package com.beamos.adapter;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.util.Log;

import com.beamos.common.Contract;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.security.MessageDigest;

/** BeamOS Adapter: the only privileged component. Typed operations only, callers verified by certificate. */
public class AdapterService extends Service {
    private static final String TAG = "BeamAdapter";
    private Keystone keystone;
    private Input input;
    private Screen screen;
    private Picture picture;
    private Playback playback;
    private LogKeeper logs;

    @Override
    public void onCreate() {
        super.onCreate();
        keystone = new Keystone(this);
        input = new Input(this);
        screen = new Screen(this);
        picture = new Picture(this);
        playback = new Playback(this);
        logs = new LogKeeper(this);
        logs.start();
        keystone.onStart();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("adapter", "BeamOS", NotificationManager.IMPORTANCE_MIN));
        startForeground(1, new Notification.Builder(this, "adapter").setContentTitle("BeamOS")
                .setSmallIcon(android.R.drawable.stat_sys_download_done).build());
        String v = "?";
        try { v = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) {}
        Log.i(TAG, "adapter " + v + " started, uid=" + Process.myUid() + " beem=" + Device.isBeem());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    private boolean callerTrusted(int uid) {
        if (uid == Process.myUid()) return true;
        PackageManager pm = getPackageManager();
        String[] pkgs = pm.getPackagesForUid(uid);
        if (pkgs == null) return false;
        for (String p : pkgs) {
            if (!Contract.STUDIO_PKG.equals(p)) continue;
            try {
                PackageInfo pi = pm.getPackageInfo(p, PackageManager.GET_SIGNING_CERTIFICATES);
                Signature[] s = pi.signingInfo.getApkContentsSigners();
                if (s.length == 1 && Contract.STUDIO_CERT_SHA256.equalsIgnoreCase(
                        Installer.hex(MessageDigest.getInstance("SHA-256").digest(s[0].toByteArray())))) return true;
            } catch (Exception e) {
                Log.w(TAG, "cert check failed", e);
            }
        }
        return false;
    }

    private final Binder binder = new Binder() {
        @Override
        protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) {
            if (code < Contract.STATE || code > 1000) {
                try { return super.onTransact(code, data, reply, flags); } catch (Exception e) { return false; }
            }
            int uid = Binder.getCallingUid();
            Bundle out = new Bundle();
            try {
                data.enforceInterface(Contract.DESCRIPTOR);
                Bundle in = data.readBundle(getClassLoader());
                if (in == null) in = new Bundle();
                if (!callerTrusted(uid)) throw new SecurityException("caller uid " + uid + " not trusted");
                long ident = Binder.clearCallingIdentity();
                try {
                    handle(code, in, out);
                } finally {
                    Binder.restoreCallingIdentity(ident);
                }
                if (!out.containsKey(Contract.KEY_OK)) out.putBoolean(Contract.KEY_OK, true);
            } catch (Throwable t) {
                Log.w(TAG, "call " + code + " failed: " + t);
                out.putBoolean(Contract.KEY_OK, false);
                out.putString(Contract.KEY_ERR, String.valueOf(t.getMessage()));
            }
            if (reply != null) {
                try { reply.writeBundle(out); } catch (RuntimeException e) { Log.d(TAG, "caller gone before reply (" + code + ")"); }
            }
            return true;
        }
    };

    private void handle(int code, Bundle in, Bundle out) throws Exception {
        switch (code) {
            case Contract.STATE: state(out); break;
            case Contract.KS_GET:
                out.putIntArray("vals", keystone.read());
                out.putBoolean("previewActive", keystone.previewActive());
                out.putString("previewId", keystone.previewId());
                break;
            case Contract.KS_PREVIEW:
                out.putString("id", keystone.preview(in.getIntArray("vals"), in.getInt("secs", 15)));
                break;
            case Contract.KS_CONFIRM: out.putBoolean(Contract.KEY_OK, keystone.confirm(in.getString("id"))); break;
            case Contract.KS_CANCEL: out.putBoolean(Contract.KEY_OK, keystone.cancel(in.getString("id"))); break;
            case Contract.AUTO_KS:
                Device.setProp("persist.sys.tpryauto", in.getBoolean("on") ? "1" : "0");
                out.putString("tpryauto", Device.prop("persist.sys.tpryauto", "?"));
                break;
            case Contract.KEY: input.key(in.getInt("code"), in.getBoolean("long")); break;
            case Contract.TEXT: out.putInt("skipped", input.text(in.getString("text"))); break;
            case Contract.LAUNCH: launch(in.getString("pkg")); break;
            case Contract.OPEN: open(in.getString("target")); break;
            case Contract.STORE: store(in.getString("pkg"), in.getString("query")); break;
            case Contract.GRANT_OVERLAY: grantOverlay(in.getString("pkg")); break;
            case Contract.INSTALL:
                ParcelFileDescriptor fd = in.getParcelable("fd");
                out.putString("result", Installer.install(this, fd, in.getString("pkg"), in.getString("sha256")));
                break;
            case Contract.IME: ime(in.getBoolean("on"), out); break;
            case Contract.PLAYBACK: playback.state(out); break;
            case Contract.MEDIA: out.putBoolean("handled", playback.media(in.getString("action"))); break;
            case Contract.PIC_GET: picture.read(out); break;
            case Contract.PIC_SET: out.putInt("value", picture.set(in.getInt("id"), in.getInt("value"))); break;
            case Contract.PIC_MODE: picture.mode(in.getString("mode")); picture.read(out); break;
            case Contract.LAMP: picture.setLampMode(in.getInt("mode")); out.putInt("lampMode", picture.lampMode()); break;
            case Contract.PIC_APPLY: picture.apply(in.getIntArray("vals"), in.getInt("lampMode"), out); break;
            case Contract.SCREEN: out.putByteArray("jpg", screen.capture(in.getInt("w", 960), in.getInt("q", 60))); break;
            case Contract.TOUCH:
                screen.touch(in.getFloat("x"), in.getFloat("y"), in.getFloat("x2", in.getFloat("x")),
                        in.getFloat("y2", in.getFloat("y")), in.getInt("dur", 60));
                break;
            case Contract.LOGS:
                if (in.getBoolean("persist")) out.putString("text", logs.tail(Math.max(2000, Math.min(400_000, in.getInt("lines", 300) * 120))));
                else out.putString("text", logs(Math.max(10, Math.min(2000, in.getInt("lines", 300)))));
                break;
            case Contract.TRIM: trim(out); break;
            case Contract.PKG: pkg(in.getString("pkg"), in.getBoolean("enabled"), out); break;
            case Contract.SCREENSAVER: if (in.getBoolean("start")) startDream(out); else screensaver(in.getBoolean("beam"), out); break;
            case Contract.PERF: perf(out); break;
            case Contract.SLEEP: {
                int minutes = in.getInt("minutes", 0);
                if (minutes > 0) {
                    int ms = Math.min(24 * 60, minutes) * 60_000;
                    android.provider.Settings.System.putInt(getContentResolver(), android.provider.Settings.System.SCREEN_OFF_TIMEOUT, ms);
                    Device.setProp("persist.sys.screentimeout", String.valueOf(ms));
                }
                out.putInt("minutes", android.provider.Settings.System.getInt(getContentResolver(), android.provider.Settings.System.SCREEN_OFF_TIMEOUT, 300000) / 60_000);
                break;
            }
            default: throw new IllegalArgumentException("unknown code " + code);
        }
    }

    private static final String BEAM_IME = "com.beamos.studio/.BeamIme";
    private static final String AOSP_IME = "com.android.inputmethod.latin/.LatinIME";

    /** Enables the BeamOS keyboard next to the AOSP one and selects the default. */
    private void ime(boolean on, Bundle out) {
        android.content.ContentResolver cr = getContentResolver();
        String enabled = android.provider.Settings.Secure.getString(cr, "enabled_input_methods");
        java.util.LinkedHashSet<String> list = new java.util.LinkedHashSet<>();
        if (enabled != null) for (String e : enabled.split(":")) if (!e.isEmpty()) list.add(e);
        list.add(AOSP_IME);
        if (on) list.add(BEAM_IME); else list.remove(BEAM_IME);
        android.provider.Settings.Secure.putString(cr, "enabled_input_methods", String.join(":", list));
        String previous = android.provider.Settings.Secure.getString(cr, "default_input_method");
        String fallback = previous != null && !BEAM_IME.equals(previous) && list.contains(previous) ? previous : AOSP_IME;
        android.provider.Settings.Secure.putString(cr, "default_input_method", on ? BEAM_IME : fallback);
        out.putString("default", android.provider.Settings.Secure.getString(cr, "default_input_method"));
    }

    /** Packages BeamOS may switch on/off on demand (mirroring stack, vendor screensaver). All reversible. */
    private static final String[] TOGGLABLE = {"com.ecloud.eshare.server", "com.ecloud.eairplay", "com.ecloud.emedia",
            "com.softwinner.miracastReceiver", "com.allshare.edisplay.idisp", "com.eshare.linedisplay.receiver", "com.htc.screensaver"};

    private void pkg(String pkg, boolean enabled, Bundle out) {
        boolean ok = false;
        for (String t : TOGGLABLE) if (t.equals(pkg)) ok = true;
        if (!ok) throw new SecurityException("package not togglable: " + pkg);
        PackageManager pm = getPackageManager();
        pm.setApplicationEnabledSetting(pkg, enabled ? PackageManager.COMPONENT_ENABLED_STATE_DEFAULT
                : PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER, 0);
        if (!enabled) ((ActivityManager) getSystemService(Context.ACTIVITY_SERVICE)).killBackgroundProcesses(pkg);
        out.putInt("state", pm.getApplicationEnabledSetting(pkg));
    }

    private void screensaver(boolean beam, Bundle out) {
        android.content.ContentResolver cr = getContentResolver();
        String comp = beam ? Contract.STUDIO_PKG + "/com.beamos.studio.BeamDream" : "com.htc.screensaver/com.htc.screensaver.ScreenSaverService";
        android.provider.Settings.Secure.putString(cr, "screensaver_components", comp);
        android.provider.Settings.Secure.putString(cr, "screensaver_default_component", comp);
        android.provider.Settings.Secure.putInt(cr, "screensaver_enabled", 1);
        android.provider.Settings.Secure.putInt(cr, "screensaver_activate_on_sleep", 1);
        out.putString("component", android.provider.Settings.Secure.getString(cr, "screensaver_components"));
    }

    /** Starts whichever screensaver is selected (IDreamManager.dream(); allowed for the platform-signed uid 1000). */
    private void startDream(Bundle out) throws Exception {
        Class<?> sm = Class.forName("android.os.ServiceManager");
        android.os.IBinder b = (android.os.IBinder) sm.getMethod("getService", String.class).invoke(null, "dreams");
        if (b == null) throw new Exception("no dream service");
        Object dm = Class.forName("android.service.dreams.IDreamManager$Stub").getMethod("asInterface", android.os.IBinder.class).invoke(null, b);
        dm.getClass().getMethod("dream").invoke(dm);
        out.putBoolean("started", true);
    }

    private void perf(Bundle out) throws Exception {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        java.util.List<ActivityManager.RunningAppProcessInfo> procs = am.getRunningAppProcesses();
        java.util.ArrayList<String> rows = new java.util.ArrayList<>();
        if (procs != null) {
            int[] pids = new int[procs.size()];
            for (int i = 0; i < pids.length; i++) pids[i] = procs.get(i).pid;
            android.os.Debug.MemoryInfo[] mi = am.getProcessMemoryInfo(pids);
            java.util.List<Object[]> list = new java.util.ArrayList<>();
            for (int i = 0; i < pids.length; i++) list.add(new Object[]{procs.get(i).processName, mi[i].getTotalPss() / 1024, procs.get(i).importance});
            java.util.Collections.sort(list, (a, b) -> Integer.compare((Integer) b[1], (Integer) a[1]));
            for (int i = 0; i < Math.min(14, list.size()); i++) {
                Object[] r = list.get(i);
                rows.add(r[0] + "|" + r[1] + "|" + ((Integer) r[2] <= 100 ? "foreground" : (Integer) r[2] >= 400 ? "cached" : "background"));
            }
        }
        out.putStringArrayList("top", rows);
        for (String line : Device.readFile("/proc/meminfo").split("\n")) {}
        java.util.Map<String, Long> mem = new java.util.HashMap<>();
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader("/proc/meminfo"))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\\s+");
                if (p.length >= 2) mem.put(p[0].replace(":", ""), Long.parseLong(p[1]) / 1024);
            }
        }
        for (String k : new String[]{"MemTotal", "MemAvailable", "MemFree", "Cached", "SwapTotal", "SwapFree"}) out.putLong(k, mem.containsKey(k) ? mem.get(k) : -1);
        out.putString("loadavg", Device.readFile("/proc/loadavg"));
        out.putString("uptime", Device.readFile("/proc/uptime").split(" ")[0]);
        out.putString("lcdTemp", Device.readFile("/sys/class/prj/lcdtemp"));
        out.putString("fanLevel", Device.readFile("/sys/class/prj/speedlevel"));
        int kills = 0;
        try {
            java.lang.Process p = Runtime.getRuntime().exec(new String[]{"logcat", "-d", "-s", "lowmemorykiller:I", "lmkd:I"});
            try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) if (line.contains("Kill") || line.contains("kill")) kills++;
            }
        } catch (Exception ignored) {}
        out.putInt("lmkKills", kills);
    }

    /** Closes cached background apps (not BeamOS, not the foreground app) and reports the memory freed. */
    private void trim(Bundle out) {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo before = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(before);
        int closed = 0;
        java.util.List<ActivityManager.RunningAppProcessInfo> procs = am.getRunningAppProcesses();
        if (procs != null) for (ActivityManager.RunningAppProcessInfo p : procs) {
            if (p.importance < ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED) continue;
            if (p.processName.startsWith("com.beamos") || p.pkgList == null) continue;
            for (String pkg : p.pkgList) { am.killBackgroundProcesses(pkg); closed++; }
        }
        try { Thread.sleep(800); } catch (InterruptedException ignored) {}
        ActivityManager.MemoryInfo after = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(after);
        out.putInt("closed", closed);
        out.putInt("freedMb", (int) Math.max(0, (after.availMem - before.availMem) / (1024 * 1024)));
        out.putLong("memAvailMb", after.availMem / (1024 * 1024));
    }

    private void launch(String pkg) {
        if (pkg == null) throw new IllegalArgumentException("pkg");
        PackageManager pm = getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) throw new IllegalArgumentException("no launcher entry for " + pkg);
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED));
    }

    private void store(String pkg, String query) {
        String uri;
        if (pkg != null && pkg.matches("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+")) uri = "market://details?id=" + pkg;
        else if (query != null && query.matches("[A-Za-z0-9 +.&'-]{1,48}")) uri = "market://search?q=" + android.net.Uri.encode(query) + "&c=apps";
        else throw new IllegalArgumentException("bad store request");
        startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(uri)).setPackage("com.android.vending")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    /** Only for BeamOS Studio: allow its transparent alignment overlay (app-op SYSTEM_ALERT_WINDOW). */
    private void grantOverlay(String pkg) throws Exception {
        if (!Contract.STUDIO_PKG.equals(pkg)) throw new SecurityException("overlay only for BeamOS Studio");
        int uid = getPackageManager().getPackageUid(pkg, 0);
        android.app.AppOpsManager ops = (android.app.AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        try {
            ops.getClass().getMethod("setMode", String.class, int.class, String.class, int.class)
                    .invoke(ops, "android:system_alert_window", uid, pkg, 0 /* MODE_ALLOWED */);
        } catch (NoSuchMethodException e) {
            ops.getClass().getMethod("setMode", int.class, int.class, String.class, int.class)
                    .invoke(ops, 24 /* OP_SYSTEM_ALERT_WINDOW */, uid, pkg, 0);
        }
    }

    private void open(String target) {
        String pkg, cls;
        if ("hdmi".equals(target)) { pkg = "com.softwinner.awlivetv"; cls = "com.softwinner.awlivetv.MainActivity"; }
        else if ("coach".equals(target)) { pkg = Contract.STUDIO_PKG; cls = "com.beamos.studio.CoachActivity"; }
        else if ("studio_home".equals(target)) { pkg = Contract.STUDIO_PKG; cls = "com.beamos.studio.HomeActivity"; }
        else if ("vendor_settings".equals(target)) { pkg = "com.htc.htcsettings"; cls = "com.htc.activity.HomeActivity"; }
        else if ("wifi".equals(target)) { pkg = "com.htc.htcsettings"; cls = "com.htc.activity.WIFIActivity"; }
        else if ("bluetooth".equals(target)) { pkg = "com.htc.htcsettings"; cls = "com.htc.activity.BluetoothActivity"; }
        else if ("sound".equals(target)) { pkg = "com.htc.htcsettings"; cls = "com.htc.activity.AudioActivity"; }
        else if ("projection".equals(target)) { pkg = "com.htc.htcsettings"; cls = "com.htc.activity.ProjectionActivity"; }
        else if ("vendor_home".equals(target)) { pkg = "com.htc.htclauncherhighenglishd08"; cls = "com.htc.activity.HomeActivity"; }
        else throw new IllegalArgumentException("unknown target " + target);
        startActivity(new Intent().setClassName(pkg, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }

    private void state(Bundle out) {
        String av = "?";
        try { av = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) {}
        out.putString("adapterVersion", av);
        out.putBoolean("beem", Device.isBeem());
        out.putString("firmware", Device.prop("ro.build.display.id", ""));
        out.putString("device", Device.prop("persist.sys.deviceName", Device.prop("ro.product.model", "")));
        out.putString("autoKeystone", Device.prop("persist.sys.tpryauto", ""));
        out.putString("keystoneAngle", Device.prop("persist.sys.keystoneAngle", ""));
        out.putString("overscan", Device.prop("persist.vendor.overscan.main", ""));
        out.putIntArray("keystone", keystone.read());
        out.putBoolean("previewActive", keystone.previewActive());
        Bundle pb = new Bundle();
        playback.state(pb);
        out.putBoolean("playing", pb.getBoolean("playing"));
        if (pb.containsKey("app")) out.putString("playingApp", pb.getString("app"));
        if (pb.containsKey("title")) out.putString("playingTitle", pb.getString("title"));
        int[] a = Device.accel();
        if (a != null) out.putIntArray("accel", a);
        out.putString("lcdTemp", Device.readFile("/sys/class/prj/lcdtemp"));
        out.putString("fanLevel", Device.readFile("/sys/class/prj/speedlevel"));
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        out.putLong("memAvailMb", mi.availMem / (1024 * 1024));
        out.putLong("memTotalMb", mi.totalMem / (1024 * 1024));
    }

    /** Recent BeamOS log lines only (our tags), for the remote diagnostics page. */
    private static String logs(int lines) throws Exception {
        java.lang.Process p = Runtime.getRuntime().exec(new String[]{
                "logcat", "-d", "-v", "time", "-t", String.valueOf(lines), "-s", "BeamAdapter:V", "BeamStudio:V", "BeamProbe:V"});
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String line;
            while ((line = r.readLine()) != null) b.append(line).append('\n');
        }
        return b.toString();
    }
}
