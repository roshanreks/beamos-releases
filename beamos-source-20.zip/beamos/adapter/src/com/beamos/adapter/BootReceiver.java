package com.beamos.adapter;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Starts the adapter at boot so a preview interrupted by a power cut is restored immediately. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        ctx.startForegroundService(new Intent(ctx, AdapterService.class));
    }
}
