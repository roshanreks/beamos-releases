package com.beamos.adapter;

import android.os.IBinder;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/** Thin wrappers around hidden platform APIs and the Beem's sysfs nodes. Emulator = fake mode. */
final class Device {
    private static final String TAG = "BeamAdapter";
    private static final Map<String, String> FAKE_PROPS = new HashMap<>();
    private static Method sGet, sSet, sService;

    private Device() {}

    static boolean isBeem() {
        return "sun50iw12p1".equals(prop("ro.hardware", ""));
    }

    static synchronized String prop(String key, String def) {
        if (FAKE_PROPS.containsKey(key)) return FAKE_PROPS.get(key);
        try {
            if (sGet == null) sGet = Class.forName("android.os.SystemProperties").getMethod("get", String.class, String.class);
            return (String) sGet.invoke(null, key, def);
        } catch (Exception e) {
            Log.w(TAG, "prop get failed " + key, e);
            return def;
        }
    }

    /** Only called with allowlisted keys from this package. In fake mode values stay in memory. */
    static synchronized void setProp(String key, String value) throws Exception {
        if (!isBeem()) { FAKE_PROPS.put(key, value); return; }
        if (sSet == null) sSet = Class.forName("android.os.SystemProperties").getMethod("set", String.class, String.class);
        sSet.invoke(null, key, value);
    }

    static IBinder service(String name) throws Exception {
        if (sService == null) sService = Class.forName("android.os.ServiceManager").getMethod("getService", String.class);
        return (IBinder) sService.invoke(null, name);
    }

    static String readFile(String path) {
        try (BufferedReader r = new BufferedReader(new FileReader(path))) {
            String line = r.readLine();
            return line == null ? "" : line.trim();
        } catch (Exception e) {
            return "";
        }
    }

    /** Accelerometer from the projector's own sensor node: "x,y,z" in ~1/1024 g. */
    static int[] accel() {
        String s = readFile("/sys/devices/platform/prj343x/xyz_data");
        String[] p = s.split(",");
        if (p.length != 3) return null;
        try {
            return new int[]{Integer.parseInt(p[0].trim()), Integer.parseInt(p[1].trim()), Integer.parseInt(p[2].trim())};
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
