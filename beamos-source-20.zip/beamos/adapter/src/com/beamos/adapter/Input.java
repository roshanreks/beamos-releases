package com.beamos.adapter;

import android.content.Context;
import android.hardware.input.InputManager;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;

import java.lang.reflect.Method;

/** Key and text injection as the system uid (INJECT_EVENTS). Text is never logged. */
final class Input {
    private static final int INJECT_ASYNC = 0;
    private static final int[] ALLOWED_KEYS = {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_HOME,
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_VOLUME_MUTE,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_PREVIOUS,
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD, KeyEvent.KEYCODE_MEDIA_REWIND, KeyEvent.KEYCODE_DEL,
            KeyEvent.KEYCODE_FORWARD_DEL, KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_TAB, KeyEvent.KEYCODE_SEARCH,
            KeyEvent.KEYCODE_SETTINGS, KeyEvent.KEYCODE_APP_SWITCH, KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_PAGE_DOWN,
            KeyEvent.KEYCODE_MOVE_HOME, KeyEvent.KEYCODE_MOVE_END, KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_TV_INPUT,
            KeyEvent.KEYCODE_SLEEP, KeyEvent.KEYCODE_WAKEUP, KeyEvent.KEYCODE_CAPTIONS, KeyEvent.KEYCODE_INFO
    };

    private final InputManager im;
    private Method inject;

    Input(Context ctx) {
        im = (InputManager) ctx.getSystemService(Context.INPUT_SERVICE);
    }

    static boolean allowed(int code) {
        for (int k : ALLOWED_KEYS) if (k == code) return true;
        return false;
    }

    private void injectEvent(InputEvent e) throws Exception {
        if (inject == null) inject = InputManager.class.getMethod("injectInputEvent", InputEvent.class, int.class);
        inject.invoke(im, e, INJECT_ASYNC);
    }

    void key(int code, boolean longPress) throws Exception {
        if (!allowed(code)) throw new IllegalArgumentException("key not allowed: " + code);
        long now = SystemClock.uptimeMillis();
        injectEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0, 0, KeyCharacterMap.VIRTUAL_KEYBOARD, 0,
                KeyEvent.FLAG_FROM_SYSTEM, InputDevice.SOURCE_KEYBOARD));
        if (longPress) {
            injectEvent(new KeyEvent(now, now + 600, KeyEvent.ACTION_DOWN, code, 1, 0, KeyCharacterMap.VIRTUAL_KEYBOARD, 0,
                    KeyEvent.FLAG_FROM_SYSTEM | KeyEvent.FLAG_LONG_PRESS, InputDevice.SOURCE_KEYBOARD));
        }
        long up = SystemClock.uptimeMillis();
        injectEvent(new KeyEvent(now, up, KeyEvent.ACTION_UP, code, 0, 0, KeyCharacterMap.VIRTUAL_KEYBOARD, 0,
                KeyEvent.FLAG_FROM_SYSTEM, InputDevice.SOURCE_KEYBOARD));
    }

    /** Types text into the focused field. Returns the number of characters that could not be typed. */
    int text(String s) throws Exception {
        if (s == null) return 0;
        if (s.length() > 500) throw new IllegalArgumentException("text too long");
        KeyCharacterMap map = KeyCharacterMap.load(KeyCharacterMap.VIRTUAL_KEYBOARD);
        int skipped = 0;
        for (int i = 0; i < s.length(); i++) {
            KeyEvent[] events = map.getEvents(new char[]{s.charAt(i)});
            if (events == null) { skipped++; continue; }
            for (KeyEvent e : events) {
                injectEvent(KeyEvent.changeFlags(e, e.getFlags() | KeyEvent.FLAG_FROM_SYSTEM));
            }
        }
        return skipped;
    }
}
