package com.beamos.adapter;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import com.beamos.common.Contract;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Silent installer for BeamOS packages only. Checks before installing:
 *  1. SHA-256 of the file equals the expected value (from the signed update manifest),
 *  2. package name is a BeamOS package and equals the expected name,
 *  3. signing certificate equals the pinned BeamOS certificate for that package.
 * One install at a time; the verified bytes are the installed bytes (same temp file, no re-read race).
 */
final class Installer {
    private static final String TAG = "BeamAdapter";
    private static final String ACTION = "com.beamos.adapter.INSTALL_RESULT";
    private static final Object LOCK = new Object();

    static String install(Context ctx, ParcelFileDescriptor pfd, String expectedPkg, String expectedSha256) throws Exception {
        synchronized (LOCK) {
            return installLocked(ctx, pfd, expectedPkg, expectedSha256);
        }
    }

    private static String installLocked(Context ctx, ParcelFileDescriptor pfd, String expectedPkg, String expectedSha256) throws Exception {
        if (expectedPkg == null || !expectedPkg.startsWith("com.beamos.")) throw new SecurityException("not a BeamOS package");
        File tmp = File.createTempFile("update", ".apk", ctx.getCacheDir());
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            try (InputStream in = new ParcelFileDescriptor.AutoCloseInputStream(pfd);
                 OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[65536];
                int n;
                long total = 0;
                while ((n = in.read(buf)) > 0) {
                    total += n;
                    if (total > 200L * 1024 * 1024) throw new SecurityException("file too large");
                    md.update(buf, 0, n);
                    out.write(buf, 0, n);
                }
            }
            String sha = hex(md.digest());
            if (expectedSha256 == null || !sha.equalsIgnoreCase(expectedSha256)) throw new SecurityException("sha256 mismatch");

            PackageManager pm = ctx.getPackageManager();
            PackageInfo info = pm.getPackageArchiveInfo(tmp.getAbsolutePath(), PackageManager.GET_SIGNING_CERTIFICATES);
            if (info == null || !expectedPkg.equals(info.packageName)) throw new SecurityException("package name mismatch");
            String pinned = Contract.ADAPTER_PKG.equals(expectedPkg) ? Contract.PLATFORM_CERT_SHA256 : Contract.STUDIO_CERT_SHA256;
            Signature[] sigs = info.signingInfo == null ? null : info.signingInfo.getApkContentsSigners();
            if (sigs == null || sigs.length != 1 || !pinned.equalsIgnoreCase(hex(MessageDigest.getInstance("SHA-256").digest(sigs[0].toByteArray())))) {
                throw new SecurityException("signing certificate not trusted");
            }

            PackageInstaller pi = pm.getPackageInstaller();
            PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            params.setAppPackageName(expectedPkg);
            final int sessionId = pi.createSession(params);
            try (PackageInstaller.Session s = pi.openSession(sessionId);
                 InputStream in = new FileInputStream(tmp);
                 OutputStream out = s.openWrite("base.apk", 0, tmp.length())) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                s.fsync(out);
                out.close();

                final String[] result = {"timeout"};
                final CountDownLatch done = new CountDownLatch(1);
                BroadcastReceiver r = new BroadcastReceiver() {
                    @Override public void onReceive(Context c, Intent i) {
                        if (i.getIntExtra(PackageInstaller.EXTRA_SESSION_ID, -1) != sessionId) return;
                        int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
                        result[0] = status == PackageInstaller.STATUS_SUCCESS ? "success"
                                : "failure " + status + " " + i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                        done.countDown();
                    }
                };
                // Only the system (PackageInstaller) can satisfy INSTALL_PACKAGES, so the result can't be spoofed.
                ctx.registerReceiver(r, new IntentFilter(ACTION), android.Manifest.permission.INSTALL_PACKAGES, null);
                try {
                    PendingIntent pi2 = PendingIntent.getBroadcast(ctx, sessionId, new Intent(ACTION).setPackage(ctx.getPackageName()),
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    s.commit(pi2.getIntentSender());
                    // Installing the adapter itself restarts this process; the install still completes.
                    done.await(120, TimeUnit.SECONDS);
                } finally {
                    ctx.unregisterReceiver(r);
                }
                Log.i(TAG, "install " + expectedPkg + " -> " + result[0]);
                return result[0];
            }
        } finally {
            tmp.delete();
        }
    }

    static String hex(byte[] b) {
        StringBuilder s = new StringBuilder();
        for (byte x : b) s.append(String.format("%02X", x));
        return s.toString();
    }
}
