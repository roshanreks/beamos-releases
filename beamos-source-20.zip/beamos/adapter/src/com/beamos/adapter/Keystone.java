package com.beamos.adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.util.Log;

import com.beamos.common.Contract;

import java.util.Arrays;
import java.util.UUID;

/**
 * Keystone engine for the Beem 470 (Hotack H713): SurfaceFlinger transaction 1050, 8 floats LB,LT,RT,RB (x,y),
 * each per-mille/1000. SurfaceFlinger itself persists the values into persist.display.keystone_*.
 *
 * Preview coordinator (device-side): the original values are saved to disk BEFORE the first preview write;
 * further previews update the picture and extend the timer; confirm keeps it; cancel/timeout/restart restores
 * the saved original. A restore that fails is retried every 5 s until it succeeds — the original is never forgotten.
 */
final class Keystone {
    private static final String TAG = "BeamAdapter";
    private static final String[] KEYS = {"lbx", "lby", "ltx", "lty", "rtx", "rty", "rbx", "rby"};
    private static final String PREFS = "keystone_preview";
    private static final long RETRY_MS = 5000;

    private final Context ctx;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable expiry = this::onExpiry;
    private final boolean real;

    Keystone(Context ctx) {
        this.ctx = ctx;
        this.real = Device.isBeem();
    }

    private SharedPreferences prefs() {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    synchronized int[] read() {
        int[] v = new int[KEYS.length];
        for (int i = 0; i < KEYS.length; i++) {
            v[i] = parse(Device.prop("persist.display.keystone_" + KEYS[i], "0"));
        }
        return v;
    }

    private static int parse(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }

    /** Sends the 8 insets to SurfaceFlinger. Range-checked only; callers decide how strict to be. */
    private boolean applyUnchecked(int[] v) throws Exception {
        if (!Contract.insetsInRange(v)) throw new IllegalArgumentException("insets out of range " + Arrays.toString(v));
        if (!real) {
            Log.i(TAG, "FAKE keystone apply " + Arrays.toString(v));
            for (int i = 0; i < KEYS.length; i++) Device.setProp("persist.display.keystone_" + KEYS[i], String.valueOf(v[i]));
            return true;
        }
        IBinder sf = Device.service("SurfaceFlinger");
        if (sf == null) throw new IllegalStateException("SurfaceFlinger not found");
        Parcel p = Parcel.obtain();
        try {
            p.writeInterfaceToken("android.ui.ISurfaceComposer");
            for (int x : v) p.writeFloat((float) (x * 0.001d));
            return sf.transact(1050, p, null, 0);
        } finally {
            p.recycle();
        }
    }

    /** Starts or updates a preview. Returns the preview id. */
    synchronized String preview(int[] v, int secs) throws Exception {
        if (!Contract.validInsets(v)) throw new IllegalArgumentException("invalid insets " + Arrays.toString(v));
        secs = Math.max(Contract.PREVIEW_MIN_SECS, Math.min(Contract.PREVIEW_MAX_SECS, secs));
        SharedPreferences sp = prefs();
        String id = sp.getString("id", null);
        long expiresAt = System.currentTimeMillis() + secs * 1000L;
        if (id == null) {
            id = UUID.randomUUID().toString();
            // Persist the original BEFORE touching the display (one commit so id/original/expires are consistent).
            if (!sp.edit().putString("id", id).putString("original", join(read())).putLong("expires", expiresAt).commit()) {
                throw new IllegalStateException("could not persist original state");
            }
        } else {
            sp.edit().putLong("expires", expiresAt).commit();
        }
        handler.removeCallbacks(expiry);
        handler.postDelayed(expiry, secs * 1000L);
        if (!applyUnchecked(v)) throw new IllegalStateException("SurfaceFlinger refused the keystone");
        Log.i(TAG, "preview id=" + id + " vals=" + Arrays.toString(v) + " secs=" + secs);
        return id;
    }

    synchronized boolean confirm(String id) {
        SharedPreferences sp = prefs();
        if (id == null || !id.equals(sp.getString("id", null))) return false;
        handler.removeCallbacks(expiry);
        sp.edit().clear().commit();
        Log.i(TAG, "confirm id=" + id + " vals=" + Arrays.toString(read()));
        return true;
    }

    synchronized boolean cancel(String id) {
        SharedPreferences sp = prefs();
        if (id != null && !id.equals(sp.getString("id", null))) return false;
        return restorePending("cancel");
    }

    /**
     * Restores a pending preview if any (cancel, timeout, service start after a crash/reboot).
     * On failure the saved original is kept and a retry is scheduled.
     */
    synchronized boolean restorePending(String why) {
        SharedPreferences sp = prefs();
        String original = sp.getString("original", null);
        if (original == null) return false;
        handler.removeCallbacks(expiry);
        int[] v = split(original);
        boolean ok;
        try {
            ok = applyUnchecked(v);
        } catch (Exception e) {
            ok = false;
            Log.e(TAG, "restore(" + why + ") failed: " + e);
        }
        boolean match = !real || Arrays.equals(read(), v);
        if (!ok || !match) {
            Log.w(TAG, "restore(" + why + ") not confirmed (ok=" + ok + " match=" + match + ") — retrying in 5 s");
            handler.postDelayed(expiry, RETRY_MS);
            return false;
        }
        sp.edit().clear().commit();
        Log.i(TAG, "restore(" + why + ") ok vals=" + Arrays.toString(v));
        return true;
    }

    synchronized void onStart() {
        SharedPreferences sp = prefs();
        if (sp.getString("original", null) == null) return;
        long left = sp.getLong("expires", 0) - System.currentTimeMillis();
        if (left <= 0) restorePending("expired-at-start");
        else handler.postDelayed(expiry, left);
    }

    private void onExpiry() {
        synchronized (this) {
            // A preview may have been extended between the timer firing and this running (L1).
            if (System.currentTimeMillis() < prefs().getLong("expires", 0) - 100) return;
        }
        restorePending("timeout");
    }

    synchronized boolean previewActive() {
        return prefs().getString("original", null) != null;
    }

    synchronized String previewId() {
        return prefs().getString("id", null);
    }

    static String join(int[] v) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < v.length; i++) { if (i > 0) b.append(','); b.append(v[i]); }
        return b.toString();
    }

    static int[] split(String s) {
        String[] p = s.split(",");
        int[] v = new int[p.length];
        for (int i = 0; i < p.length; i++) v[i] = Integer.parseInt(p[i].trim());
        return v;
    }
}
