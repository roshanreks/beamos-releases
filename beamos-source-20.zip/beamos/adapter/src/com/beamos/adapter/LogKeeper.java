package com.beamos.adapter;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;

/**
 * Persistent log ring (survives reboots and freezes): streams `logcat` into 3 × 1 MB files in the adapter's
 * private storage so the last minutes before a hang can be read afterwards. Only warnings and above from the
 * system plus everything from BeamOS, to stay small on a 1 GB device.
 */
final class LogKeeper {
    private static final String TAG = "BeamAdapter";
    private static final long MAX_FILE = 1024 * 1024;
    private static final int FILES = 3;
    private final File dir;
    private Thread thread;

    LogKeeper(Context ctx) {
        dir = new File(ctx.getFilesDir(), "logs");
        dir.mkdirs();
    }

    synchronized void start() {
        if (thread != null) return;
        thread = new Thread(this::run, "beam-logkeeper");
        thread.setDaemon(true);
        thread.start();
    }

    private File current() { return new File(dir, "log.0"); }

    private synchronized void rotate() {
        new File(dir, "log." + (FILES - 1)).delete();
        for (int i = FILES - 2; i >= 0; i--) {
            File f = new File(dir, "log." + i);
            if (f.exists()) f.renameTo(new File(dir, "log." + (i + 1)));
        }
    }

    private void run() {
        while (true) {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"logcat", "-v", "time", "-b", "main,system,crash",
                        "*:W", "BeamAdapter:I", "BeamStudio:I", "ActivityManager:I", "WindowManager:I", "PowerManagerService:I"});
                try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
                     FileWriter w = new FileWriter(current(), true)) {
                    String line;
                    long size = current().length();
                    int n = 0;
                    while ((line = r.readLine()) != null) {
                        w.write(line);
                        w.write('\n');
                        size += line.length() + 1;
                        if (++n % 20 == 0) w.flush();
                        if (size > MAX_FILE) { w.flush(); rotate(); break; }
                    }
                }
                p.destroy();
            } catch (Exception e) {
                Log.w(TAG, "logkeeper: " + e);
                try { Thread.sleep(5000); } catch (InterruptedException ie) { return; }
            }
        }
    }

    /** Last `maxBytes` of the persisted log (newest file last). */
    synchronized String tail(int maxBytes) {
        StringBuilder sb = new StringBuilder();
        for (int i = FILES - 1; i >= 0; i--) {
            File f = new File(dir, "log." + i);
            if (!f.exists()) continue;
            try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
                long len = raf.length();
                long from = Math.max(0, len - maxBytes);
                raf.seek(from);
                byte[] b = new byte[(int) (len - from)];
                raf.readFully(b);
                sb.append(new String(b, StandardCharsets.UTF_8));
            } catch (Exception ignored) {}
        }
        int over = sb.length() - maxBytes;
        return over > 0 ? sb.substring(over) : sb.toString();
    }
}
