package com.beamos.adapter;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * Picture quality through the projector's own picture engine (Allwinner ITvServer via the com.softwinner.tv library):
 * setPQValue(id, value) / getPQValue(id), picture modes by name, and the lamp power mode (android.os.PrjScreen).
 * Every id and value is allow-listed and clamped to the engine's documented range (research/05 §1).
 */
final class Picture {
    private static final String TAG = "BeamAdapter";

    /** id -> {min, max}; names are what the phone shows. */
    static final int[][] PARAMS = {
            {1, 0, 100},   // brightness (image)
            {2, 0, 100},   // contrast
            {3, 0, 100},   // saturation
            {4, 0, 100},   // hue (50 neutral)
            {5, 0, 100},   // sharpness
            {6, 10, 100},  // backlight / LED dimming (never below 10 so the picture can't go dark)
            {7, 0, 3},     // temporal noise reduction
            {8, 0, 3},     // spatial noise reduction
            {9, 0, 3},     // dynamic contrast (DCI)
            {10, 0, 3},    // black extension
            {11, 0, 4},    // gamma 1.8 / 2.0 / 2.1 / 2.2 / 2.4
            {12, 0, 3},    // colour temperature std / cool / warm / user
            {13, 0, 1},    // dynamic backlight
    };
    static final String[] MODES = {"standard", "cinema", "vivid", "game", "computer", "energy_saving", "custom"};

    private final Context ctx;
    private final boolean real;
    private final Map<Integer, Integer> fake = new HashMap<>();
    private Object tv;
    private Method set, get, setMode, getMode;
    private String fakeMode = "standard";
    private int fakeLamp;

    Picture(Context ctx) {
        this.ctx = ctx;
        this.real = Device.isBeem();
    }

    private synchronized void init() throws Exception {
        if (tv != null) return;
        ClassLoader cl = ctx.getClassLoader();
        Class<?> proxyCls = Class.forName("com.softwinner.tv.client.AwTvServerManagerProxy", true, cl);
        Object proxy = proxyCls.getMethod("getInstance").invoke(null);
        Object server = proxyCls.getMethod("getAwTvServerManager").invoke(proxy);
        if (server == null) throw new IllegalStateException("picture engine not available");
        Class<?> itf = Class.forName("vendor.aw.homlet.tvsystem.tvserver.V1_0.ITvServer", true, cl);
        set = itf.getMethod("setPQValue", int.class, int.class);
        get = itf.getMethod("getPQValue", int.class);
        setMode = itf.getMethod("setPictureModeByName", String.class);
        getMode = itf.getMethod("getPictureModeName");
        tv = server;
    }

    private static int[] range(int id) {
        for (int[] p : PARAMS) if (p[0] == id) return p;
        return null;
    }

    synchronized void read(Bundle out) throws Exception {
        int[] ids = new int[PARAMS.length], vals = new int[PARAMS.length];
        if (real) init();
        try {
            for (int i = 0; i < PARAMS.length; i++) {
                ids[i] = PARAMS[i][0];
                vals[i] = real ? (Integer) get.invoke(tv, ids[i]) : fake.containsKey(ids[i]) ? fake.get(ids[i]) : ids[i] == 6 ? 100 : ids[i] > 6 ? 0 : 50;
            }
        } catch (Exception e) { tv = null; throw e; }
        out.putIntArray("ids", ids);
        out.putIntArray("vals", vals);
        out.putString("mode", real ? String.valueOf(getMode.invoke(tv)) : fakeMode);
        out.putInt("lampMode", lampMode());
        out.putString("panelBrightness", real ? Device.readFile("/sys/class/backlight/tv/brightness") : "100");
    }

    synchronized int set(int id, int value) throws Exception {
        int[] r = range(id);
        if (r == null) throw new IllegalArgumentException("unknown picture setting " + id);
        int v = Math.max(r[1], Math.min(r[2], value));
        if (!real) { fakeMode = "custom"; fake.put(id, v); return v; }
        Bundle before = new Bundle(); read(before);
        if (!"custom".equals(before.getString("mode"))) {
            mode("custom"); // the vendor UI only permits edits in Custom; retain the look being edited
            int[] values = before.getIntArray("vals");
            for (int i = 0; i < PARAMS.length; i++) write(PARAMS[i][0], values[i]);
        }
        return write(id, v);
    }

    private int write(int id, int value) throws Exception {
        if (!real) { fake.put(id, value); return value; }
        init();
        try {
            set.invoke(tv, id, value);
            int actual = (Integer) get.invoke(tv, id);
            if (actual != value) throw new IllegalStateException("Picture setting " + id + " was not applied (requested " + value + ", actual " + actual + ")");
            return actual;
        } catch (Exception e) { tv = null; throw e; }
    }

    /** One serialized, verified operation; callers cannot write arbitrary hardware parameters. */
    synchronized void apply(int[] values, int lamp, Bundle out) throws Exception {
        if (values == null || values.length != PARAMS.length || lamp < 0 || lamp > 2) throw new IllegalArgumentException("invalid picture preset");
        for (int i = 0; i < PARAMS.length; i++) if (values[i] < PARAMS[i][1] || values[i] > PARAMS[i][2]) throw new IllegalArgumentException("picture value out of range: " + PARAMS[i][0]);
        Bundle previous = new Bundle(); read(previous);
        try {
            mode("custom");
            setLampMode(lamp); // power/panel policy first, then the user's picture values
            for (int i = 0; i < PARAMS.length; i++) write(PARAMS[i][0], values[i]);
            read(out);
            int[] actual = out.getIntArray("vals");
            for (int i = 0; i < PARAMS.length; i++) if (actual[i] != values[i]) throw new IllegalStateException("Picture setting changed during apply: " + PARAMS[i][0]);
            if (out.getInt("lampMode") != lamp) throw new IllegalStateException("Lamp mode did not apply");
        } catch (Exception e) {
            try {
                mode(previous.getString("mode"));
                setLampMode(previous.getInt("lampMode"));
                int[] old = previous.getIntArray("vals");
                for (int i = 0; i < PARAMS.length; i++) write(PARAMS[i][0], old[i]);
            } catch (Exception restore) { Log.e(TAG, "picture restore failed", restore); }
            throw e;
        }
    }

    synchronized void mode(String name) throws Exception {
        boolean ok = false;
        for (String m : MODES) if (m.equals(name)) ok = true;
        if (!ok) throw new IllegalArgumentException("unknown picture mode " + name);
        if (!real) { fakeMode = name; return; }
        init();
        setMode.invoke(tv, name);
        if (!name.equals(String.valueOf(getMode.invoke(tv)))) throw new IllegalStateException("Picture mode did not apply: " + name);
    }

    /** Lamp power: 0 standard, 1 energy saving, 2 high-bright (fan follows the vendor's coupling). */
    int lampMode() {
        if (!real) return fakeLamp;
        try {
            return (Integer) Class.forName("android.os.PrjScreen").getMethod("get_brightness_level").invoke(null);
        } catch (Exception e) {
            return -1;
        }
    }

    synchronized void setLampMode(int m) throws Exception {
        if (m < 0 || m > 2) throw new IllegalArgumentException("lamp mode 0..2");
        if (!real) { fakeLamp = m; return; }
        Class<?> prj = Class.forName("android.os.PrjScreen");
        prj.getMethod("set_brightness_level", int.class).invoke(null, m);
        // set_brightness_level already selects the vendor fan policy; do not override thermal control.
        if (m == 2) prj.getMethod("set_bright", int.class).invoke(null, 3); // vendor's highest supported panel level
        Log.i(TAG, "lamp mode " + m);
    }
}
