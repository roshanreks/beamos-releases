package com.beamos.adapter;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.util.Log;

import java.util.List;

/**
 * Playback guard: what is playing right now (MediaSession + audio activity), and transport controls that go
 * through the app's own MediaController — never through injected keys, so the player's UI stays untouched.
 * Runs as system uid (MEDIA_CONTENT_CONTROL).
 */
final class Playback {
    private static final String TAG = "BeamAdapter";
    private final Context ctx;
    private final MediaSessionManager msm;
    private final AudioManager am;

    Playback(Context ctx) {
        this.ctx = ctx;
        this.msm = (MediaSessionManager) ctx.getSystemService(Context.MEDIA_SESSION_SERVICE);
        this.am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
    }

    private List<MediaController> sessions() {
        try {
            return msm.getActiveSessions((ComponentName) null);
        } catch (Exception e) {
            Log.w(TAG, "sessions: " + e);
            return java.util.Collections.emptyList();
        }
    }

    /** The controller that is playing, else the first with a state, else null. */
    private MediaController current() {
        MediaController best = null;
        for (MediaController c : sessions()) {
            PlaybackState s = c.getPlaybackState();
            if (s == null) continue;
            if (s.getState() == PlaybackState.STATE_PLAYING) return c;
            if (best == null) best = c;
        }
        return best;
    }

    void state(Bundle out) {
        MediaController c = current();
        boolean music = am.isMusicActive();
        boolean playing = music;
        if (c != null) {
            PlaybackState s = c.getPlaybackState();
            playing = playing || (s != null && s.getState() == PlaybackState.STATE_PLAYING);
            out.putString("pkg", c.getPackageName());
            try {
                out.putString("app", String.valueOf(ctx.getPackageManager().getApplicationLabel(
                        ctx.getPackageManager().getApplicationInfo(c.getPackageName(), 0))));
            } catch (PackageManager.NameNotFoundException ignored) {}
            MediaMetadata md = c.getMetadata();
            if (md != null) {
                String title = md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE);
                if (title == null) title = md.getString(MediaMetadata.METADATA_KEY_TITLE);
                if (title != null) out.putString("title", title);
                out.putLong("dur", md.getLong(MediaMetadata.METADATA_KEY_DURATION));
            }
            if (s != null) {
                out.putLong("pos", s.getPosition());
                out.putFloat("speed", s.getPlaybackSpeed());
                out.putInt("state", s.getState());
                out.putLong("actions", s.getActions());
            }
        }
        out.putBoolean("playing", playing);
        out.putBoolean("musicActive", music);
    }

    boolean playing() {
        Bundle b = new Bundle();
        state(b);
        return b.getBoolean("playing");
    }

    /** Transport via MediaController; returns false if no session accepts it (caller may fall back to a key). */
    boolean media(String action) {
        MediaController c = current();
        if (c == null) return false;
        MediaController.TransportControls t = c.getTransportControls();
        PlaybackState s = c.getPlaybackState();
        long pos = s == null ? 0 : s.getPosition();
        switch (action) {
            case "toggle":
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) t.pause(); else t.play();
                return true;
            case "play": t.play(); return true;
            case "pause": t.pause(); return true;
            case "next": t.skipToNext(); return true;
            case "prev": t.skipToPrevious(); return true;
            case "ff": t.seekTo(pos + 10_000); return true;
            case "rw": t.seekTo(Math.max(0, pos - 10_000)); return true;
            default: throw new IllegalArgumentException("unknown media action " + action);
        }
    }
}
