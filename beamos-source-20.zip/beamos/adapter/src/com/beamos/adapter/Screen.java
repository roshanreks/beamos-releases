package com.beamos.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.hardware.input.InputManager;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;
import android.view.WindowManager;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;

/**
 * Live View: screen capture (SurfaceControl.screenshot, system uid) and touch injection.
 * Protected (DRM) layers appear black in captures by design; they still play on the wall.
 */
final class Screen {
    private final Context ctx;
    private final InputManager im;
    private Method shot, inject;

    Screen(Context ctx) {
        this.ctx = ctx;
        this.im = (InputManager) ctx.getSystemService(Context.INPUT_SERVICE);
    }

    private int[] size() {
        DisplayMetrics m = new DisplayMetrics();
        ((WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(m);
        return new int[]{m.widthPixels, m.heightPixels};
    }

    /** JPEG of the current screen, scaled to width w (160..1920), quality 30..90. */
    byte[] capture(int w, int quality) throws Exception {
        int[] s = size();
        w = Math.max(160, Math.min(s[0], w));
        int h = Math.round(w * s[1] / (float) s[0]);
        if (shot == null) {
            shot = Class.forName("android.view.SurfaceControl").getMethod("screenshot", Rect.class, int.class, int.class, int.class);
        }
        Bitmap b = (Bitmap) shot.invoke(null, new Rect(0, 0, s[0], s[1]), w, h, 0);
        if (b == null) throw new IllegalStateException("screenshot returned null");
        Bitmap sw = b.getConfig() == Bitmap.Config.HARDWARE ? b.copy(Bitmap.Config.ARGB_8888, false) : b;
        ByteArrayOutputStream out = new ByteArrayOutputStream(64 * 1024);
        sw.compress(Bitmap.CompressFormat.JPEG, Math.max(30, Math.min(90, quality)), out);
        if (sw != b) sw.recycle();
        b.recycle();
        return out.toByteArray();
    }

    private void injectEvent(InputEvent e) throws Exception {
        if (inject == null) inject = InputManager.class.getMethod("injectInputEvent", InputEvent.class, int.class);
        inject.invoke(im, e, 0);
    }

    private void motion(long down, int action, float x, float y) throws Exception {
        MotionEvent e = MotionEvent.obtain(down, SystemClock.uptimeMillis(), action, x, y, 0);
        e.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        try { injectEvent(e); } finally { e.recycle(); }
    }

    /** Tap or swipe at normalised coordinates (0..1). Swipe if (x2,y2) differs; duration 50..2000 ms. */
    void touch(float x, float y, float x2, float y2, int durMs) throws Exception {
        int[] s = size();
        float ax = clamp(x) * (s[0] - 1), ay = clamp(y) * (s[1] - 1);
        float bx = clamp(x2) * (s[0] - 1), by = clamp(y2) * (s[1] - 1);
        long down = SystemClock.uptimeMillis();
        motion(down, MotionEvent.ACTION_DOWN, ax, ay);
        boolean swipe = Math.abs(ax - bx) > 4 || Math.abs(ay - by) > 4;
        int dur = Math.max(50, Math.min(2000, durMs));
        if (swipe) {
            int steps = Math.max(5, dur / 16);
            for (int i = 1; i <= steps; i++) {
                float t = i / (float) steps;
                motion(down, MotionEvent.ACTION_MOVE, ax + (bx - ax) * t, ay + (by - ay) * t);
                Thread.sleep(dur / steps);
            }
        } else if (dur > 400) {
            Thread.sleep(dur); // long press
        }
        motion(down, MotionEvent.ACTION_UP, swipe ? bx : ax, swipe ? by : ay);
    }

    private static float clamp(float v) {
        return Float.isNaN(v) ? 0 : Math.max(0f, Math.min(1f, v));
    }
}
