package com.beamos.common;

/**
 * Binder contract between com.beamos.studio (normal uid) and com.beamos.adapter (system uid).
 * Every call: data = Bundle of arguments, reply = Bundle with KEY_OK (boolean) and KEY_ERR (string) on failure.
 * The adapter only exposes these typed, bounded operations: no shell, no raw Binder, no arbitrary properties.
 */
public final class Contract {
    private Contract() {}

    public static final String ADAPTER_PKG = "com.beamos.adapter";
    public static final String ADAPTER_SERVICE = "com.beamos.adapter.AdapterService";
    public static final String STUDIO_PKG = "com.beamos.studio";
    public static final String DESCRIPTOR = "com.beamos.adapter.IAdapter";

    /** SHA-256 of the BeamOS release certificate (studio and modules). */
    public static final String STUDIO_CERT_SHA256 = "863209E6C7983CB38FAC3B0F5A792651577E228FB47D7399DAE79B9E424017B5";
    /** SHA-256 of the public AOSP platform test certificate (this firmware's platform key; adapter). */
    public static final String PLATFORM_CERT_SHA256 = "C8A2E9BCCF597C2FB6DC66BEE293FC13F2FC47EC77BC6B2B0D52C11F51192AB8";

    // Transaction codes
    public static final int STATE = 1;         // device + playback snapshot
    public static final int KS_GET = 10;       // -> int[] "vals", boolean "previewActive", string "previewId"
    public static final int KS_PREVIEW = 11;   // ints "vals" (8, per-mille LB,LT,RT,RB), int "secs" (5..120) -> "id"
    public static final int KS_CONFIRM = 12;   // string "id"
    public static final int KS_CANCEL = 13;    // string "id"
    public static final int AUTO_KS = 20;      // boolean "on"
    public static final int KEY = 30;          // int "code", boolean "long"
    public static final int TEXT = 31;         // string "text" (raw key injection; only on explicit request)
    public static final int LAUNCH = 40;       // string "pkg" (installed app with a launcher entry)
    public static final int OPEN = 41;         // string "target": hdmi | vendor_settings | wifi | bluetooth | sound | projection
    public static final int STORE = 42;        // string "pkg" (details page) or "query" (search) in Google Play
    public static final int GRANT_OVERLAY = 43;// lets BeamOS Studio draw the transparent guide over other apps
    public static final int INSTALL = 50;      // ParcelFileDescriptor "fd", string "pkg", string "sha256"
    public static final int LOGS = 60;         // int "lines" -> string "text"; boolean "persist" -> the on-disk ring (survives reboots)
    public static final int TRIM = 95;         // close cached background apps (never BeamOS) -> int "freedMb", int "closed"
    public static final int PKG = 96;          // string "pkg", boolean "enabled" — only the mirroring/screensaver allow-list
    public static final int SCREENSAVER = 97;  // boolean "beam": true = BeamOS screensaver, false = vendor
    public static final int PERF = 98;         // -> memory/zram/temps/top processes (strings + ints)
    public static final int SLEEP = 94;        // int "minutes" (0 = read only) -> int "minutes": screen-off timeout
    public static final int IME = 70;          // boolean "on": make the BeamOS keyboard the default
    public static final int SCREEN = 80;       // int "w", int "q" -> byte[] "jpg"
    public static final int TOUCH = 81;        // float x,y,x2,y2 (0..1), int "dur"
    public static final int PLAYBACK = 82;     // -> boolean "playing", string "pkg","title","app", long "pos","dur"
    public static final int MEDIA = 83;        // string "action": toggle|play|pause|next|prev|ff|rw -> boolean "handled"
    public static final int PIC_GET = 90;      // -> int[] "ids", int[] "vals", string "mode", int "lampMode"
    public static final int PIC_SET = 91;      // int "id", int "value" -> int "value" (clamped)
    public static final int PIC_MODE = 92;     // string "mode"
    public static final int LAMP = 93;         // int "mode": 0 standard, 1 energy saving, 2 high-bright
    public static final int PIC_APPLY = 99;    // complete bounded int[] "vals" (ids 1..13), int "lampMode" -> verified picture

    // Common keys
    public static final String KEY_OK = "ok";
    public static final String KEY_ERR = "err";

    /** Keystone insets: 0 = full frame, 500 = half the panel. Firmware clamps the same way. */
    public static final int INSET_MIN = 0;
    public static final int INSET_MAX = 500;
    public static final int PREVIEW_MIN_SECS = 5;
    public static final int PREVIEW_MAX_SECS = 120;

    /** Range and length only — what a restore of a previously accepted picture must pass. */
    public static boolean insetsInRange(int[] v) {
        if (v == null || v.length != 8) return false;
        for (int x : v) if (x < INSET_MIN || x > INSET_MAX) return false;
        return true;
    }

    /** Full check for NEW geometry: range, a visible picture, and a strictly convex quad (no darts/bow-ties). */
    public static boolean validInsets(int[] v) {
        if (!insetsInRange(v)) return false;
        if (v[2] + v[4] > 900 || v[0] + v[6] > 900 || v[3] + v[1] > 900 || v[5] + v[7] > 900) return false;
        double[][] q = {{v[2] / 1e3, v[3] / 1e3}, {1 - v[4] / 1e3, v[5] / 1e3}, {1 - v[6] / 1e3, 1 - v[7] / 1e3}, {v[0] / 1e3, 1 - v[1] / 1e3}};
        for (int i = 0; i < 4; i++) {
            double[] a = q[i], b = q[(i + 1) % 4], c = q[(i + 2) % 4];
            if ((b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]) <= 0.005) return false;
        }
        return true;
    }
}
