/* Local camera viewer. Only the native LiDAR publisher controls geometry; any paired remote may watch. */
(() => {
  const status=document.querySelector('#cameraStatus'),image=document.querySelector('#cameraFrame'),metrics=document.querySelector('#cameraMetrics'),stop=document.querySelector('#cameraStop');
  const overlay=document.querySelector('#cameraOverlay');
  let busy=false,url=null,lastSequence=-1;
  function draw(e,ready){
    overlay.replaceChildren();
    if(Array.isArray(e.screenQuad)&&e.screenQuad.length===4){const p=document.createElementNS('http://www.w3.org/2000/svg','polygon');p.setAttribute('points',e.screenQuad.map(q=>q.join(',')).join(' '));p.setAttribute('fill','none');p.setAttribute('stroke',ready?'#c7f36b':'#ffd166');p.setAttribute('stroke-width','0.004');overlay.appendChild(p);}
    for(const point of Array.isArray(e.excluded)?e.excluded.slice(0,160):[]){const p=document.createElementNS('http://www.w3.org/2000/svg','circle');p.setAttribute('cx',point[0]);p.setAttribute('cy',point[1]);p.setAttribute('r','0.004');p.setAttribute('fill','#ff6b6b');overlay.appendChild(p);}
  }
  function clear(){overlay.replaceChildren();image.classList.add('hidden');image.removeAttribute('src');if(url)URL.revokeObjectURL(url);url=null;lastSequence=-1;}
  async function poll(){
    if(busy)return;
    if(!token || tab!=='picture' || document.hidden){clear();return;}
    busy=true;
    try {
      const state=await api('/api/calibration');stop.disabled=!state.live;
      status.style.color=state.geometryReady?'var(--accent)':'var(--muted)';
      status.textContent=state.geometryReady?'Live measurements meet the alignment tolerance':state.live?'Camera connected — scanning or correcting':'No live camera. Start a scan in the iPhone companion.';
      const e=state.evidence||{};
      metrics.textContent=state.live?`${Number(e.markers)||0}/4 markers · ${e.maxErrorMm>=0?Number(e.maxErrorMm).toFixed(1)+' mm estimated corner error':'measuring corners'} · ${e.obstaclesChecked?'clear area verified':'checking clear area'}`:'Your saved alignment stays in place when the camera disconnects.';
      if(!state.frameAvailable){clear();return;}
      if(state.sequence!==lastSequence){
        const response=await fetch('/api/calibration/frame?sequence='+state.sequence,{headers:{'X-Beam-Token':token},cache:'no-store'});
        if(!response.ok)throw new Error('Camera frame expired');
        const blob=await response.blob();if(tab!=='picture'||document.hidden){clear();return;}
        const next=URL.createObjectURL(blob),old=url;url=next;image.src=next;image.classList.remove('hidden');if(old)URL.revokeObjectURL(old);lastSequence=state.sequence;draw(e,state.geometryReady);
      }
    }catch(error){status.textContent='Camera feedback unavailable: '+error.message;status.style.color='var(--muted)';metrics.textContent='';stop.disabled=true;clear();}
    finally{busy=false;}
  }
  stop.onclick=()=>safe(api('/api/calibration/stop',{}).then(poll));
  document.addEventListener('visibilitychange',()=>{if(document.hidden)clear();else poll()});
  setInterval(poll,750);poll();
})();
