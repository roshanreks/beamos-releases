/* Coded calibration photo reader. Runs locally; camera photos are not uploaded for detection. */
(function(root){
  "use strict";
  function parseBeamCode(text){
    const m=/^BEAM1:(TL|TR|BR|BL):([0-9a-z]{16}):(\d{3,4})x(\d{3,4})$/.exec(text||"");if(!m)return null;
    const vals=m[2].match(/../g).map(x=>parseInt(x,36)),width=+m[3],height=+m[4];
    if(vals.some(x=>x>500)||width<320||height<240||width>7680||height>4320)return null;
    return {id:m[1],vals,width,height,key:m[2]+":"+width+"x"+height};
  }
  function projectiveCentre(q){
    const [a,b,c,d]=q,ux=c.x-a.x,uy=c.y-a.y,vx=d.x-b.x,vy=d.y-b.y,det=ux*vy-uy*vx;
    if(!Number.isFinite(det)||Math.abs(det)<1e-7)throw new Error("A photo code is too small or folded; retake it closer");
    const t=((b.x-a.x)*vy-(b.y-a.y)*vx)/det;return [a.x+t*ux,a.y+t*uy];
  }
  async function readBeamCodes(canvas){
    const W=canvas.width,H=canvas.height,pixels=canvas.getContext("2d").getImageData(0,0,W,H).data;
    const found=[];
    const rw=Math.ceil(W*.62),rh=Math.ceil(H*.62),regions=[[0,0,W,H],[0,0,rw,rh],[W-rw,0,rw,rh],[W-rw,H-rh,rw,rh],[0,H-rh,rw,rh]];
    for(const [rx,ry,cw,ch] of regions)for(let attempt=0;attempt<4;attempt++){
      const crop=new Uint8ClampedArray(cw*ch*4);for(let y=0;y<ch;y++)crop.set(pixels.subarray(((ry+y)*W+rx)*4,((ry+y)*W+rx+cw)*4),y*cw*4);
      const qr=root.jsQR(crop,cw,ch,{inversionAttempts:"dontInvert"});if(!qr)break;
      const p=qr.location,q=[p.topLeftCorner,p.topRightCorner,p.bottomRightCorner,p.bottomLeftCorner].map(p=>({x:p.x+rx,y:p.y+ry}));
      const code=parseBeamCode(qr.data);if(code)found.push({...code,centre:projectiveCentre(q)});
      const x0=Math.max(0,Math.floor(Math.min(...q.map(p=>p.x)))-8),x1=Math.min(W-1,Math.ceil(Math.max(...q.map(p=>p.x)))+8);
      const y0=Math.max(0,Math.floor(Math.min(...q.map(p=>p.y)))-8),y1=Math.min(H-1,Math.ceil(Math.max(...q.map(p=>p.y)))+8);
      for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){const i=(y*W+x)*4;pixels[i]=pixels[i+1]=pixels[i+2]=pixels[i+3]=255;}
      await new Promise(resolve=>setTimeout(resolve,0));
    }
    return found;
  }
  function codedPhotoQuad(codes,homography,hap){
    if(!codes.length)return null;
    const ids=["TL","TR","BR","BL"],first=codes[0];
    if(codes.length!==4||ids.some(id=>codes.filter(c=>c.id===id).length!==1))throw new Error("Only "+new Set(codes.map(c=>c.id)).size+" of 4 photo codes were read. Include all four codes and retake the photo.");
    if(codes.some(c=>c.key!==first.key))throw new Error("Picture changed during the photo. Hold still and take another photo.");
    const size=Math.round(first.height*.18),margin=Math.round(first.height*.015),x=(margin+size/2)/first.width,y=(margin+size/2)/first.height;
    const centres=[[x,y],[1-x,y],[1-x,1-y],[x,1-y]],measured=ids.map(id=>codes.find(c=>c.id===id).centre);
    const transform=homography(centres,measured),quad=[[0,0],[1,0],[1,1],[0,1]].map(p=>hap(transform,p));
    return {quad,baseline:first.vals.slice()};
  }
  root.BeamPhotoCodes={parseBeamCode,projectiveCentre,readBeamCodes,codedPhotoQuad};
  if(typeof module!=="undefined")module.exports=root.BeamPhotoCodes;
})(typeof window!=="undefined"?window:globalThis);
