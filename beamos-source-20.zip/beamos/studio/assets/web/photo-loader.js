"use strict";
// Decode on the phone/Mac, including HEIC when the browser has no native decoder.
let beamHeicLibrary=null;
async function readBeamPhoto(file,maxSide=1400){
  if(!file||file.size>32*1024*1024)throw new Error("Choose a photo under 32 MB");
  const decode=blob=>new Promise((resolve,reject)=>{const image=new Image(),url=URL.createObjectURL(blob);image.onload=()=>{URL.revokeObjectURL(url);resolve(image);};image.onerror=()=>{URL.revokeObjectURL(url);reject(new Error("Photo format could not be decoded"));};image.src=url;});
  let image;
  try{image=await decode(file);}catch(original){
    if(!/heic|heif/i.test(file.type+" "+file.name))throw original;
    if(!beamHeicLibrary)beamHeicLibrary=new Promise((resolve,reject)=>{const script=document.createElement("script");script.src="/vendor/heic-to.js";script.onload=resolve;script.onerror=()=>reject(new Error("HEIC decoder could not load — reconnect and retry"));document.head.append(script);}).catch(e=>{beamHeicLibrary=null;throw e;});
    await beamHeicLibrary;try{image=await HeicTo({blob:file,type:"bitmap"});}catch(e){throw new Error(e?.message||String(e)||"HEIC photo could not be decoded");}
  }
  if(!image.width||!image.height||image.width*image.height>80000000){if(image.close)image.close();throw new Error("Photo dimensions are too large");}
  const scale=Math.min(1,maxSide/Math.max(image.width,image.height)),canvas=document.createElement("canvas");canvas.width=Math.max(1,Math.round(image.width*scale));canvas.height=Math.max(1,Math.round(image.height*scale));canvas.getContext("2d").drawImage(image,0,0,canvas.width,canvas.height);if(image.close)image.close();return canvas;
}
