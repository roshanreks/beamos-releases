package com.beamos.studio;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.util.Log;

import com.beamos.common.Contract;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Synchronous client for com.beamos.adapter. Never call from the UI thread. */
final class AdapterClient {
    private static final String TAG = "BeamStudio";
    private static AdapterClient instance;
    private final Context ctx;
    private volatile IBinder binder;
    private volatile CountDownLatch bound = new CountDownLatch(1);

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) { binder = b; bound.countDown(); }
        @Override public void onServiceDisconnected(ComponentName n) { binder = null; bound = new CountDownLatch(1); }
        @Override public void onBindingDied(ComponentName n) {
            binder = null;
            bound = new CountDownLatch(1);
            try { ctx.unbindService(this); } catch (Exception ignored) {}
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> { lastRebind = 0; rebind(); }, 2000);
        }
    };

    private AdapterClient(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        rebind();
    }

    static synchronized AdapterClient get(Context ctx) {
        if (instance == null) instance = new AdapterClient(ctx);
        return instance;
    }

    private long lastRebind;

    private synchronized void rebind() {
        long now = System.currentTimeMillis();
        if (now - lastRebind < 1500) return; // back-off: at most one bind attempt per 1.5 s
        lastRebind = now;
        Intent i = new Intent().setComponent(new ComponentName(Contract.ADAPTER_PKG, Contract.ADAPTER_SERVICE));
        try {
            ctx.startForegroundService(i);
        } catch (Exception e) {
            Log.w(TAG, "adapter start failed: " + e);
        }
        boolean ok = ctx.bindService(i, conn, Context.BIND_AUTO_CREATE | Context.BIND_IMPORTANT);
        if (!ok) { Log.w(TAG, "adapter not installed?"); try { ctx.unbindService(conn); } catch (Exception ignored) {} }
    }

    boolean available() {
        return binder != null;
    }

    Bundle call(int code, Bundle args) {
        Bundle out;
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            Log.w(TAG, "adapter call on the UI thread refused", new Throwable());
            out = new Bundle();
            out.putBoolean(Contract.KEY_OK, false);
            out.putString(Contract.KEY_ERR, "internal: call on UI thread");
            return out;
        }
        try {
            if (binder == null && !bound.await(3, TimeUnit.SECONDS)) {
                rebind();
                if (!bound.await(3, TimeUnit.SECONDS)) throw new IllegalStateException("BeamOS adapter not available");
            }
            Parcel data = Parcel.obtain(), reply = Parcel.obtain();
            try {
                data.writeInterfaceToken(Contract.DESCRIPTOR);
                data.writeBundle(args == null ? new Bundle() : args);
                binder.transact(code, data, reply, 0);
                out = reply.readBundle(getClass().getClassLoader());
            } finally {
                data.recycle();
                reply.recycle();
            }
        } catch (Exception e) {
            out = new Bundle();
            out.putBoolean(Contract.KEY_OK, false);
            out.putString(Contract.KEY_ERR, String.valueOf(e.getMessage()));
        }
        if (out == null) {
            out = new Bundle();
            out.putBoolean(Contract.KEY_OK, false);
            out.putString(Contract.KEY_ERR, "no reply");
        }
        return out;
    }
}
