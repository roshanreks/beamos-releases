package com.beamos.studio;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.Bundle;
import android.util.Log;

import com.beamos.common.Contract;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Control Protocol v1 over HTTP. Everything except the page, /api/hello and /api/pair needs a paired token. */
final class Api implements HttpServer.Handler {
    private static final String TAG = "BeamStudio";
    private final Context ctx;
    private final Updater updater;
    private volatile String lastUpdateLog = "";

    Api(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.updater = new Updater(this.ctx);
        CameraControl.get(this.ctx);
    }

    private static HttpServer.Response ok(JSONObject o) throws Exception {
        if (!o.has("ok")) o.put("ok", true);
        return HttpServer.Response.json(200, o.toString());
    }

    private static HttpServer.Response err(int status, String msg) {
        return HttpServer.Response.json(status, "{\"ok\":false,\"err\":\"" + Json.esc(msg) + "\"}");
    }

    private static HttpServer.Response fromAdapter(Bundle b) throws Exception {
        JSONObject o = Json.fromBundle(b);
        return HttpServer.Response.json(b.getBoolean(Contract.KEY_OK) ? 200 : 400, o.toString());
    }

    @Override
    public HttpServer.Response handle(HttpServer.Request r) throws Exception {
        String p = r.path;
        if ("GET".equals(r.method) && ("/".equals(p) || "/index.html".equals(p))) return asset("web/index.html", "text/html; charset=utf-8");
        if ("GET".equals(r.method) && "/camera-viewer.js".equals(p)) return asset("web/camera-viewer.js","application/javascript; charset=utf-8");
        if ("GET".equals(r.method) && "/photo-loader.js".equals(p)) return asset("web/photo-loader.js","application/javascript; charset=utf-8");
        if ("GET".equals(r.method) && "/photo-codes.js".equals(p)) return asset("web/photo-codes.js","application/javascript; charset=utf-8");
        if ("GET".equals(r.method) && "/vendor/jsQR.js".equals(p)) return asset("web/vendor/jsQR.js","application/javascript; charset=utf-8");
        if ("GET".equals(r.method) && "/vendor/heic-to.js".equals(p)) return asset("web/vendor/heic-to.js","application/javascript; charset=utf-8");
        if ("GET".equals(r.method) && "/manifest.json".equals(p)) return asset("web/manifest.json", "application/manifest+json");
        if ("GET".equals(r.method) && "/share".equals(p)) return asset("web/share.html", "text/html; charset=utf-8");
        if ("GET".equals(r.method) && "/receive".equals(p)) {
            if (!"127.0.0.1".equals(r.remote) || !Pairing.get(ctx).valid(r.params.get("t"))) return err(403, "local only");
            return asset("web/receive.html", "text/html; charset=utf-8");
        }
        if (!p.startsWith("/api/")) return err(404, "not found");

        // Reject cross-site requests (a page on another origin must not drive the projector).
        String origin = r.header("origin"), host = r.header("host");
        if (origin != null && host != null && !origin.endsWith("://" + host)) return err(403, "cross-origin request");

        if ("/api/hello".equals(p)) {
            JSONObject o = new JSONObject();
            o.put("name", "BeamOS").put("version", Studio.version(ctx)).put("paired", Pairing.get(ctx).valid(token(r)));
            return ok(o);
        }
        if ("/api/pair".equals(p) && "POST".equals(r.method)) {
            JSONObject in = new JSONObject(r.bodyText());
            String t = Pairing.get(ctx).pair(in.optString("code"), in.optString("name", "phone"));
            if (t == null) return err(403, "wrong or expired code");
            Studio.toast(ctx, "Paired: " + in.optString("name", "phone"));
            return ok(new JSONObject().put("token", t));
        }
        if (!Pairing.get(ctx).valid(token(r))) return err(401, "not paired");
        if(p.startsWith("/api/calibration/")&&!p.equals("/api/calibration/frame")&&!"POST".equals(r.method))return err(405,"Use POST for camera changes");
        if(p.startsWith("/api/coach/fit")&&!p.equals("/api/coach/fit/state")&&!"POST".equals(r.method))return err(405,"Use POST for fitted screen changes");

        if (p.startsWith("/api/mapping")) {
            JSONObject in = r.stream == null && r.body.length > 0 && !p.equals("/api/mapping/upload") ? new JSONObject(r.bodyText()) : new JSONObject();
            return Mapping.get(ctx).handle(r, p, in);
        }
        JSONObject in = r.body.length > 0 ? new JSONObject(r.bodyText()) : new JSONObject();
        AdapterClient a = AdapterClient.get(ctx);
        Bundle b = new Bundle();
        switch (p) {
            case "/api/state": {
                Bundle s = a.call(Contract.STATE, null);
                JSONObject o = Json.fromBundle(s);
                o.put("studioVersion", Studio.version(ctx)).put("ip", Net.lanIp()).put("adapter", s.getBoolean(Contract.KEY_OK));
                o.put("shareUrl", "https://" + Net.lanIp() + ":" + GatewayService.TLS_PORT + "/share").put("tlsFingerprint", Tls.fingerprint());
                o.put("paired", Pairing.get(ctx).count()).put("update", Updater.status).put("feed", updater.feedUrl())
                        .put("autoUpdate", AutoUpdate.enabled(ctx)).put("lastAutoUpdate", AutoUpdate.last(ctx));
                AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
                o.put("volume", am.getStreamVolume(AudioManager.STREAM_MUSIC)).put("volumeMax", am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
                return ok(o);
            }
            case "/api/key":
                b.putInt("code", in.getInt("code"));
                b.putBoolean("long", in.optBoolean("long"));
                return fromAdapter(a.call(Contract.KEY, b));
            case "/api/text":
                b.putString("text", in.getString("text"));
                return fromAdapter(a.call(Contract.TEXT, b));
            case "/api/apps": {
                JSONArray arr = new JSONArray();
                for (AppCatalog.App x : new AppCatalog(ctx).all()) {
                    arr.put(new JSONObject().put("pkg", x.pkg).put("label", x.label).put("tv", x.tv).put("system", x.system)
                            .put("hidden", x.hidden).put("streaming", x.streaming).put("fav", x.fav));
                }
                JSONArray favs = new JSONArray();
                for (String f : new AppCatalog(ctx).favourites()) favs.put(f);
                return ok(new JSONObject().put("apps", arr).put("favs", favs));
            }
            case "/api/apps/fav":                      // star / unstar (home Watch row)
                new AppCatalog(ctx).setFavourite(in.getString("pkg"), in.getBoolean("on"));
                return ok(new JSONObject());
            case "/api/apps/fav/move":
                new AppCatalog(ctx).moveFavourite(in.getString("pkg"), in.getInt("dir") < 0 ? -1 : 1);
                return ok(new JSONObject());
            case "/api/apps/favs": {                   // whole order at once
                JSONArray o = in.getJSONArray("order");
                List<String> l = new java.util.ArrayList<>();
                for (int i = 0; i < o.length(); i++) l.add(o.getString(i));
                new AppCatalog(ctx).setFavourites(l);
                return ok(new JSONObject());
            }
            case "/api/apps/hide":
                new AppCatalog(ctx).setHidden(in.getString("pkg"), in.getBoolean("hidden"));
                return ok(new JSONObject());
            case "/api/appcenter": {
                AppCatalog cat = new AppCatalog(ctx);
                JSONArray arr = new JSONArray();
                for (String[] r0 : AppCatalog.RECOMMENDED) {
                    arr.put(new JSONObject().put("name", r0[0]).put("query", r0[1]).put("pkg", r0[2]).put("installed", cat.installed(r0[2])));
                }
                return ok(new JSONObject().put("apps", arr));
            }
            case "/api/store":
                b.putString("pkg",AppCatalog.storeTarget(in.has("pkg")?in.getString("pkg"):null,in.optString("query","")));
                return fromAdapter(a.call(Contract.STORE, b));
            case "/api/picture": return ok(PicturePresets.get(ctx).read());
            case "/api/picture/set":
                JSONObject changes=in.optJSONObject("values");
                if(changes==null) changes=new JSONObject().put(Integer.toString(in.getInt("id")),in.getInt("value"));
                return ok(PicturePresets.get(ctx).setValues(changes));
            case "/api/picture/mode":
                return ok(PicturePresets.get(ctx).select(in.getString("mode")));
            case "/api/picture/lamp":
                return ok(PicturePresets.get(ctx).lamp(in.getInt("mode")));
            case "/api/picture/presets/save":
                return ok(PicturePresets.get(ctx).save(in.getString("name"),in.optString("device",""),in.optString("id","")));
            case "/api/picture/presets/delete":
                return ok(PicturePresets.get(ctx).delete(in.getString("id")));
            case "/api/update/auto":
                AutoUpdate.setEnabled(ctx, in.getBoolean("on"));
                return ok(new JSONObject().put("auto", AutoUpdate.enabled(ctx)));
            case "/api/icon": return icon(r.params.get("pkg"));
            case "/api/launch": {
                if (PlaybackPoller.playing() && !in.optBoolean("confirm")) return err(409, "This will interrupt what is playing");
                Bundle st = a.call(Contract.STATE, null);
                if (st.getLong("memAvailMb", 999) < 220) a.call(Contract.TRIM, null);   // sweep before a heavy app
                b.putString("pkg", in.getString("pkg"));
                return fromAdapter(a.call(Contract.LAUNCH, b));
            }
            case "/api/open": {
                String target = in.getString("target");
                if (!target.matches("hdmi|wifi|bluetooth|sound|projection|vendor_settings")) return err(400, "unknown target");
                if (PlaybackPoller.playing() && !in.optBoolean("confirm")) return err(409, "This will interrupt what is playing");
                b.putString("target", target);
                return fromAdapter(a.call(Contract.OPEN, b));
            }
            case "/api/media":
                b.putString("action", in.getString("action"));
                PlaybackPoller.pollSoon();
                return fromAdapter(a.call(Contract.MEDIA, b));
            case "/api/playback": return ok(PlaybackPoller.last());
            case "/api/volume": {
                AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
                if (in.has("level")) {
                    int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.max(0, Math.min(max, in.getInt("level"))), AudioManager.FLAG_SHOW_UI);
                } else if (in.optBoolean("mute")) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI);
                }
                return ok(new JSONObject().put("volume", am.getStreamVolume(AudioManager.STREAM_MUSIC)));
            }
            case "/api/keystone": return fromAdapter(a.call(Contract.KS_GET, null));
            case "/api/autokeystone":
                b.putBoolean("on", in.getBoolean("on"));
                return fromAdapter(a.call(Contract.AUTO_KS, b));
            case "/api/logs":
                b.putInt("lines", 400);
                b.putBoolean("persist", in.optBoolean("persist") || "1".equals(r.params.get("persist")));
                return fromAdapter(a.call(Contract.LOGS, b));
            case "/api/trim": return fromAdapter(a.call(Contract.TRIM, null));
            case "/api/mirror": {                       // mirroring on demand: AirPlay/EShare/Miracast only while wanted
                boolean on = in.getBoolean("on");
                for (String pkg : new String[]{"com.ecloud.eshare.server", "com.ecloud.eairplay", "com.softwinner.miracastReceiver"}) {
                    Bundle pk = new Bundle(); pk.putString("pkg", pkg); pk.putBoolean("enabled", on); a.call(Contract.PKG, pk);
                }
                ctx.getSharedPreferences("mirror", Context.MODE_PRIVATE).edit().putBoolean("on", on).apply();
                if (on) { Bundle l = new Bundle(); l.putString("pkg", "com.ecloud.eshare.server"); a.call(Contract.LAUNCH, l); }
                return ok(new JSONObject().put("mirror", on));
            }
            case "/api/screensaver/start":            // explicit: asks first when something is playing
                if (PlaybackPoller.playing() && !in.optBoolean("confirm")) return err(409, "This will interrupt what is playing");
                b.putBoolean("start", true);
                return fromAdapter(a.call(Contract.SCREENSAVER, b));
            case "/api/screensaver":
                b.putBoolean("beam", in.getBoolean("beam"));
                Bundle sr = a.call(Contract.SCREENSAVER, b);
                Bundle pv = new Bundle(); pv.putString("pkg", "com.htc.screensaver"); pv.putBoolean("enabled", !in.getBoolean("beam")); a.call(Contract.PKG, pv);
                return fromAdapter(sr);
            case "/api/perf": return fromAdapter(a.call(Contract.PERF, null));
            case "/api/sleep":
                b.putInt("minutes", in.optInt("minutes", 0));
                return fromAdapter(a.call(Contract.SLEEP, b));
            case "/api/update/check": {
                JSONArray arr = new JSONArray();
                for (Updater.Item i : updater.check()) {
                    arr.put(new JSONObject().put("pkg", i.pkg).put("version", i.versionName).put("code", i.versionCode)
                            .put("installed", i.installedCode).put("notes", i.notes));
                }
                return ok(new JSONObject().put("updates", arr).put("status", Updater.status));
            }
            case "/api/update/install": {
                String busy = AutoUpdate.busyReason(ctx, in.optBoolean("force"));
                if (busy != null) return err(409, busy);
                final List<Updater.Item> items = updater.check();
                new Thread(() -> {
                    try { lastUpdateLog = updater.install(items); } catch (Exception e) { lastUpdateLog = "error: " + e.getMessage(); Updater.status = "failed"; }
                }, "beam-update").start();
                return ok(new JSONObject().put("started", items.size()));
            }
            case "/api/update/status": return ok(new JSONObject().put("status", Updater.status).put("log", lastUpdateLog));
            case "/api/update/feed":
                updater.setFeedUrl(in.getString("url"));
                return ok(new JSONObject().put("feed", updater.feedUrl()));
            case "/api/screen": {
                b.putInt("w", parseInt(r.params.get("w"), 960));
                b.putInt("q", parseInt(r.params.get("q"), 60));
                Bundle sc = a.call(Contract.SCREEN, b);
                if (!sc.getBoolean(Contract.KEY_OK)) return err(500, sc.getString(Contract.KEY_ERR));
                return HttpServer.Response.bytes("image/jpeg", sc.getByteArray("jpg"));
            }
            case "/api/touch":
                b.putFloat("x", (float) in.getDouble("x"));
                b.putFloat("y", (float) in.getDouble("y"));
                b.putFloat("x2", (float) in.optDouble("x2", in.getDouble("x")));
                b.putFloat("y2", (float) in.optDouble("y2", in.getDouble("y")));
                b.putInt("dur", in.optInt("dur", 60));
                return fromAdapter(a.call(Contract.TOUCH, b));
            case "/api/ime":
                b.putBoolean("on", in.getBoolean("on"));
                return fromAdapter(a.call(Contract.IME, b));
            case "/api/calibration": return ok(CameraCalibration.get().state());
            case "/api/calibration/start": return ok(CameraCalibration.get().start(in.optString("source","Camera")));
            case "/api/calibration/publish": return ok(CameraCalibration.get().publish(in,CoachSession.get(ctx).vals()));
            case "/api/calibration/preview": return ok(CameraControl.get(ctx).preview(in));
            case "/api/calibration/keep": return ok(CameraControl.get(ctx).keep(in));
            case "/api/calibration/stop": return ok(CameraCalibration.get().stop(in.optString("lease")));
            case "/api/calibration/frame": {
                HttpServer.Response image=HttpServer.Response.bytes("image/jpeg",CameraCalibration.get().image(parseInt(r.params.get("sequence"),-1)));
                image.headers.put("Cache-Control","no-store");return image;
            }
            case "/api/input/state": return ok(Typing.state());
            case "/api/input/send": return ok(Typing.send(in));
            case "/api/input/show": {
                BeamIme ime=BeamIme.active();if(ime!=null)ime.showKeyboard();return ok(Typing.state());
            }
            case "/api/coach": return ok(CoachSession.get(ctx).state());
            case "/api/coach/fit": return ok(ScreenFit.get(ctx).fit(in));
            case "/api/coach/fit/state": return ok(ScreenFit.get(ctx).state());
            case "/api/coach/fit/resize": return ok(ScreenFit.get(ctx).resize(in));
            case "/api/coach/fit/undo": return ok(ScreenFit.get(ctx).undo(in));
            case "/api/coach/preview":
                return ok(CoachSession.get(ctx).previewVerified(Json.ints(in.getJSONArray("baseline"),8), Json.ints(in.getJSONArray("vals"),8)));
            case "/api/coach/keep": {
                CoachSession coach=CoachSession.get(ctx);
                if (!java.util.Arrays.equals(coach.vals(),Json.ints(in.getJSONArray("vals"),8))) return err(409,"Alignment changed — inspect it before saving");
                if (!coach.keep()) return err(409,"Preview was not saved");
                return ok(coach.state());
            }
            case "/api/coach/cancel": {
                CoachSession coach=CoachSession.get(ctx);
                if (!java.util.Arrays.equals(coach.vals(),Json.ints(in.getJSONArray("vals"),8))) return err(409,"Alignment changed elsewhere — capture again");
                coach.revert(); return ok(coach.state());
            }
            case "/api/coach/guide": {
                CoachSession coach=CoachSession.get(ctx); coach.setGuide(in.optString("guide","corners"));
                boolean on=in.optBoolean("on",true);
                if (!GuideOverlay.get(ctx).show(on)) return err(409,"Enable BeamOS display-over-apps permission first");
                return ok(coach.state().put("guideVisible",on).put("cameraLayout",GuideOverlay.cameraLayout(ctx)));
            }

            case "/api/pairing/revoke":
                Pairing.get(ctx).revokeAll();
                return ok(new JSONObject());
            default: return err(404, "unknown api " + p);
        }
    }

    private static int parseInt(String s, int def) {
        try { return s == null ? def : Integer.parseInt(s); } catch (NumberFormatException e) { return def; }
    }

    private static String token(HttpServer.Request r) {
        String t = r.header("x-beam-token");
        return t != null ? t : r.params.get("t");
    }

    private HttpServer.Response asset(String path, String type) throws Exception {
        try (InputStream in = ctx.getAssets().open(path)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return HttpServer.Response.bytes(type, out.toByteArray());
        }
    }

    private HttpServer.Response icon(String pkg) throws Exception {
        if (pkg == null) return err(400, "pkg");
        Drawable d = ctx.getPackageManager().getApplicationIcon(pkg);
        Bitmap bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        d.setBounds(0, 0, 96, 96);
        d.draw(c);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        HttpServer.Response res = HttpServer.Response.bytes("image/png", out.toByteArray());
        res.headers.put("Cache-Control", "max-age=86400");
        Log.d(TAG, "icon " + pkg);
        return res;
    }
}
