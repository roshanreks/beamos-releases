package com.beamos.studio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Which apps BeamOS shows, and how. TV apps (built for a remote) come first; phone-style apps are marked so the
 * phone's Live View can be used; duplicates and vendor tools are hidden by default (owner can unhide any app).
 */
final class AppCatalog {
    static final class App {
        String pkg, label;
        boolean tv, system, hidden, streaming, fav;
    }

    /** Phone versions hidden when the TV version of the same service is installed. */
    private static final String[][] DUPLICATES = {
            {"com.google.android.youtube", "com.google.android.youtube.tv"},
            {"com.netflix.mediaclient", "com.netflix.ninja"},
    };

    /** Hidden by default: vendor launcher/settings (BeamOS replaces them) and rarely used extras. */
    private static final String[] HIDDEN_BY_DEFAULT = {
            "com.htc.htclauncherhighenglishd08", "com.htc.htcsettings", "com.android.music", "com.mobisystems.office",
            "com.android.tv.settings",
    };

    /** Streaming/TV services shown in the home "Watch" row (any matching installed package). */
    static final String[][] STREAMING = {
            {"YouTube", "com.google.android.youtube.tv"},
            {"Crunchyroll", "com.crunchyroll.crunchyroid"},
            {"Netflix", "com.netflix.ninja"},
            {"Prime Video", "com.amazon.amazonvideo.livingroom", "com.amazon.avod.thirdpartyclient"},
            {"JioHotstar", "in.startv.hotstar.dplus.tv", "in.startv.hotstar"},
            {"ZEE5", "com.graymatrix.did"},
            {"SonyLIV", "com.sonyliv"},
            {"Spotify", "com.spotify.tv.android", "com.spotify.music"},
            {"VLC", "org.videolan.vlc"},
            {"Kodi", "org.xbmc.kodi"},
            {"Plex", "com.plexapp.android"},
    };

    /** App Center: recommended services; "query" opens the Play Store search on the projector. */
    static final String[][] RECOMMENDED = {
            {"YouTube for Android TV", "YouTube for Android TV", "com.google.android.youtube.tv"},
            {"Netflix (TV)", "Netflix", "com.netflix.ninja"},
            {"Crunchyroll (TV)", "Crunchyroll", "com.crunchyroll.crunchyroid"},
            {"Prime Video (TV)", "Prime Video Android TV", "com.amazon.amazonvideo.livingroom"},
            {"JioHotstar", "JioHotstar", "in.startv.hotstar"},
            {"ZEE5", "ZEE5", "com.graymatrix.did"},
            {"SonyLIV", "SonyLIV", "com.sonyliv"},
            {"Spotify (TV)", "Spotify Android TV", "com.spotify.tv.android"},
            {"VLC (plays any file)", "VLC", "org.videolan.vlc"},
            {"Kodi (media centre)", "Kodi", "org.xbmc.kodi"},
            {"Plex", "Plex", "com.plexapp.android"},
    };

    /** Projector tools checked separately from Leanback streaming apps. */
    private static boolean remoteUtility(String pkg) {
        return "com.softwinner.TvdFileManager".equals(pkg) || "com.softwinner.miracastReceiver".equals(pkg)
                || "com.htc.htcsettings".equals(pkg);
    }
    static String storeTarget(String pkg,String query) {
        for(String[] app:RECOMMENDED)if(app[2].equals(pkg) || (pkg==null&&app[1].equals(query)))return app[2];
        throw new IllegalArgumentException("Choose an approved TV app from App Center");
    }

    private final Context ctx;
    private final SharedPreferences sp;

    AppCatalog(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.sp = this.ctx.getSharedPreferences("apps", Context.MODE_PRIVATE);
    }

    private Set<String> userHidden() { return new HashSet<>(sp.getStringSet("hidden", new HashSet<>())); }
    private Set<String> userShown() { return new HashSet<>(sp.getStringSet("shown", new HashSet<>())); }

    /** The owner's ordered favourites (home "Watch" row). Empty = BeamOS picks the installed streaming services. */
    List<String> favourites() {
        List<String> out = new ArrayList<>();
        String raw = sp.getString("favs", "");
        for (String p : raw.split(",")) if (!p.isEmpty()) out.add(p);
        return out;
    }

    void setFavourites(List<String> pkgs) {
        StringBuilder sb = new StringBuilder();
        Set<String> seen = new HashSet<>();
        for (String p : pkgs) if (p != null && !p.contains(",") && seen.add(p)) { if (sb.length() > 0) sb.append(','); sb.append(p); }
        sp.edit().putString("favs", sb.toString()).apply();
    }

    boolean isFavourite(String pkg) { return favourites().contains(pkg); }

    void setFavourite(String pkg, boolean on) {
        List<String> f = favourites();
        f.remove(pkg);
        if (on) f.add(pkg);
        setFavourites(f);
    }

    /** Moves a favourite one step left (-1) or right (+1). */
    void moveFavourite(String pkg, int dir) {
        List<String> f = favourites();
        int i = f.indexOf(pkg);
        int j = i + dir;
        if (i < 0 || j < 0 || j >= f.size()) return;
        Collections.swap(f, i, j);
        setFavourites(f);
    }

    void setHidden(String pkg, boolean hidden) {
        Set<String> h = userHidden(), s = userShown();
        if (hidden) { h.add(pkg); s.remove(pkg); } else { h.remove(pkg); s.add(pkg); }
        sp.edit().putStringSet("hidden", h).putStringSet("shown", s).apply();
    }

    boolean installed(String pkg) {
        try { ctx.getPackageManager().getApplicationInfo(pkg, 0); return true; } catch (PackageManager.NameNotFoundException e) { return false; }
    }

    private boolean defaultHidden(String pkg) {
        for (String h : HIDDEN_BY_DEFAULT) if (h.equals(pkg)) return true;
        for (String[] d : DUPLICATES) if (d[0].equals(pkg) && installed(d[1])) return true;
        return false;
    }

    boolean isHidden(String pkg) {
        if (userShown().contains(pkg)) return false;
        return userHidden().contains(pkg) || defaultHidden(pkg);
    }

    static boolean isStreaming(String pkg) {
        for (String[] s : STREAMING) for (int i = 1; i < s.length; i++) if (s[i].equals(pkg)) return true;
        return false;
    }

    /** All launchable apps except BeamOS itself; TV apps first, then alphabetical. */
    List<App> all() {
        PackageManager pm = ctx.getPackageManager();
        Set<String> tv = new HashSet<>();
        for (ResolveInfo ri : pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)) {
            tv.add(ri.activityInfo.packageName);
        }
        Set<String> seen = new HashSet<>();
        List<String> favs = favourites();
        List<App> out = new ArrayList<>();
        for (String cat : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            for (ResolveInfo ri : pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(ctx.getPackageName()) || !seen.add(pkg)) continue;
                App a = new App();
                a.pkg = pkg;
                a.label = String.valueOf(ri.activityInfo.applicationInfo.loadLabel(pm));
                a.tv = tv.contains(pkg);
                if(!a.tv && !remoteUtility(pkg))continue; // phone-only apps stay out of the remote-only catalogue
                a.system = (ri.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                a.hidden = isHidden(pkg);
                a.streaming = isStreaming(pkg);
                a.fav = favs.contains(pkg);
                out.add(a);
            }
        }
        Collections.sort(out, (x, y) -> {
            if (x.tv != y.tv) return x.tv ? -1 : 1;
            return x.label.compareToIgnoreCase(y.label);
        });
        return out;
    }

    /** Home "Watch" row: the owner's favourites in their order; until they pick any, the best installed streaming apps. */
    List<App> watchRow() {
        List<App> all = all();
        List<App> row = new ArrayList<>();
        List<String> favs = favourites();
        if (!favs.isEmpty()) {
            for (String p : favs) for (App a : all) if (a.pkg.equals(p) && !a.hidden) { row.add(a); break; }
            return row;
        }
        for (String[] s : STREAMING) {
            for (int i = 1; i < s.length; i++) {
                App hit = null;
                for (App a : all) if (a.pkg.equals(s[i]) && !a.hidden) { hit = a; break; }
                if (hit != null) { hit.label = s[0]; row.add(hit); break; }
            }
        }
        return row;
    }

    Intent launchIntent(String pkg) {
        PackageManager pm = ctx.getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        return i == null ? null : i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    }
}
