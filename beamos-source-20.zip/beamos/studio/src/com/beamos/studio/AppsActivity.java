package com.beamos.studio;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** All launchable apps (TV and phone-style), user apps first, alphabetical. */
public class AppsActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        Ui.applyBackground(sv);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 36);
        root.setPadding(pad, Ui.dp(this, 24), pad, pad);
        root.addView(Ui.text(this, "Apps", 28, Ui.TEXT, true));
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(5);
        grid.setClipChildren(false);
        root.addView(grid);
        sv.addView(root);
        setContentView(sv);

        PackageManager pm = getPackageManager();
        AppCatalog cat = new AppCatalog(this);
        int i = 0;
        for (AppCatalog.App a : cat.all()) {
            if (a.hidden) continue;
            final String pkg = a.pkg;
            android.graphics.drawable.Drawable icon = null;
            try { icon = pm.getApplicationIcon(pkg); } catch (Exception ignored) {}
            grid.addView(Ui.tile(this, a.label, a.tv ? "TV app" : "phone-style", Ui.TILE_COLORS[i++ % Ui.TILE_COLORS.length], 160, 100, icon, () -> {
                Intent li = cat.launchIntent(pkg);
                if (li != null) startActivity(li);
            }));
        }
        if (grid.getChildCount() > 0) grid.getChildAt(0).requestFocus();
    }
}
