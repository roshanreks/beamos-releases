package com.beamos.studio;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Automatic updates: checks the signed feed shortly after start and every 5 minutes. Installs immediately when the
 * projector is idle; while something is playing it waits (an install compiles the apps and can stutter video),
 * at most 10 minutes, and never while a picture edit is unsaved or the phone keyboard is in use.
 */
final class AutoUpdate {
    private static final long FIRST_DELAY = 45_000L, PERIOD = 5 * 60_000L, MAX_WAIT_WHILE_PLAYING = 10 * 60_000L;
    private static Handler handler;
    private static final AtomicBoolean running = new AtomicBoolean();
    private static long waitingSince;

    private AutoUpdate() {}

    static boolean enabled(Context c) {
        return c.getSharedPreferences("updates", Context.MODE_PRIVATE).getBoolean("auto", true);
    }

    static void setEnabled(Context c, boolean on) {
        c.getSharedPreferences("updates", Context.MODE_PRIVATE).edit().putBoolean("auto", on).apply();
    }

    static String last(Context c) {
        return c.getSharedPreferences("updates", Context.MODE_PRIVATE).getString("last", "");
    }

    static synchronized void start(Context ctx) {
        if (handler != null) return;
        final Context app = ctx.getApplicationContext();
        handler = new Handler(Looper.getMainLooper());
        Runnable tick = new Runnable() {
            @Override public void run() {
                new Thread(() -> runOnce(app, false), "beam-autoupdate").start();
                handler.postDelayed(this, PERIOD);
            }
        };
        handler.postDelayed(tick, FIRST_DELAY);
    }

    /** Why an install must wait right now, or null if it may proceed. */
    static String busyReason(Context ctx, boolean force) {
        if (CoachSession.get(ctx).dirty()) return "picture edit in progress";
        if (MappingActivity.showing() || Mapping.get(ctx).calibrating()) return "mapping output in use";
        if (CameraCalibration.get().live()) return "live camera calibration in progress";
        if (BeamIme.active() != null) return "typing in progress";
        if (!force && PlaybackPoller.playing()) return "video playing";
        return null;
    }

    static void runOnce(Context ctx, boolean force) {
        if (!enabled(ctx) && !force) return;
        if (!running.compareAndSet(false, true)) return;
        try {
            Updater u = new Updater(ctx);
            List<Updater.Item> items = u.check();
            if (items.isEmpty()) { waitingSince = 0; return; }
            boolean waitedLong = waitingSince != 0 && System.currentTimeMillis() - waitingSince > MAX_WAIT_WHILE_PLAYING;
            String busy = busyReason(ctx, force || waitedLong);
            if (busy != null) {
                if (waitingSince == 0) waitingSince = System.currentTimeMillis();
                Updater.status = "update ready — waiting (" + busy + ")";
                Log.i(Studio.TAG, "auto-update: " + busy + ", later");
                return;
            }
            waitingSince = 0;
            String stamp = new SimpleDateFormat("d MMM HH:mm", Locale.US).format(new Date());
            StringBuilder s = new StringBuilder(stamp).append(": ");
            for (Updater.Item i : items) s.append(i.pkg.replace("com.beamos.", "")).append(' ').append(i.versionName).append(' ');
            ctx.getSharedPreferences("updates", Context.MODE_PRIVATE).edit().putString("last", s.toString().trim()).commit();
            u.install(items);
        } catch (Exception e) {
            Log.i(Studio.TAG, "auto-update: " + e.getMessage());
        } finally {
            running.set(false);
        }
    }
}
