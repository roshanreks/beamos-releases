package com.beamos.studio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.service.dreams.DreamService;
import android.view.View;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * BeamOS screensaver: the blob canvas, a big clock, the date, and what is playing. Redraws once a minute
 * (zero CPU otherwise) and nudges the clock around slowly so no pixel burns in on the panel.
 */
public class BeamDream extends DreamService {
    private final Handler h = new Handler(Looper.getMainLooper());
    private Face face;
    private final Runnable tick = new Runnable() {
        @Override public void run() { if (face != null) face.invalidate(); h.postDelayed(this, 60_000); }
    };

    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setInteractive(false);
        setFullscreen(true);
        setScreenBright(false);
        face = new Face(this);
        setContentView(face);
    }

    @Override
    public void onDreamingStarted() {
        super.onDreamingStarted();
        h.post(tick);
    }

    @Override
    public void onDreamingStopped() {
        h.removeCallbacks(tick);
        super.onDreamingStopped();
    }

    static final class Face extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int shift;

        Face(Context c) {
            super(c);
            setBackground(Ui.blobBackground(c, 1920, 1080));
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), hgt = getHeight();
            shift = (shift + 7) % 60;                               // slow drift against burn-in
            int cx = w / 2 + shift - 30, cy = hgt / 2 + (shift % 23) - 11;
            p.setColor(Color.WHITE);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(hgt * 0.26f);
            p.setFakeBoldText(true);
            p.setShadowLayer(24, 0, 8, Color.argb(160, 0, 0, 0));
            c.drawText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()), cx, cy + hgt * 0.08f, p);
            p.setFakeBoldText(false);
            p.setTextSize(hgt * 0.045f);
            p.setColor(Color.argb(220, 255, 255, 255));
            c.drawText(new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date()), cx, cy + hgt * 0.16f, p);
            JSONObject pb = PlaybackPoller.last();
            String title = pb.optString("title", "");
            if (!title.isEmpty()) {
                p.setTextSize(hgt * 0.035f);
                p.setColor(Color.argb(200, 255, 255, 255));
                c.drawText((pb.optBoolean("playing") ? "▶  " : "⏸  ") + title, cx, hgt - hgt * 0.08f, p);
            }
        }
    }
}
