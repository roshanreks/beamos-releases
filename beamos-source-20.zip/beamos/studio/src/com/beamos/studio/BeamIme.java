package com.beamos.studio;

import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * BeamOS keyboard. When any text box on the projector gets focus, connected phones are told immediately and can
 * type (incl. dictation, Hindi, emoji) straight into it. The on-screen bar offers the regular keyboard for the
 * IR remote. Password text is never sent back to phones or logged.
 */
public class BeamIme extends InputMethodService {
    private static volatile BeamIme active;
    private final Handler main = new Handler(Looper.getMainLooper());
    private EditorInfo editor;
    private TextView label;
    private long fieldSequence;
    private final String instanceId=java.util.UUID.randomUUID().toString();
    private String fieldToken(){return instanceId+":"+fieldSequence;}

    static BeamIme active() { return active; }

    @Override
    public View onCreateInputView() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Ui.CARD);
        int p = Ui.dp(this, 10);
        bar.setPadding(p * 2, p, p * 2, p);
        label = Ui.text(this, "", 16, Ui.TEXT, false);
        bar.addView(label, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button kb = new Button(this);
        kb.setText("On-screen keyboard");
        kb.setOnClickListener(v -> switchToPreviousInputMethod());
        bar.addView(kb);
        updateLabel();
        return bar;
    }

    private void updateLabel() {
        if (label == null) return;
        int phones = Events.clients();
        label.setText(phones > 0 ? "📱 Type on your phone — the keyboard is waiting there" : "📱 Open BeamOS on your phone to type, or use the on-screen keyboard →");
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInput(EditorInfo info, boolean restarting) {
        super.onStartInput(info, restarting);
        boolean same = restarting && editor != null && editor.fieldId == info.fieldId
                && java.util.Objects.equals(editor.packageName,info.packageName) && editor.inputType == info.inputType;
        if (!same) fieldSequence++;
        active=this; editor=info;
        Events.publish(fieldEvent("input"));
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info,restarting);
        updateLabel(); // focus is tracked by onStartInput, even when no soft-keyboard view is shown
    }

    @Override
    public void onFinishInput() {
        String ended=fieldToken();
        super.onFinishInput();
        if(active==this) active=null;
        editor=null;
        try {Events.publish(new JSONObject().put("t","input_end").put("session",ended));}catch(Exception ignored){}
    }

    @Override
    public void onDestroy() {
        if (active == this) active = null;
        super.onDestroy();
    }

    private boolean isPassword() {
        if (editor == null) return false;
        int cls = editor.inputType & InputType.TYPE_MASK_CLASS, var = editor.inputType & InputType.TYPE_MASK_VARIATION;
        return cls == InputType.TYPE_CLASS_TEXT && (var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)
                || cls == InputType.TYPE_CLASS_NUMBER && var == InputType.TYPE_NUMBER_VARIATION_PASSWORD;
    }

    JSONObject fieldEvent(String type) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            final JSONObject[] box = {new JSONObject()};
            runOnMain(() -> { box[0] = fieldEvent(type); return true; });
            return box[0];
        }
        JSONObject o = new JSONObject();
        try {
            o.put("t", type).put("session",fieldToken()).put("active",editor!=null);
            if (editor != null && "input".equals(type)) {
                int cls = editor.inputType & InputType.TYPE_MASK_CLASS;
                int var = editor.inputType & InputType.TYPE_MASK_VARIATION;
                String kind = isPassword() ? "password" : cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE ? "number"
                        : var == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS || var == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ? "email"
                        : var == InputType.TYPE_TEXT_VARIATION_URI ? "url" : "text";
                int action = editor.imeOptions & EditorInfo.IME_MASK_ACTION;
                String act = action == EditorInfo.IME_ACTION_SEARCH ? "search" : action == EditorInfo.IME_ACTION_GO ? "go"
                        : action == EditorInfo.IME_ACTION_SEND ? "send" : action == EditorInfo.IME_ACTION_NEXT ? "next" : "done";
                o.put("kind", kind).put("action", act).put("app", editor.packageName)
                        .put("hint", editor.hintText == null ? "" : editor.hintText.toString());
                boolean code = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE;
                o.put("code",code).put("sensitive",isPassword()||code);
                if (!isPassword() && !code) o.put("text", currentText());
            }
        } catch (Exception ignored) {}
        return o;
    }

    private String currentText() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return "";
        ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
        return et == null || et.text == null ? "" : et.text.toString();
    }

    private boolean matches(String session) {return editor!=null && (session==null || session.isEmpty() || session.equals(fieldToken()));}

    boolean write(String session,String value,boolean replace) {
        if(value.length()>8192)throw new IllegalArgumentException("Keep text under 8192 characters");
        return runOnMain(() -> {
            if(!matches(session))return false;
            return replace?setText(value):commit(value);
        });
    }

    /** Re-query the real InputConnection after each auto-advancing OTP digit. */
    boolean code(String session,String value) {
        try {return CodeEntry.send(new CodeEntry.Host(){
            public CodeEntry.Field field(){
                final CodeEntry.Field[] result={null};
                runOnMain(()->{if(editor==null)return false;int cls=editor.inputType&InputType.TYPE_MASK_CLASS;
                    InputConnection ic=getCurrentInputConnection();ExtractedText et=ic==null?null:ic.getExtractedText(new ExtractedTextRequest(),0);
                    result[0]=new CodeEntry.Field(fieldToken(),editor.packageName,cls==InputType.TYPE_CLASS_NUMBER||cls==InputType.TYPE_CLASS_PHONE,et==null||et.text==null?-1:et.text.length());return true;});return result[0];
            }
            public boolean digit(String digit,boolean replace){return runOnMain(()->replace?setText(digit):commit(digit));}
            public void settle()throws InterruptedException{Thread.sleep(70);}
        },session==null?"":session,value);}catch(InterruptedException e){Thread.currentThread().interrupt();return false;}
    }

    boolean showKeyboard() {return runOnMain(()->{if(editor==null)return false;requestShowSelf(0);return true;});}

    /** Replaces the whole field with text (runs on the IME thread). */
    boolean setText(final String text) {
        return runOnMain(() -> {
            InputConnection ic = getCurrentInputConnection();
            if (ic == null) return false;
            ic.beginBatchEdit();
            ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
            if (et != null && et.text != null) {
                ic.setSelection(0, et.text.length());
            } else {
                ic.deleteSurroundingText(10000, 10000);
            }
            boolean ok=ic.commitText(text, 1);
            ic.endBatchEdit();
            return ok;
        });
    }

    /** Inserts text at the cursor (append semantics for the Type tab). */
    boolean commit(final String text) {
        return runOnMain(() -> {
            InputConnection ic = getCurrentInputConnection();
            return ic != null && ic.commitText(text, 1);
        });
    }

    boolean action(String session) {return runOnMain(()->matches(session)&&action());}

    /** Presses the field's action (Search / Go / Done), or Enter. */
    boolean action() {
        return runOnMain(() -> {
            InputConnection ic = getCurrentInputConnection();
            if (ic == null) return false;
            int a = editor == null ? EditorInfo.IME_ACTION_NONE : editor.imeOptions & EditorInfo.IME_MASK_ACTION;
            if (a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED) {
                return ic.performEditorAction(a);
            } else {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
            }
            return true;
        });
    }

    private interface Job { boolean run(); }

    private boolean runOnMain(Job j) {
        if (Looper.myLooper() == Looper.getMainLooper()) return j.run();
        final boolean[] r = {false};
        final java.util.concurrent.atomic.AtomicBoolean cancelled = new java.util.concurrent.atomic.AtomicBoolean();
        final CountDownLatch done = new CountDownLatch(1);
        main.post(() -> { try { if (!cancelled.get()) r[0] = j.run(); } finally { done.countDown(); } });
        try { if (!done.await(2, TimeUnit.SECONDS)) cancelled.set(true); } catch (InterruptedException ignored) { cancelled.set(true); }
        return r[0];
    }
}
