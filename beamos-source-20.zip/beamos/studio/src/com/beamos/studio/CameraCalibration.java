package com.beamos.studio;

import android.graphics.BitmapFactory;
import android.os.SystemClock;
import android.util.Base64;
import java.util.UUID;
import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONObject;

/** One short-lived camera publisher, many paired viewers. Frames stay in RAM and expire with the lease. */
final class CameraCalibration {
    private static CameraCalibration instance;
    private String lease="",source="";
    private long received,sequence=-1,stableSince;
    private byte[] frame;
    private JSONObject evidence=new JSONObject();
    private int stableFrames;
    private String stableTarget="";
    private int[] stableGeometry;
    interface Clock {long millis();}
    interface OwnedAction { JSONObject run() throws Exception; }
    private Runnable onExpire=()->{};
    synchronized void onExpire(Runnable action){onExpire=action;}
    synchronized JSONObject owned(String key,OwnedAction action)throws Exception{
        expire();
        if(!fresh()||!lease.equals(key))throw new IllegalStateException("Camera lease expired — reconnect the camera");
        return action.run();
    }
    synchronized void expire(){
        if(!lease.isEmpty()&&!fresh()){lease="";frame=null;stableFrames=0;stableSince=0;onExpire.run();}
    }
    synchronized boolean hasFreshFrame(){expire();return fresh()&&frame!=null;}
    private final Clock clock;
    CameraCalibration(){this(SystemClock::elapsedRealtime);}
    CameraCalibration(Clock clock){this.clock=clock;}
    static synchronized CameraCalibration get() {if(instance==null)instance=new CameraCalibration();return instance;}
    private long now(){return clock.millis();}
    private boolean fresh(){return !lease.isEmpty() && now()-received<2500;}
    synchronized boolean live(){expire();return fresh();}
    synchronized JSONObject start(String name) throws Exception {
        expire();
        if(fresh())throw new IllegalStateException("A camera is already sharing. Stop it before switching cameras.");
        if(name.length()>64)throw new IllegalArgumentException("Camera name too long");
        lease=UUID.randomUUID().toString();source=name;received=now();sequence=-1;stableSince=0;stableFrames=0;frame=null;evidence=new JSONObject();stableTarget="";stableGeometry=null;
        return state().put("lease",lease);
    }
    synchronized JSONObject publish(JSONObject in,int[] actualGeometry) throws Exception {
        if(!fresh()||!lease.equals(in.optString("lease")))throw new IllegalStateException("Camera lease expired — reconnect the camera");
        long seq=in.getLong("sequence");if(seq<=sequence)throw new IllegalArgumentException("Stale camera frame");
        String encoded=in.getString("jpeg");if(encoded.length()>240000)throw new IllegalArgumentException("Camera frame too large");
        byte[] bytes=Base64.decode(encoded,Base64.DEFAULT);BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,opts);
        if(opts.outWidth<16||opts.outHeight<16||opts.outWidth>1280||opts.outHeight>1280||!"image/jpeg".equals(opts.outMimeType))throw new IllegalArgumentException("Use a JPEG camera frame up to 1280 px");
        JSONObject e=in.optJSONObject("evidence");if(e==null)e=new JSONObject();
        double error=e.optDouble("maxErrorMm",Double.MAX_VALUE),aspectError=e.optDouble("aspectError",Double.MAX_VALUE),confidence=e.optDouble("confidence",0),age=e.optDouble("captureAgeMs",Double.MAX_VALUE);
        String target=e.optString("targetId");if(target.length()>64)throw new IllegalArgumentException("Invalid camera target");
        int[] geometry=new int[8];JSONArray v=e.optJSONArray("vals");boolean geometryMatches=v!=null&&v.length()==8;
        if(geometryMatches){for(int i=0;i<8;i++){double d=v.optDouble(i,Double.NaN);if(!Double.isFinite(d)||d!=Math.rint(d))geometryMatches=false;else geometry[i]=(int)d;}geometryMatches=geometryMatches&&Arrays.equals(geometry,actualGeometry);}
        boolean valid=geometryMatches && !target.isEmpty() && e.optInt("markers")==4 && Double.isFinite(error)&&error>=0&&error<=5 && Double.isFinite(aspectError)&&aspectError>=0&&aspectError<=0.01 && confidence>=0.9 && confidence<=1 && age>=0&&age<750 && e.optBoolean("planeStable") && e.optBoolean("obstaclesChecked") && ("lidar".equals(e.optString("reference"))||"wall-reference".equals(e.optString("reference")));
        long n=now();if(valid && n-received<1250 && target.equals(stableTarget) && Arrays.equals(geometry,stableGeometry)){stableFrames++;}else{stableFrames=valid?1:0;stableSince=valid?n:0;}
        stableTarget=target;stableGeometry=geometry;
        evidence=new JSONObject().put("markers",e.optInt("markers")).put("maxErrorMm",Double.isFinite(error)?error:-1).put("confidence",Double.isFinite(confidence)?confidence:0).put("reference",e.optString("reference","none"))
            .put("planeStable",e.optBoolean("planeStable")).put("obstaclesChecked",e.optBoolean("obstaclesChecked")).put("aspectError",Double.isFinite(aspectError)?aspectError:-1).put("geometryMatches",geometryMatches).put("targetId",target)
            .put("screenQuad",overlayPoints(e.optJSONArray("screenQuad"),4)).put("excluded",overlayPoints(e.optJSONArray("excluded"),160))
            .put("quality",e.optJSONObject("quality")==null?new JSONObject():e.getJSONObject("quality"));
        frame=bytes;received=n;sequence=seq;return state();
    }
    synchronized JSONObject state() throws Exception {
        expire();boolean live=fresh();if(!live){frame=null;stableFrames=0;stableSince=0;}
        return new JSONObject().put("ok",true).put("live",live).put("source",source).put("sequence",sequence).put("frameAvailable",live&&frame!=null).put("frameAgeMs",received==0?-1:now()-received)
            .put("stableFrames",stableFrames).put("geometryReady",live&&frame!=null&&stableFrames>=5&&now()-stableSince>=2000).put("evidence",evidence);
    }
    private static JSONArray overlayPoints(JSONArray points,int limit)throws Exception{
        JSONArray safe=new JSONArray();if(points==null)return safe;
        for(int i=0;i<Math.min(limit,points.length());i++){
            JSONArray p=points.optJSONArray(i);if(p==null||p.length()!=2)continue;
            double x=p.optDouble(0,Double.NaN),y=p.optDouble(1,Double.NaN);
            if(Double.isFinite(x)&&Double.isFinite(y)&&x>=-1&&x<=2&&y>=-1&&y<=2)safe.put(new JSONArray().put(x).put(y));
        }
        return safe;
    }
    synchronized byte[] image(long expected)throws Exception{if(expected>=0&&sequence!=expected)throw new IllegalStateException("Camera frame advanced; refresh status");return image();}
    synchronized byte[] image() throws Exception {if(!fresh()||frame==null)throw new IllegalStateException("No live camera frame");return frame.clone();}
    synchronized JSONObject stop(String key) throws Exception {
        if(!key.isEmpty()&&!lease.equals(key))throw new IllegalStateException("This camera no longer owns the session");
        return stop();
    }
    synchronized JSONObject stop() throws Exception {lease="";frame=null;stableFrames=0;stableSince=0;onExpire.run();return state();}
}
