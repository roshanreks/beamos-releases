package com.beamos.studio;

import android.content.Context;
import java.util.Arrays;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;

/** Camera writes are temporary, compare-and-set, and belong to an expiring camera lease. */
final class CameraControl {
    private static CameraControl instance;
    private final Context ctx;
    private final CameraCalibration camera=CameraCalibration.get();
    private String owner="";
    private int[] before;
    private CameraControl(Context ctx){
        this.ctx=ctx.getApplicationContext();
        camera.onExpire(this::rollback);
        Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"beam-camera-expiry");t.setDaemon(true);return t;})
            .scheduleWithFixedDelay(()->{try{camera.expire();}catch(Exception ignored){}},500,500,TimeUnit.MILLISECONDS);
    }
    static synchronized CameraControl get(Context ctx){if(instance==null)instance=new CameraControl(ctx);return instance;}
    private void rollback(){
        CoachSession coach=CoachSession.get(ctx);coach.cancelCameraPreview(owner);owner="";before=null;
        if("scan".equals(coach.guide())){coach.setGuide("off");GuideOverlay.get(ctx).show(false);}
    }
    JSONObject preview(JSONObject in)throws Exception{
        return camera.owned(in.optString("lease"),()->{
            if(!camera.hasFreshFrame())throw new IllegalStateException("A fresh camera measurement is required");
            CoachSession coach=CoachSession.get(ctx);
            synchronized(coach){
                if(!owner.isEmpty()&&!coach.ownsCameraPreview(owner))throw new IllegalStateException("Alignment changed elsewhere; restart the camera scan");
                if(!"scan".equals(coach.guide()))throw new IllegalStateException("Show the automatic scan grid first");
                int[] baseline=ScreenFit.readInsets(in.getJSONArray("baseline")),target=ScreenFit.readInsets(in.getJSONArray("vals"));
                for(int i=0;i<8;i++)if(Math.abs(target[i]-baseline[i])>20)throw new IllegalArgumentException("Camera correction step exceeds the bounded adjustment");
                JSONObject result=coach.previewVerified(baseline,target);
                if(owner.isEmpty())before=baseline.clone();owner=coach.cameraOwner();
                if(owner.isEmpty())throw new IllegalStateException("Camera preview was superseded");
                return result;
            }
        });
    }
    JSONObject keep(JSONObject in)throws Exception{
        return camera.owned(in.optString("lease"),()->{
            if(!camera.state().optBoolean("geometryReady"))throw new IllegalStateException("Wait for fresh stable camera verification before saving");
            CoachSession coach=CoachSession.get(ctx);
            if(!Arrays.equals(coach.vals(),ScreenFit.readInsets(in.getJSONArray("vals"))))throw new IllegalStateException("Camera image is no longer current");
            // Always require an owned preview, including a no-change preview for an already aligned screen.
            JSONObject result=ScreenFit.get(ctx).ownedFit(in,owner,before);owner="";before=null;return result;
        });
    }
}
