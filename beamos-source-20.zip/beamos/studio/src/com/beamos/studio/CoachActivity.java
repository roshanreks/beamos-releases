package com.beamos.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;

import java.util.Arrays;

/**
 * Screen Coach on the wall. The guide is drawn full-frame, so the projector's own correction warps it: when every
 * grid cell is square, lines are straight/level and circles are round, the picture is 100% corrected.
 *
 * Remote: arrows move the selected corner/edge/picture · OK = next corner/edge · MENU = step size ·
 * PLAY/PAUSE = guide style · BACK = keep / revert.
 */
public class CoachActivity extends Activity {
    private Guide view;
    private CoachSession session;
    private final java.util.concurrent.ExecutorService io = java.util.concurrent.Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        session = CoachSession.get(this);
        view = new Guide(this, session, Qr.make(Net.controlUrl() + "#coach&code=" + Pairing.get(this).code(), 360));
        setContentView(view);
        view.setFocusable(true);
        view.requestFocus();
        session.setListener(() -> runOnUiThread(view::invalidate));
        io.execute(session::load);
    }

    @Override
    protected void onDestroy() {
        session.setListener(null);
        io.shutdown();
        super.onDestroy();
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        int dx = 0, dy = 0;
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_LEFT: dx = -1; break;
            case KeyEvent.KEYCODE_DPAD_RIGHT: dx = 1; break;
            case KeyEvent.KEYCODE_DPAD_UP: dy = -1; break;
            case KeyEvent.KEYCODE_DPAD_DOWN: dy = 1; break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER: session.cycleMode(); return true;
            case KeyEvent.KEYCODE_HOME: return super.onKeyDown(code, e);
            case KeyEvent.KEYCODE_MENU: session.cycleStep(); return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: session.cycleGuide(); return true;
            case KeyEvent.KEYCODE_BACK: finishWithChoice(); return true;
            default: return super.onKeyDown(code, e);
        }
        // Holding an arrow speeds up: after ~1 s of repeats use the big step.
        if (!session.loaded()) { Studio.toast(this, "Reading the current picture…"); return true; }
        final int fdx = dx, fdy = dy, st = e.getRepeatCount() > 15 ? CoachSession.STEPS[2] : 0;
        io.execute(() -> { try { session.nudge(null, fdx, fdy, st); } catch (Exception ex) { android.util.Log.w(Studio.TAG, "nudge: " + ex); } });
        return true;
    }

    private void finishWithChoice() {
        if (!session.dirty()) { finish(); return; }
        try {
            if (!session.state().optBoolean("temporary")) {
                session.io().execute(() -> {
                    boolean ok = session.keep();
                    if (ok) runOnUiThread(this::finish);
                    else Studio.toast(this, "Picture was not saved — please retry the adjustment");
                });
                return;
            }
        } catch (Exception ignored) {}
        new AlertDialog.Builder(this).setTitle("Keep this picture?")
                .setPositiveButton("Keep", (d, w) -> session.io().execute(() -> { boolean ok = session.keep(); if (!ok) Studio.toast(this, "The edit had expired — previous picture restored"); runOnUiThread(this::finish); }))
                .setNegativeButton("Revert", (d, w) -> session.io().execute(() -> { session.revert(); runOnUiThread(this::finish); }))
                .setNeutralButton("Continue", null).show();
    }

    static final class Guide extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final CoachSession s;
        private final Bitmap qr;
        /** Overlay mode: transparent, drawn on top of whatever is playing (nothing pauses). */
        private final boolean overlay;
        private Bitmap[] cameraCodes;
        private String cameraKey="";

        Guide(Context c, CoachSession s, Bitmap qr) { this(c, s, qr, false); }

        Guide(Context c, CoachSession s, Bitmap qr, boolean overlay) {
            super(c);
            this.s = s;
            this.qr = qr;
            this.overlay = overlay;
        }

        private int a(int rgb, int alphaOverlay) {
            return overlay ? Color.argb(alphaOverlay, Color.red(rgb), Color.green(rgb), Color.blue(rgb)) : rgb;
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            String guide = s.guide(), mode = s.mode();
            if (!overlay) c.drawColor(Color.BLACK);
            if ("camera".equals(guide) || "scan".equals(guide)) {
                if ("scan".equals(guide)) {
                    c.drawColor(Color.WHITE);p.setColor(Color.rgb(105,105,105));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);
                    for(int x=1;x<16;x++)c.drawLine(w*x/16f,0,w*x/16f,h,p);
                    for(int y=1;y<9;y++)c.drawLine(0,h*y/9f,w,h*y/9f,p);
                    p.setStyle(Paint.Style.FILL);
                }
                int[] v=s.vals();StringBuilder encoded=new StringBuilder();for(int x:v){String n=Integer.toString(x,36);if(n.length()<2)encoded.append('0');encoded.append(n);}
                String key=encoded+":"+w+"x"+h;
                if (cameraCodes == null || !key.equals(cameraKey)) {
                    if(cameraCodes!=null)for(Bitmap b:cameraCodes)if(b!=null)b.recycle();cameraKey=key;
                    cameraCodes=new Bitmap[4]; String[] ids={"TL","TR","BR","BL"};
                    for(int i=0;i<4;i++) cameraCodes[i]=Qr.make("BEAM1:"+ids[i]+":"+key,256,4);
                }
                int size=Math.round(h*0.18f), margin=Math.round(h*0.015f);
                int[][] at={{margin,margin},{w-margin-size,margin},{w-margin-size,h-margin-size},{margin,h-margin-size}};
                p.setFilterBitmap(false);
                for(int i=0;i<4;i++) if(cameraCodes[i]!=null) c.drawBitmap(cameraCodes[i],null,new Rect(at[i][0],at[i][1],at[i][0]+size,at[i][1]+size),p);
                return; // only the four coded corners cover the playing video
            }
            float cell = w / 16f; // 16 x 9 squares on a 16:9 panel
            if ("grid".equals(guide)) {
                p.setStyle(Paint.Style.STROKE);
                p.setColor(overlay ? Color.argb(150, 255, 255, 255) : Color.rgb(85, 85, 85));
                p.setStrokeWidth(2);
                for (int i = 1; i < 16; i++) c.drawLine(cell * i, 0, cell * i, h, p);
                for (int j = 1; j < 9; j++) c.drawLine(0, cell * j, w, cell * j, p);
                p.setColor(a(Color.rgb(70, 110, 160), 170));
                p.setPathEffect(new DashPathEffect(new float[]{18, 14}, 0));
                c.drawLine(w / 3f, 0, w / 3f, h, p);
                c.drawLine(2 * w / 3f, 0, 2 * w / 3f, h, p);
                c.drawLine(0, h / 3f, w, h / 3f, p);
                c.drawLine(0, 2 * h / 3f, w, 2 * h / 3f, p);
                p.setPathEffect(null);
                p.setColor(overlay ? Color.argb(110, 255, 255, 255) : Color.rgb(60, 60, 60));
                c.drawLine(0, 0, w, h, p);
                c.drawLine(w, 0, 0, h, p);
            }
            if ("grid".equals(guide) || "circles".equals(guide)) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(4);
                p.setColor(a(Color.rgb(199, 243, 107), 210));
                c.drawCircle(w / 2f, h / 2f, h * 0.42f, p);
                p.setStrokeWidth(3);
                p.setColor(a(Color.rgb(120, 170, 255), 200));
                float r = h * 0.16f;
                c.drawCircle(w * 0.18f, h * 0.24f, r, p);
                c.drawCircle(w * 0.82f, h * 0.24f, r, p);
                c.drawCircle(w * 0.18f, h * 0.76f, r, p);
                c.drawCircle(w * 0.82f, h * 0.76f, r, p);
                if ("circles".equals(guide)) {
                    p.setColor(Color.rgb(90, 90, 90));
                    for (float k = 0.1f; k < 0.42f; k += 0.08f) c.drawCircle(w / 2f, h / 2f, h * k, p);
                }
            }
            // centre cross + edge rulers
            p.setStyle(Paint.Style.STROKE);
            p.setColor(Color.WHITE);
            p.setStrokeWidth(4);
            c.drawLine(w / 2f - 70, h / 2f, w / 2f + 70, h / 2f, p);
            c.drawLine(w / 2f, h / 2f - 70, w / 2f, h / 2f + 70, p);
            p.setStrokeWidth(3);
            for (int i = 1; i < 32; i++) {
                float x = w * i / 32f, len = i % 2 == 0 ? 26 : 14;
                c.drawLine(x, 0, x, len, p);
                c.drawLine(x, h, x, h - len, p);
            }
            for (int j = 1; j < 18; j++) {
                float y = h * j / 18f, len = j % 2 == 0 ? 26 : 14;
                c.drawLine(0, y, len, y, p);
                c.drawLine(w, y, w - len, y, p);
            }
            // white frame border
            p.setStrokeWidth(10);
            c.drawRect(5, 5, w - 5, h - 5, p);
            // corner markers (same colours as the photo-fit flow)
            p.setStyle(Paint.Style.FILL);
            int m = (int) (cell * (overlay ? 0.6f : 1.2f));
            p.setColor(Color.RED);    c.drawRect(0, 0, m, m, p);
            p.setColor(Color.GREEN);  c.drawRect(w - m, 0, w, m, p);
            p.setColor(Color.BLUE);   c.drawRect(w - m, h - m, w, h, p);
            p.setColor(Color.YELLOW); c.drawRect(0, h - m, m, h, p);
            highlight(c, mode, w, h, m);
            // QR only when no phone is connected yet (keeps the guide clean while editing)
            if (!overlay && qr != null && Events.clients() == 0) {
                int q = h / 4;
                c.drawBitmap(qr, null, new Rect(w / 2 - q / 2, (int) (h * 0.62f), w / 2 + q / 2, (int) (h * 0.62f) + q), null);
            }
            // HUD
            if (overlay) {
                p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(30);
                p.setStyle(Paint.Style.FILL);
                String st = (s.dirty() ? "● unsaved · " : "") + "Adjusting " + label(mode) + " · step " + s.step();
                float tw = p.measureText(st) + 40;
                p.setColor(Color.argb(170, 0, 0, 0));
                c.drawRoundRect(w / 2f - tw / 2, 40, w / 2f + tw / 2, 86, 18, 18, p);
                p.setColor(Color.WHITE);
                c.drawText(st, w / 2f, 73, p);
                return;
            }
            p.setColor(Color.WHITE);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(34);
            String st = (s.dirty() ? "● unsaved  " : "") + "Adjusting " + label(mode) + " · step " + s.step() + " · guide " + s.guide();
            c.drawText(st, w / 2f, h / 2f - 110, p);
            p.setTextSize(28);
            p.setColor(Color.rgb(170, 180, 200));
            c.drawText("Arrows move · OK next corner · MENU step · ⏯ guide · BACK done · auto-saved   " + Arrays.toString(s.vals()),
                    w / 2f, h / 2f + 120, p);
        }

        private static String label(String mode) {
            switch (mode) {
                case "TL": return "top-left corner";
                case "TR": return "top-right corner";
                case "BR": return "bottom-right corner";
                case "BL": return "bottom-left corner";
                case "ALL": return "whole picture (↑↓ size, ←→ position)";
                default: return mode.toLowerCase() + " edge";
            }
        }

        private void highlight(Canvas c, String mode, int w, int h, int m) {
            p.setStyle(Paint.Style.STROKE);
            p.setColor(Color.rgb(199, 243, 107));
            p.setStrokeWidth(16);
            switch (mode) {
                case "TL": c.drawCircle(m * 0.5f, m * 0.5f, m * 0.9f, p); break;
                case "TR": c.drawCircle(w - m * 0.5f, m * 0.5f, m * 0.9f, p); break;
                case "BR": c.drawCircle(w - m * 0.5f, h - m * 0.5f, m * 0.9f, p); break;
                case "BL": c.drawCircle(m * 0.5f, h - m * 0.5f, m * 0.9f, p); break;
                case "TOP": c.drawLine(0, 10, w, 10, p); break;
                case "BOTTOM": c.drawLine(0, h - 10, w, h - 10, p); break;
                case "LEFT": c.drawLine(10, 0, 10, h, p); break;
                case "RIGHT": c.drawLine(w - 10, 0, w - 10, h, p); break;
                default: c.drawRect(10, 10, w - 10, h - 10, p);
            }
        }
    }
}
