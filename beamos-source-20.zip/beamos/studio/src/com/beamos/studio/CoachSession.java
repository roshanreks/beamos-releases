package com.beamos.studio;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;

import com.beamos.common.Contract;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The single owner of picture geometry in BeamOS. Shared by the phone/Mac (WebSocket), the projector remote
 * (CoachActivity), Settings and the wall overlay. Real-time: callers post the newest values; one applier thread
 * sends the latest pending values to the adapter (stale positions are skipped).
 *
 * Values: per-mille insets in payload order LBx,LBy,LTx,LTy,RTx,RTy,RBx,RBy (0 = full frame, 500 = half panel).
 * Ordinary adjustments are confirmed on the adapter immediately after applying, so they survive disconnects
 * and restarts. Only an explicit temporary preview (the Settings safety dialog) expires after 120 seconds.
 * The session stays in sync with the adapter: it re-reads the baseline before every new edit, adopts a pending
 * preview after a restart, and notices when the adapter's timer has reverted an abandoned edit.
 */
final class CoachSession {
    static final String[] MODES = {"TL", "TR", "BR", "BL", "TOP", "RIGHT", "BOTTOM", "LEFT", "ALL"};
    static final int[] STEPS = {1, 5, 20};
    static final String[] GUIDES = {"grid", "circles", "corners", "off", "camera", "scan"};
    static final int PREVIEW_SECS = 120;
    private static CoachSession instance;

    interface Listener { void changed(); }

    private final Context ctx;
    /** Keep/revert/load run here (process-wide, survives any socket). */
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> new Thread(r, "beam-coach-io"));
    private final Handler notifier;
    private final Deque<int[]> undo = new ArrayDeque<>();
    private int[] vals = new int[8];
    private int[] pending;
    private String previewId;
    private boolean dirty, loaded, applying, notifyPosted;
    private boolean temporary;
    private int mode = 0, stepIdx = 1, guide = 0, epoch = 0;
    private long lastPreviewAt;
    private long stateRevision, editGeneration;
    private String lastError = "";
    private Listener listener, overlayListener;
    private final Thread applier;

    private CoachSession(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        HandlerThread ht = new HandlerThread("beam-coach-notify");
        ht.start();
        notifier = new Handler(ht.getLooper());
        applier = new Thread(this::applyLoop, "beam-coach-apply");
        applier.setDaemon(true);
        applier.start();
        io.execute(this::load);
    }

    static synchronized CoachSession get(Context ctx) {
        if (instance == null) instance = new CoachSession(ctx);
        return instance;
    }

    ExecutorService io() { return io; }

    synchronized void setListener(Listener l) { listener = l; }
    synchronized void setOverlayListener(Listener l) { overlayListener = l; }

    // ---------- baseline ----------

    /** Reads the live values from the adapter and adopts a pending preview if one exists (after a restart). */
    void load() {
        if (Looper.myLooper() == Looper.getMainLooper()) { io.execute(this::load); return; }
        final long revision;
        synchronized (this) { revision = stateRevision; }
        Bundle r = AdapterClient.get(ctx).call(Contract.KS_GET, null);
        synchronized (this) {
            if (revision != stateRevision) return; // ignore an old read that completed after a newer write
            if (!r.getBoolean(Contract.KEY_OK) || r.getIntArray("vals") == null) return;
            if (dirty && (pending != null || applying)) return; // never replace an edit while its adapter call is in flight
            vals = r.getIntArray("vals");
            loaded = true;
            if (r.getBoolean("previewActive")) {
                dirty = true;
                temporary = true;
                previewId = r.getString("previewId");
                lastError = "Unsaved picture change — Keep or Revert";
                armExpiryCheck();
            } else if (dirty) {
                // The adapter's timer reverted an abandoned edit.
                dirty = false;
                previewId = null;
                undo.clear();
                lastError = "Reverted after 2 minutes without changes";
            }
        }
        changedLater();
    }

    /** Blocks until the real values were read (never on the main thread). */
    boolean ensureLoaded() {
        if (Looper.myLooper() == Looper.getMainLooper()) return loaded();
        for (int i = 0; i < 20; i++) {
            synchronized (this) { if (loaded) return true; }
            load();
            synchronized (this) { if (loaded) return true; }
            try { Thread.sleep(250); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
        }
        return false;
    }

    synchronized boolean loaded() { return loaded; }

    private void freshBaseline() {
        boolean need;
        synchronized (this) { need = !dirty; }
        if (need) load();
    }

    // ---------- editing ----------

    void set(int[] v, boolean pushUndo) {
        if (!ensureLoaded()) throw new IllegalStateException("picture values not loaded yet");
        if (pushUndo) freshBaseline();
        setLocked(v, pushUndo, false);
    }

    /** Camera/photo correction: reject stale capture geometry, then acknowledge the real adapter result. */
    JSONObject previewVerified(int[] baseline, int[] target) throws Exception {
        if (!ensureLoaded()) throw new IllegalStateException("Alignment is not loaded");
        freshBaseline();
        final long generation;
        synchronized (this) {
            if (pending != null || applying) throw new IllegalStateException("Alignment is busy — capture again");
            if (!Arrays.equals(vals, baseline)) throw new IllegalStateException("Alignment changed since this image — capture again");
            setLocked(target, true, true);generation=editGeneration;
        }
        try {
            synchronized(this){
                waitIdle();
                if (generation!=editGeneration || !lastError.isEmpty() || !Arrays.equals(vals, target) || !temporary)
                    throw new IllegalStateException(lastError.isEmpty() ? "Alignment changed during correction" : lastError);
            }
            Bundle actual = AdapterClient.get(ctx).call(Contract.KS_GET, null);
            synchronized(this){
                if(generation!=editGeneration)throw new IllegalStateException("Alignment changed during correction");
                if (!actual.getBoolean(Contract.KEY_OK) || !Arrays.equals(actual.getIntArray("vals"), target))
                    throw new IllegalStateException("Projector did not confirm all four corners");
                return state();
            }
        }catch(Exception error){
            synchronized(this){if(generation==editGeneration)cancelCameraPreview(cameraOwner());}
            throw error;
        }
    }

    // A camera may cancel only its exact preview generation, even if a later manual edit uses identical values.
    synchronized String cameraOwner() {
        return temporary && dirty && pending == null && !applying && previewId != null ? previewId + ":" + stateRevision : "";
    }
    synchronized boolean ownsCameraPreview(String owner) { return !owner.isEmpty() && owner.equals(cameraOwner()); }
    synchronized void cancelCameraPreview(String owner) { if (ownsCameraPreview(owner)) revert(); }

    /** A requested photo fit is durable before the remote reports success. No other edit can interleave Keep. */
    JSONObject applyVerified(int[] baseline,int[] target) throws Exception {
        if(!ensureLoaded())throw new IllegalStateException("Alignment is not loaded");
        synchronized(this){
            previewVerified(baseline,target);
            if(!Arrays.equals(vals,target)||!keep())throw new IllegalStateException("Fit was not saved; refresh alignment");
            return state();
        }
    }

    /** Deliberate safety preview, used only by Settings' visible Keep/Revert dialog. */
    void preview(int[] v) {
        if (!ensureLoaded()) throw new IllegalStateException("picture values not loaded yet");
        freshBaseline();
        setLocked(v, true, true);
    }

    private synchronized void setLocked(int[] v, boolean pushUndo, boolean previewOnly) {
        if (!Contract.validInsets(v)) throw new IllegalArgumentException("that shape would fold the picture");
        if (pushUndo) pushUndo();
        ++editGeneration;
        temporary = previewOnly;
        ++stateRevision;
        vals = v.clone();
        dirty = true;
        pending = vals.clone();
        notifyAll();
        changedLater();
    }

    void nudge(String modeName, int dx, int dy, int step) {
        if (!ensureLoaded()) throw new IllegalStateException("picture values not loaded yet");
        freshBaseline();
        nudgeLocked(modeName, dx, dy, step);
    }

    private synchronized void nudgeLocked(String modeName, int dx, int dy, int step) {
        int m = modeName == null ? mode : Math.max(0, Arrays.asList(MODES).indexOf(modeName));
        int s = step > 0 ? Math.min(100, step) : STEPS[stepIdx];
        int[] v = vals.clone();
        boolean single = m < 4;
        // dx>0 = right on the wall, dy>0 = down on the wall (front projection, panel not mirrored).
        switch (MODES[m]) {
            case "TL": v[2] += dx * s; v[3] += dy * s; break;
            case "TR": v[4] -= dx * s; v[5] += dy * s; break;
            case "BR": v[6] -= dx * s; v[7] -= dy * s; break;
            case "BL": v[0] += dx * s; v[1] -= dy * s; break;
            case "TOP": v[2] += dx * s; v[4] -= dx * s; v[3] += dy * s; v[5] += dy * s; break;
            case "BOTTOM": v[0] += dx * s; v[6] -= dx * s; v[1] -= dy * s; v[7] -= dy * s; break;
            case "LEFT": v[2] += dx * s; v[0] += dx * s; v[3] += dy * s; v[1] -= dy * s; break;
            case "RIGHT": v[4] -= dx * s; v[6] -= dx * s; v[5] += dy * s; v[7] -= dy * s; break;
            case "ALL":
                if (dy != 0 && dx == 0) { for (int i = 0; i < 8; i++) v[i] += dy * s; }
                else { v[2] += dx * s; v[0] += dx * s; v[4] -= dx * s; v[6] -= dx * s; }
                break;
        }
        if (single) {
            for (int i = 0; i < 8; i++) v[i] = Math.max(Contract.INSET_MIN, Math.min(Contract.INSET_MAX, v[i]));
        } else {
            // Multi-value moves stop at the limit instead of distorting (M11).
            for (int x : v) if (x < Contract.INSET_MIN || x > Contract.INSET_MAX) { changedLater(); return; }
        }
        mode = m;
        if (!Contract.validInsets(v) || Arrays.equals(v, vals)) { changedLater(); return; }
        setLocked(v, true, false);
    }

    synchronized void selectMode(String name) {
        int m = Arrays.asList(MODES).indexOf(name);
        if (m >= 0) mode = m;
        changedLater();
    }

    synchronized void cycleMode() { mode = (mode + 1) % MODES.length; changedLater(); }
    synchronized void cycleStep() { stepIdx = (stepIdx + 1) % STEPS.length; changedLater(); }

    synchronized void setStep(int s) {
        for (int i = 0; i < STEPS.length; i++) if (STEPS[i] == s) stepIdx = i;
        changedLater();
    }

    synchronized void setGuide(String g) {
        int i = Arrays.asList(GUIDES).indexOf(g);
        if (i >= 0) guide = i;
        changedLater();
    }

    synchronized void cycleGuide() { guide = (guide + 1) % GUIDES.length; changedLater(); }

    boolean undo() {
        if (!ensureLoaded()) return false;
        synchronized (this) {
            if (undo.isEmpty()) return false;
            vals = undo.pop();
            ++editGeneration;
            ++stateRevision;
            temporary = false;
            dirty = true;
            pending = vals.clone();
            notifyAll();
            changedLater();
            return true;
        }
    }

    private void pushUndo() {
        undo.push(vals.clone());
        while (undo.size() > 100) undo.removeLast();
    }

    // ---------- keep / revert ----------

    /** Makes the current picture permanent. Returns false if the edit had already expired (then resyncs). */
    boolean keep() {
        String id;
        int myEpoch;
        synchronized (this) {
            waitIdle();
            id = previewId;
            if (id == null) return loaded && !dirty && lastError.isEmpty(); // ordinary edits are already saved
            myEpoch = ++epoch;
        }
        boolean ok = false;
        if (id != null) {
            Bundle a = new Bundle();
            a.putString("id", id);
            ok = AdapterClient.get(ctx).call(Contract.KS_CONFIRM, a).getBoolean(Contract.KEY_OK);
        }
        synchronized (this) {
            previewId = null;
            dirty = false;
            temporary = false;
            undo.clear();
            lastError = ok ? "" : id == null ? "Nothing to keep" : "The edit had expired — the previous picture was restored";
            ++stateRevision;
        }
        Log.i(Studio.TAG, "keep ok=" + ok + " epoch=" + myEpoch);
        load();
        return ok;
    }

    /** Restores the picture from before this session's first change. */
    void revert() {
        String id;
        synchronized (this) {
            if (!temporary) return; // a stale safety-dialog timeout must never undo a newer saved adjustment
            pending = null;
            waitIdle();
            id = previewId;
            ++epoch;
        }
        Bundle a = new Bundle();
        a.putString("id", id);
        AdapterClient.get(ctx).call(Contract.KS_CANCEL, a);
        synchronized (this) {
            previewId = null;
            dirty = false;
            temporary = false;
            undo.clear();
            lastError = "";
            ++stateRevision;
        }
        load();
    }

    private void waitIdle() {
        while (pending != null || applying) {
            try { wait(100); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
        }
    }

    private void applyLoop() {
        while (true) {
            int[] v;
            int myEpoch;
            boolean save;
            synchronized (this) {
                while (pending == null) {
                    try { wait(); } catch (InterruptedException e) { return; }
                }
                v = pending;
                pending = null;
                applying = true;
                myEpoch = epoch;
                save = !temporary;
            }
            // Manual alignment owns the geometry until the user explicitly enables automatic keystone again.
            Bundle auto = new Bundle();
            auto.putBoolean("on", false);
            Bundle autoResult = AdapterClient.get(ctx).call(Contract.AUTO_KS, auto);
            Bundle a = new Bundle();
            a.putIntArray("vals", v);
            a.putInt("secs", PREVIEW_SECS);
            Bundle r = autoResult.getBoolean(Contract.KEY_OK)
                    ? AdapterClient.get(ctx).call(Contract.KS_PREVIEW, a) : autoResult;
            boolean saved = false;
            if (save && r.getBoolean(Contract.KEY_OK)) {
                Bundle confirm = new Bundle();
                confirm.putString("id", r.getString("id"));
                Bundle result = AdapterClient.get(ctx).call(Contract.KS_CONFIRM, confirm);
                saved = result.getBoolean(Contract.KEY_OK);
                if (!saved) { r.putBoolean(Contract.KEY_OK, false); r.putString(Contract.KEY_ERR, "Could not save picture; retry the adjustment"); }
            }
            boolean stale;
            synchronized (this) {
                applying = false;
                ++stateRevision;
                stale = myEpoch != epoch;   // a keep/revert happened while this was in flight (L2)
                if (r.getBoolean(Contract.KEY_OK)) {
                    if (!stale) {
                        previewId = saved ? null : r.getString("id");
                        lastError = "";
                        if (saved && pending == null) dirty = false;
                        if (!saved) armExpiryCheck();
                    }
                } else {
                    lastError = String.valueOf(r.getString(Contract.KEY_ERR));
                    Log.w(Studio.TAG, "preview failed: " + lastError);
                }
                notifyAll();
            }
            if (stale && r.getBoolean(Contract.KEY_OK)) {
                // The user already reverted/kept: cancel the late preview so it cannot resurface.
                Bundle c = new Bundle();
                c.putString("id", r.getString("id"));
                AdapterClient.get(ctx).call(Contract.KS_CANCEL, c);
            }
            changedLater();
        }
    }

    /** Mirrors the adapter's timer: shortly after it would have fired, re-read and resync. */
    private void armExpiryCheck() {
        final long at = lastPreviewAt = System.currentTimeMillis();
        notifier.postDelayed(() -> {
            boolean check;
            synchronized (this) { check = dirty && lastPreviewAt == at; }
            if (check) io.execute(this::load);
        }, PREVIEW_SECS * 1000L + 1500);
    }

    // ---------- state ----------

    synchronized JSONObject state() {
        JSONObject o = new JSONObject();
        try {
            JSONArray a = new JSONArray();
            for (int x : vals) a.put(x);
            o.put("t", "coach").put("vals", a).put("dirty", dirty).put("mode", MODES[mode]).put("step", STEPS[stepIdx])
                    .put("guide", GUIDES[guide]).put("undo", undo.size()).put("error", lastError).put("loaded", loaded)
                    .put("autoSave", true).put("temporary", temporary);
        } catch (Exception ignored) {}
        return o;
    }

    synchronized int[] vals() { return vals.clone(); }
    synchronized String mode() { return MODES[mode]; }
    synchronized int step() { return STEPS[stepIdx]; }
    synchronized String guide() { return GUIDES[guide]; }
    synchronized boolean dirty() { return dirty; }

    /** Trailing-edge coalescing on one notifier thread: at most ~60 notifications/s, never drops the last one. */
    private void changedLater() {
        synchronized (this) {
            if (notifyPosted) return;
            notifyPosted = true;
        }
        notifier.postDelayed(() -> {
            synchronized (this) { notifyPosted = false; }
            changed();
        }, 16);
    }

    private void changed() {
        Listener l, o;
        JSONObject s;
        synchronized (this) { l = listener; o = overlayListener; s = state(); }
        if (l != null) l.changed();
        if (o != null) o.changed();
        Events.publish(s);
    }
}
