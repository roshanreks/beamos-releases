package com.beamos.studio;

/** Testable OTP transaction. Re-reads focus after each digit so auto-advancing cells are not overwritten. */
final class CodeEntry {
    static final class Field {
        final String id,app; final boolean numeric; final int length;
        Field(String id,String app,boolean numeric,int length){this.id=id;this.app=app;this.numeric=numeric;this.length=length;}
    }
    interface Host {Field field();boolean digit(String digit,boolean replace);void settle() throws InterruptedException;}
    static boolean send(Host host,String expected,String value) throws InterruptedException {
        if(!value.matches("[0-9]{1,12}"))throw new IllegalArgumentException("Enter 1–12 code digits");
        Field first=host.field();if(first==null||!first.numeric||(!expected.isEmpty()&&!first.id.equals(expected)))return false;
        boolean split=false;
        for(int i=0;i<value.length();i++) {
            Field before=host.field();if(before==null||!before.numeric||!first.app.equals(before.app))return false;
            boolean replace=i==0||split;
            if(!host.digit(value.substring(i,i+1),replace))return false;
            host.settle();Field after=host.field();
            if(after!=null&&!before.id.equals(after.id))split=true;
            // An app can acknowledge commitText while its length filter discards the digit.
            if(i>0 && !replace && after!=null && before.id.equals(after.id) && before.length>=0 && after.length<=before.length)return false;
        }
        return true;
    }
}
