package com.beamos.studio;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

/** Tiny event bus feeding the WebSocket clients (coach state, playback, text-box events). */
final class Events {
    private static final List<LinkedBlockingQueue<String>> CLIENTS = new ArrayList<>();
    static final int MAX_CLIENTS = 6;

    private Events() {}

    /** Returns null when the room is full (the newcomer is refused; nobody gets evicted). */
    static synchronized LinkedBlockingQueue<String> subscribe() {
        if (CLIENTS.size() >= MAX_CLIENTS) return null;
        LinkedBlockingQueue<String> q = new LinkedBlockingQueue<>(200);
        CLIENTS.add(q);
        return q;
    }

    static synchronized void unsubscribe(LinkedBlockingQueue<String> q) {
        CLIENTS.remove(q);
    }

    static synchronized int clients() {
        return CLIENTS.size();
    }

    static synchronized void publish(JSONObject e) {
        String s = e.toString();
        for (LinkedBlockingQueue<String> q : CLIENTS) q.offer(s);
    }
}
