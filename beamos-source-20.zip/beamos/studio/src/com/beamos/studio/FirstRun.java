package com.beamos.studio;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import com.beamos.common.Contract;

import java.util.Arrays;

/** First start only: remember the stock keystone so "Restore picture from before BeamOS" always works. */
final class FirstRun {
    private FirstRun() {}

    static void rememberOriginalPicture(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("first_run", Context.MODE_PRIVATE);
        if (sp.contains("keystone")) return;
        for (int attempt = 0; attempt < 10; attempt++) {
            Bundle r = AdapterClient.get(ctx).call(Contract.KS_GET, null);
            if (r.getBoolean(Contract.KEY_OK) && !r.getBoolean("previewActive")) {
                sp.edit().putString("keystone", Arrays.toString(r.getIntArray("vals"))).apply();
                Log.i(Studio.TAG, "first-run picture saved " + Arrays.toString(r.getIntArray("vals")));
                return;
            }
            try { Thread.sleep(2000); } catch (InterruptedException e) { return; }
        }
    }
}
