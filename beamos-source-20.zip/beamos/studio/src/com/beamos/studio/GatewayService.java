package com.beamos.studio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

/** Foreground service hosting the LAN control gateway (phone / Mac). */
public class GatewayService extends Service {
    static final int PORT = 8080;
    static final int TLS_PORT = 8443;
    private HttpServer server;

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("gateway", "BeamOS remote", NotificationManager.IMPORTANCE_MIN));
        startForeground(1, new Notification.Builder(this, "gateway").setContentTitle("BeamOS remote")
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).build());
        AdapterClient.get(this); // bind early
        new Thread(() -> FirstRun.rememberOriginalPicture(this), "beam-firstrun").start();
        new Thread(() -> {
            for(int attempt=0;attempt<5;attempt++) {
                try { PicturePresets.get(this).restore(); return; }
                catch(Exception e) {
                    Log.w(Studio.TAG,"picture restore: "+e.getMessage());
                    try { Thread.sleep(1500); } catch(InterruptedException stopped) { return; }
                }
            }
        }, "beam-picture-restore").start();
        AutoUpdate.start(this);
        server = new HttpServer(PORT, new Api(this));
        server.setWsHandler(new WsSession(this));
        server.setHostCheck(host -> {
            String h = host.toLowerCase(java.util.Locale.ROOT);
            if (h.endsWith(":" + PORT)) h = h.substring(0, h.length() - (":" + PORT).length());
            if (h.endsWith(":" + TLS_PORT)) h = h.substring(0, h.length() - (":" + TLS_PORT).length());
            return h.equals("127.0.0.1") || h.equals("localhost") || h.equals(Net.lanIp()) || h.equals("beam.local") || h.equals("beamos.local");
        });
        PlaybackPoller.start(this);
        try {
            server.start();
        } catch (Exception e) {
            Log.e(Studio.TAG, "gateway failed to start", e);
        }
        new Thread(() -> {
            try { server.startTls(TLS_PORT, Tls.get(this)); } catch (Exception e) { Log.w(Studio.TAG, "https not started: " + e); }
        }, "beam-tls").start();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (server != null) server.stop();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
