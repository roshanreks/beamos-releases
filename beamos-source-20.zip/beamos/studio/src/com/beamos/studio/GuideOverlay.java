package com.beamos.studio;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.WindowManager;
import android.graphics.Point;
import org.json.JSONObject;

/**
 * Transparent alignment guide drawn ON TOP of whatever is playing: the app underneath keeps playing and keeps
 * focus (the overlay is not focusable/touchable). Hidden automatically after 3 minutes without changes.
 */
final class GuideOverlay {
    private static GuideOverlay instance;
    private final Context ctx;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable autoHide = () -> show(false);
    private volatile CoachActivity.Guide view;

    private GuideOverlay(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    static synchronized GuideOverlay get(Context ctx) {
        if (instance == null) instance = new GuideOverlay(ctx);
        return instance;
    }

    /** Returns false if the "display over other apps" permission is missing. */
    boolean show(boolean on) {
        if (on && !Settings.canDrawOverlays(ctx)) return false;
        if(Looper.myLooper()==Looper.getMainLooper())return showOnMain(on);
        java.util.concurrent.FutureTask<Boolean> task=new java.util.concurrent.FutureTask<>(()->showOnMain(on));
        main.post(task);
        try{return task.get(3,java.util.concurrent.TimeUnit.SECONDS);}catch(Exception e){task.cancel(false);Log.w(Studio.TAG,"overlay acknowledgement: "+e);return false;}
    }

    private boolean showOnMain(boolean on){
        WindowManager wm=(WindowManager)ctx.getSystemService(Context.WINDOW_SERVICE);
        if(on&&view==null){
            CoachSession s=CoachSession.get(ctx);view=new CoachActivity.Guide(ctx,s,null,true);
            WindowManager.LayoutParams lp=new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                |WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS|WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,PixelFormat.TRANSLUCENT);
            try{wm.addView(view,lp);s.setOverlayListener(()->main.post(()->{if(view!=null)view.invalidate();kick();}));}
            catch(Exception e){Log.w(Studio.TAG,"overlay failed: "+e);view=null;return false;}
        }else if(!on&&view!=null){
            try{wm.removeView(view);}catch(Exception ignored){}
            CoachSession.get(ctx).setOverlayListener(null);view=null;
        }
        kick();return !on||(view!=null&&view.isAttachedToWindow());
    }

    boolean showing() { return view != null; }

    static JSONObject cameraLayout(Context ctx) throws Exception {
        Point size=new Point();((WindowManager)ctx.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealSize(size);
        return new JSONObject().put("width",size.x).put("height",size.y).put("size",Math.round(size.y*0.18f)).put("margin",Math.round(size.y*0.015f));
    }

    private void kick() {
        main.removeCallbacks(autoHide);
        if (view != null) main.postDelayed(autoHide, 3 * 60 * 1000L);
    }
}
