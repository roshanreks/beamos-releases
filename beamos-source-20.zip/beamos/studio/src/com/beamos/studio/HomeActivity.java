package com.beamos.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

import com.beamos.common.Contract;

/** BeamOS home screen: big remote-friendly tiles, favourite apps, and how to connect the phone. */
public class HomeActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView status;
    private LinearLayout favRow;
    private final Runnable refresher = new Runnable() {
        @Override public void run() { refreshStatus(); ui.postDelayed(this, 20000); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Studio.startGateway(this);
        // A projector home screen never lets the device doze off (the vendor launcher did the same).
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        Ui.applyBackground(root);
        int pad = Ui.dp(this, 40);
        root.setPadding(pad, Ui.dp(this, 28), pad, Ui.dp(this, 20));
        root.setClipChildren(false);

        LinearLayout header = Ui.row(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = Ui.text(this, "BeamOS", 30, Ui.TEXT, true);
        header.addView(logo);
        TextView ver = Ui.text(this, "  v" + Studio.version(this), 14, Ui.ACCENT, false);
        header.addView(ver);
        View spacer = new View(this);
        header.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("EEE d MMM  h:mm a");
        clock.setFormat24Hour("EEE d MMM  HH:mm");
        clock.setTextColor(Ui.TEXT);
        clock.setTextSize(20);
        header.addView(clock);
        root.addView(header);

        LinearLayout main = Ui.row(this);
        main.setPadding(0, Ui.dp(this, 18), 0, 0);
        HorizontalScrollView mainScroll = new HorizontalScrollView(this);
        mainScroll.setClipChildren(false);
        mainScroll.setHorizontalScrollBarEnabled(false);
        main.addView(Ui.tile(this, "Apps", "Everything installed", Ui.TILE_COLORS[0], 160, 128, null, "📺",
                () -> startActivity(new Intent(this, AppsActivity.class))));
        main.addView(Ui.tile(this, "HDMI", "External input", Ui.TILE_COLORS[2], 125, 128, null, "🔌", () -> open("hdmi")));
        main.addView(Ui.tile(this, "Screen Coach", "Fit & straighten", Ui.TILE_COLORS[3], 160, 128, null, "🎯",
                () -> startActivity(new Intent(this, CoachActivity.class))));
        main.addView(Ui.tile(this, "Mirror", "Phone, Mac, PC", Ui.TILE_COLORS[6], 125, 128, null, "📡", this::mirror));
        main.addView(Ui.tile(this, "Phone Remote", "Scan to connect", Ui.TILE_COLORS[4], 160, 128, null, "📱", this::showPairing));
        main.addView(Ui.tile(this, "Settings", "Picture, updates", Ui.TILE_COLORS[5], 140, 128, null, "⚙️",
                () -> startActivity(new Intent(this, SettingsActivity.class))));
        main.addView(Ui.tile(this, "Bluetooth", "Speaker, headphones", Ui.TILE_COLORS[7], 125, 128, null, "🎧", () -> open("bluetooth")));
        main.addView(Ui.tile(this, "Mapping", "Light the room", Ui.TILE_COLORS[1], 125, 128, null, "🎨",
                () -> startActivity(new Intent(this, MappingActivity.class))));
        main.addView(Ui.tile(this, "Screensaver", "Hold BACK anytime", Ui.TILE_COLORS[3], 140, 128, null, "🌙", this::screensaver));
        mainScroll.addView(main);
        root.addView(mainScroll);

        root.addView(Ui.text(this, "Watch", 16, Ui.MUTED, true), withTop(18));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setClipChildren(false);
        hs.setHorizontalScrollBarEnabled(false);
        favRow = Ui.row(this);
        hs.addView(favRow);
        root.addView(hs);

        View grow = new View(this);
        root.addView(grow, new LinearLayout.LayoutParams(1, 0, 1f));
        status = Ui.text(this, "", 15, Ui.MUTED, false);
        root.addView(status);
        setContentView(root);
        main.getChildAt(0).requestFocus();
    }

    private LinearLayout.LayoutParams withTop(int dp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, dp);
        lp.leftMargin = Ui.dp(this, 10);
        return lp;
    }

    @Override
    protected void onResume() {
        super.onResume();
        buildFavourites();
        ui.post(refresher);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(refresher);
        super.onPause();
    }

    private void buildFavourites() {
        favRow.removeAllViews();
        AppCatalog cat = new AppCatalog(this);
        PackageManager pm = getPackageManager();
        int i = 0;
        for (AppCatalog.App a : cat.watchRow()) {
            final Intent li = cat.launchIntent(a.pkg);
            if (li == null) continue;
            android.graphics.drawable.Drawable icon = null;
            try { icon = pm.getApplicationIcon(a.pkg); } catch (Exception ignored) {}
            final String label = a.label, pkg = a.pkg;
            LinearLayout tile = Ui.tile(this, a.label, a.tv ? null : "phone-style · use Live View", Ui.TILE_COLORS[i++ % Ui.TILE_COLORS.length],
                    170, 110, icon, () -> {
                        try { startActivity(li); } catch (Exception e) { Studio.toast(this, "Can't open " + label); }
                    });
            tile.setOnLongClickListener(v -> { tileMenu(cat, pkg, label); return true; });   // hold OK: favourite / hide
            favRow.addView(tile);
        }
        favRow.addView(Ui.tile(this, "App Center", "Get TV apps", Ui.CARD, 160, 110,
                () -> new Thread(() -> {
                    Bundle a = new Bundle();
                    a.putString("pkg", "com.android.vending");
                    AdapterClient.get(this).call(Contract.LAUNCH, a);
                }).start()));
        favRow.addView(Ui.tile(this, "All apps", null, Ui.CARD, 140, 110, () -> startActivity(new Intent(this, AppsActivity.class))));
    }

    /** Hold OK on an app tile: move it, un-favourite it, or hide it — the row is the owner's. */
    private void tileMenu(AppCatalog cat, String pkg, String label) {
        boolean fav = cat.isFavourite(pkg);
        String[] items = fav
                ? new String[]{"Move left", "Move right", "Remove from Watch row", "Hide app"}
                : new String[]{"Add to Watch row (then reorder from the phone)", "Hide app"};
        new AlertDialog.Builder(this).setTitle(label).setItems(items, (d, which) -> {
            String pick = items[which];
            if (pick.startsWith("Move left")) cat.moveFavourite(pkg, -1);
            else if (pick.startsWith("Move right")) cat.moveFavourite(pkg, 1);
            else if (pick.startsWith("Remove")) cat.setFavourite(pkg, false);
            else if (pick.startsWith("Add")) { for (AppCatalog.App a : cat.watchRow()) if (!cat.isFavourite(a.pkg)) cat.setFavourite(a.pkg, true); cat.setFavourite(pkg, true); }
            else if (pick.startsWith("Hide")) { cat.setHidden(pkg, true); cat.setFavourite(pkg, false); Studio.toast(this, "Hidden — un-hide from the phone (Apps → Hidden)"); }
            buildFavourites();
        }).show();
    }

    private void screensaver() {
        new Thread(() -> {
            Bundle a = new Bundle();
            a.putBoolean("start", true);
            Bundle r = AdapterClient.get(this).call(Contract.SCREENSAVER, a);
            if (!r.getBoolean(Contract.KEY_OK)) Studio.toast(this, "Screensaver: " + r.getString(Contract.KEY_ERR));
        }).start();
    }

    private long lastHome;

    /** HOME while already home = pressed twice: open All apps (the only "double-tap" the launcher can see). */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastHome < 700) { lastHome = 0; startActivity(new Intent(this, AppsActivity.class)); }
        else lastHome = now;
    }

    private void refreshStatus() {
        new Thread(() -> {
            Bundle s = AdapterClient.get(this).call(Contract.STATE, null);
            String code = Pairing.get(this).code();
            String line = "Phone/Mac: open " + Net.controlUrl() + "  ·  pairing code " + code
                    + (s.getBoolean(Contract.KEY_OK)
                    ? "  ·  " + s.getString("lcdTemp", "?") + "°C  ·  " + s.getLong("memAvailMb") + " MB free"
                    : "  ·  adapter offline: " + s.getString(Contract.KEY_ERR));
            ui.post(() -> status.setText(line));
        }).start();
    }

    /** Mirroring on demand: switches the receivers on only while wanted, then opens the connect screen. */
    private void mirror() {
        Studio.toast(this, "Starting mirroring receivers…");
        CoachSession.get(this).io().execute(() -> {
            for (String pkg : new String[]{"com.ecloud.eshare.server", "com.ecloud.eairplay", "com.softwinner.miracastReceiver"}) {
                Bundle p = new Bundle(); p.putString("pkg", pkg); p.putBoolean("enabled", true);
                AdapterClient.get(this).call(Contract.PKG, p);
            }
            getSharedPreferences("mirror", MODE_PRIVATE).edit().putBoolean("on", true).apply();
            Bundle l = new Bundle(); l.putString("pkg", "com.ecloud.eshare.server");
            AdapterClient.get(this).call(Contract.LAUNCH, l);
        });
    }

    private void open(String target) {
        new Thread(() -> {
            Bundle a = new Bundle();
            a.putString("target", target);
            Bundle r = AdapterClient.get(this).call(Contract.OPEN, a);
            if (!r.getBoolean(Contract.KEY_OK)) Studio.toast(this, "Couldn't open " + target + ": " + r.getString(Contract.KEY_ERR));
        }).start();
    }

    private void showPairing() {
        String url = Net.controlUrl() + "#code=" + Pairing.get(this).code();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(Ui.dp(this, 24), Ui.dp(this, 16), Ui.dp(this, 24), Ui.dp(this, 16));
        Bitmap qr = Qr.make(url, 480);
        ImageView iv = new ImageView(this);
        iv.setImageBitmap(qr);
        box.addView(iv, new LinearLayout.LayoutParams(Ui.dp(this, 220), Ui.dp(this, 220)));
        TextView t = Ui.text(this, "Scan with your iPhone camera\nor open " + Net.controlUrl() + "\nCode: " + Pairing.get(this).code(),
                18, android.graphics.Color.BLACK, false);
        t.setGravity(Gravity.CENTER);
        box.addView(t);
        new AlertDialog.Builder(this).setTitle("Connect your phone or Mac").setView(box).setPositiveButton("Done", null).show();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {          // home has nowhere to go back to; holding BACK = screensaver
            event.startTracking();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyLongPress(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) { screensaver(); return true; }
        return super.onKeyLongPress(keyCode, event);
    }
}
