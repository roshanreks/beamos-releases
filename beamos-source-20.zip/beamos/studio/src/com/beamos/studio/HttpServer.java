package com.beamos.studio;

import android.util.Log;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Minimal HTTP/1.1 server (LAN only): one request per connection, bounded sizes and deadlines.
 * HTTP requests run on a small pool; WebSocket sessions on their own capped pool (never starve HTTP).
 * Requests whose Host header is not this projector are refused (DNS-rebinding protection).
 */
final class HttpServer {
    private static final String TAG = "BeamStudio";
    private static final int MAX_HEADER = 16 * 1024;
    private static final int MAX_BODY = 256 * 1024;
    private static final long HEADER_DEADLINE_MS = 10_000;
    static final int MAX_WS = 6;

    static final class Request {
        String method, path, query = "", remote;
        final Map<String, String> headers = new HashMap<>();
        final Map<String, String> params = new HashMap<>();
        byte[] body = new byte[0];
        /** Large uploads (STREAM_PATHS) are left on the socket: the handler copies exactly streamLen bytes from here. */
        InputStream stream;
        long streamLen;

        String header(String k) { return headers.get(k.toLowerCase(Locale.ROOT)); }
        String bodyText() { return new String(body, StandardCharsets.UTF_8); }
    }

    private static final String STREAM_PATH = "/api/mapping/upload";
    private static final long MAX_STREAM = 400L * 1024 * 1024;

    static final class Response {
        int status = 200;
        String type = "application/json; charset=utf-8";
        byte[] body = new byte[0];
        final Map<String, String> headers = new HashMap<>();

        static Response json(int status, String json) {
            Response r = new Response();
            r.status = status;
            r.body = json.getBytes(StandardCharsets.UTF_8);
            return r;
        }

        static Response bytes(String type, byte[] b) {
            Response r = new Response();
            r.type = type;
            r.body = b;
            return r;
        }
    }

    interface Handler { Response handle(Request r) throws Exception; }
    interface WsHandler { void session(Ws ws, Request r) throws Exception; }
    interface HostCheck { boolean allowed(String host); }

    private final int port;
    private final Handler handler;
    private final ExecutorService pool = Executors.newFixedThreadPool(4, r -> new Thread(r, "beam-http"));
    private final ThreadPoolExecutor wsPool = new ThreadPoolExecutor(MAX_WS, MAX_WS, 30, TimeUnit.SECONDS,
            new SynchronousQueue<>(), r -> new Thread(r, "beam-ws"));
    private WsHandler wsHandler;
    private HostCheck hostCheck = h -> true;
    private ServerSocket server;

    HttpServer(int port, Handler handler) {
        this.port = port;
        this.handler = handler;
        wsPool.allowCoreThreadTimeOut(true);
    }

    void setWsHandler(WsHandler h) { this.wsHandler = h; }
    void setHostCheck(HostCheck c) { this.hostCheck = c; }

    private ServerSocket tls;

    /** Second listener for https (self-signed): same handlers, so browsers get a secure context for screen sharing. */
    synchronized void startTls(int tlsPort, javax.net.ssl.SSLContext ctx) throws IOException {
        if (tls != null) return;
        javax.net.ssl.SSLServerSocket ss = (javax.net.ssl.SSLServerSocket) ctx.getServerSocketFactory().createServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress(InetAddress.getByName("0.0.0.0"), tlsPort), 16);
        tls = ss;
        accept(ss, "beam-accept-tls");
        Log.i(TAG, "https server on :" + tlsPort);
    }

    synchronized void start() throws IOException {
        if (server != null) return;
        final ServerSocket ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress(InetAddress.getByName("0.0.0.0"), port), 32);
        server = ss;
        accept(ss, "beam-accept");
        Log.i(TAG, "http server on :" + port);
    }

    private void accept(final ServerSocket ss, String name) {
        Thread acceptThread = new Thread(() -> {
            while (!ss.isClosed()) {
                try {
                    Socket s = ss.accept();
                    s.setSoTimeout(15000);
                    pool.execute(() -> serve(s));
                } catch (IOException e) {
                    if (!ss.isClosed()) Log.w(TAG, "accept: " + e);
                } catch (RejectedExecutionException e) {
                    break;
                }
            }
        }, name);
        acceptThread.start();
    }

    synchronized void stop() {
        ServerSocket ss = server, ts = tls;
        server = null; tls = null;
        try { if (ss != null) ss.close(); } catch (IOException ignored) {}
        try { if (ts != null) ts.close(); } catch (IOException ignored) {}
    }

    private void serve(Socket s) {
        boolean handedOff = false;
        try {
            InputStream in = new BufferedInputStream(s.getInputStream());
            Request req = parse(in);
            if (req == null) return;
            req.remote = s.getInetAddress().getHostAddress();
            String host = req.header("host");
            if (host == null || !hostCheck.allowed(host)) {
                write(s.getOutputStream(), Response.json(421, "{\"ok\":false,\"err\":\"wrong host\"}"));
                return;
            }
            String upgrade = req.header("upgrade");
            if (upgrade != null && "websocket".equalsIgnoreCase(upgrade) && wsHandler != null) {
                String key = req.header("sec-websocket-key");
                if (key == null) return;
                final Socket sock = s;
                try {
                    wsPool.execute(() -> {
                        try (Socket ws0 = sock) {
                            ws0.setSoTimeout(60_000);      // browsers answer our 20 s pings; dead peers time out
                            ws0.setKeepAlive(true);
                            ws0.setTcpNoDelay(true);
                            OutputStream out = ws0.getOutputStream();
                            Ws.handshake(out, key);
                            wsHandler.session(new Ws(ws0, in, out), req);
                        } catch (Exception e) {
                            Log.w(TAG, "ws session: " + e);
                        }
                    });
                    handedOff = true;
                } catch (RejectedExecutionException e) {
                    write(s.getOutputStream(), Response.json(503, "{\"ok\":false,\"err\":\"too many devices connected\"}"));
                }
                return;
            }
            Response res;
            try {
                res = handler.handle(req);
            } catch (Exception e) {
                Log.w(TAG, "handler error " + req.path + ": " + e);
                res = Response.json(500, "{\"ok\":false,\"err\":\"" + Json.esc(String.valueOf(e.getMessage())) + "\"}");
            }
            write(s.getOutputStream(), res);
        } catch (SocketTimeoutException ignored) {
        } catch (Exception e) {
            Log.w(TAG, "serve: " + e);
        } finally {
            if (!handedOff) try { s.close(); } catch (IOException ignored) {}
        }
    }

    private static Request parse(InputStream in) throws IOException {
        ByteArrayOutputStream head = new ByteArrayOutputStream();
        long deadline = System.currentTimeMillis() + HEADER_DEADLINE_MS;
        int prev3 = 0, prev2 = 0, prev1 = 0, c;
        while ((c = in.read()) != -1) {
            head.write(c);
            if (head.size() > MAX_HEADER || System.currentTimeMillis() > deadline) return null;
            if (prev3 == '\r' && prev2 == '\n' && prev1 == '\r' && c == '\n') break;
            prev3 = prev2; prev2 = prev1; prev1 = c;
        }
        String[] lines = head.toString("ISO-8859-1").split("\r\n");
        if (lines.length == 0) return null;
        String[] first = lines[0].split(" ");
        if (first.length < 2) return null;
        Request r = new Request();
        r.method = first[0];
        String target = first[1];
        int q = target.indexOf('?');
        r.path = q >= 0 ? target.substring(0, q) : target;
        if (q >= 0) {
            r.query = target.substring(q + 1);
            for (String kv : r.query.split("&")) {
                int e = kv.indexOf('=');
                if (e > 0) r.params.put(URLDecoder.decode(kv.substring(0, e), "UTF-8"), URLDecoder.decode(kv.substring(e + 1), "UTF-8"));
            }
        }
        for (int i = 1; i < lines.length; i++) {
            int colon = lines[i].indexOf(':');
            if (colon > 0) r.headers.put(lines[i].substring(0, colon).trim().toLowerCase(Locale.ROOT), lines[i].substring(colon + 1).trim());
        }
        String cl = r.header("content-length");
        if (cl != null) {
            long longLen = Long.parseLong(cl.trim());
            if (longLen > MAX_BODY && r.path.equals(STREAM_PATH) && longLen <= MAX_STREAM) {
                r.stream = in;
                r.streamLen = longLen;
                return r;
            }
            int len = (int) Math.min(longLen, Integer.MAX_VALUE);
            if (len < 0 || len > MAX_BODY) return null;
            byte[] b = new byte[len];
            int off = 0;
            while (off < len) {
                int n = in.read(b, off, len - off);
                if (n < 0) break;
                off += n;
            }
            r.body = b;
        }
        return r;
    }

    private static void write(OutputStream out, Response res) throws IOException {
        StringBuilder h = new StringBuilder();
        h.append("HTTP/1.1 ").append(res.status).append(' ').append(res.status == 200 ? "OK" : "Error").append("\r\n");
        h.append("Content-Type: ").append(res.type).append("\r\n");
        h.append("Content-Length: ").append(res.body.length).append("\r\n");
        if (!res.headers.containsKey("Cache-Control")) h.append("Cache-Control: no-store\r\n");
        h.append("X-Content-Type-Options: nosniff\r\n");
        h.append("Referrer-Policy: no-referrer\r\n");
        for (Map.Entry<String, String> e : res.headers.entrySet()) h.append(e.getKey()).append(": ").append(e.getValue()).append("\r\n");
        h.append("Connection: close\r\n\r\n");
        out.write(h.toString().getBytes(StandardCharsets.ISO_8859_1));
        out.write(res.body);
        out.flush();
    }
}
