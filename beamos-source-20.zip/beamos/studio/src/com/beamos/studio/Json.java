package com.beamos.studio;

import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONObject;

/** Small JSON helpers (org.json is part of Android). */
final class Json {
    private Json() {}

    static String esc(String s) {
        return JSONObject.quote(s == null ? "" : s).replaceAll("^\"|\"$", "");
    }

    /** Converts an adapter reply Bundle to JSON (ints, int[], strings, booleans, longs). */
    static JSONObject fromBundle(Bundle b) throws Exception {
        JSONObject o = new JSONObject();
        for (String k : b.keySet()) {
            Object v = b.get(k);
            if (v instanceof int[]) {
                JSONArray a = new JSONArray();
                for (int x : (int[]) v) a.put(x);
                o.put(k, a);
            } else if (v instanceof java.util.ArrayList) {
                JSONArray a = new JSONArray();
                for (Object x : (java.util.ArrayList<?>) v) a.put(String.valueOf(x));
                o.put(k, a);
            } else if (v instanceof Boolean || v instanceof Integer || v instanceof Long || v instanceof String) {
                o.put(k, v);
            } else if (v != null) {
                o.put(k, String.valueOf(v));
            }
        }
        return o;
    }

    static int[] ints(JSONArray a, int n) throws Exception {
        if (a == null || a.length() != n) throw new IllegalArgumentException("expected " + n + " numbers");
        int[] v = new int[n];
        for (int i = 0; i < n; i++) v[i] = (int) Math.round(a.getDouble(i));
        return v;
    }
}
