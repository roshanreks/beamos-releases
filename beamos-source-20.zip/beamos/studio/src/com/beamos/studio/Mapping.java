package com.beamos.studio;

import android.content.Context;
import android.content.Intent;
import android.os.StatFs;
import android.os.Handler;
import android.os.Looper;
import android.util.AtomicFile;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Locale;

/**
 * Mapping Studio store + routes. The current scene lives in files/mapping/scene.json, named scenes in
 * files/mapping/scenes/, media in files/mapping/. Showing the output is always an explicit user action
 * (and asks first when something is playing); editing while shown is live.
 */
final class Mapping {
    private static final long MIN_FREE = 150L * 1024 * 1024;
    private static final String[] IMG = {"jpg", "jpeg", "png", "webp", "gif"}, VID = {"mp4", "webm", "mkv", "mov", "3gp"};
    private static Mapping instance;
    private final Context ctx;
    private final File dir, scenes;
    private final Handler timer = new Handler(Looper.getMainLooper());
    private JSONObject calibration;
    private boolean outputBeforeCalibration;
    private final Runnable calibrationTimeout = () -> { try { endCalibration(); } catch (Exception ignored) {} };

    private Mapping(Context c) {
        ctx = c.getApplicationContext();
        dir = MappingActivity.mediaDir(ctx);
        scenes = new File(dir, "scenes");
        scenes.mkdirs();
    }

    static synchronized Mapping get(Context c) {
        if (instance == null) instance = new Mapping(c);
        return instance;
    }

    private static HttpServer.Response ok(JSONObject o) throws Exception {
        if (!o.has("ok")) o.put("ok", true);
        return HttpServer.Response.json(200, o.toString());
    }

    private static HttpServer.Response err(int status, String msg) {
        return HttpServer.Response.json(status, "{\"ok\":false,\"err\":\"" + Json.esc(msg) + "\"}");
    }

    /** A file name the phone sent, reduced to something safe inside our directory. */
    private static String safeName(String n) {
        if (n == null) return null;
        n = n.replaceAll("[^A-Za-z0-9._ -]", "_").trim();
        if (n.isEmpty() || n.startsWith(".") || n.length() > 80) return null;
        return n;
    }

    private static String ext(String n) {
        int i = n.lastIndexOf('.');
        return i < 0 ? "" : n.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    static boolean isImage(String n) { return Arrays.asList(IMG).contains(ext(n)); }
    static boolean isVideo(String n) { return Arrays.asList(VID).contains(ext(n)); }

    private static String readAll(File f) throws Exception {
        return new String(new AtomicFile(f).readFully(), "UTF-8");
    }

    private static synchronized void writeAll(File f, String s) throws Exception {
        AtomicFile file = new AtomicFile(f);
        FileOutputStream out = null;
        try { out = file.startWrite(); out.write(s.getBytes("UTF-8")); file.finishWrite(out); }
        catch (Exception e) { if (out != null) file.failWrite(out); throw e; }
    }

    synchronized JSONObject scene() throws Exception {
        File f = MappingActivity.sceneFile(ctx);
        return f.exists() || new File(f + ".bak").exists() ? new JSONObject(readAll(f)) : new JSONObject().put("surfaces", new JSONArray());
    }

    /** Validates (quads, known types, files that exist) and keeps a scene; applies it live when the output is up. */
    synchronized void setScene(JSONObject scene) throws Exception {
        validateScene(scene);
        writeAll(MappingActivity.sceneFile(ctx), scene.toString());
        // Calibration never becomes the saved scene, nor can a background edit replace its markers.
        if (calibration == null) MappingActivity.apply(scene);
    }

    private void validateScene(JSONObject scene) throws Exception {
        JSONArray arr = scene.optJSONArray("surfaces");
        if (arr == null) throw new Exception("surfaces missing");
        if (arr.length() > 24) throw new Exception("too many surfaces (max 24)");
        int videos = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject s = arr.getJSONObject(i);
            JSONArray q = s.optJSONArray("quad");
            if (q == null || q.length() != 4) throw new Exception("surface " + i + ": quad");
            for (int k = 0; k < 4; k++) {
                JSONArray pt = q.getJSONArray(k);
                double x = pt.getDouble(0), y = pt.getDouble(1);
                if (x < -0.5 || x > 1.5 || y < -0.5 || y > 1.5) throw new Exception("surface " + i + ": corner off the picture");
            }
            String type = s.optString("type", "color");
            if (!Arrays.asList("color", "pattern", "image", "video").contains(type)) throw new Exception("surface " + i + ": type");
            if ("image".equals(type) || "video".equals(type)) {
                String f = safeName(s.optString("file"));
                if (f == null || !new File(dir, f).isFile()) throw new Exception("surface " + i + ": media missing");
                s.put("file", f);
                if ("video".equals(type) && ++videos > 3) throw new Exception("at most 3 videos at once (memory)");
            }
        }
    }

    synchronized JSONObject outputScene() throws Exception { return calibration == null ? scene() : calibration; }
    synchronized boolean calibrating() { return calibration != null; }

    private synchronized void beginCalibration(JSONObject markers) throws Exception {
        validateScene(markers);
        if (calibration == null) outputBeforeCalibration = MappingActivity.showing();
        calibration = markers;
        timer.removeCallbacks(calibrationTimeout);
        timer.postDelayed(calibrationTimeout, 120_000);
        ctx.startActivity(new Intent(ctx, MappingActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        MappingActivity.apply(markers);
    }

    synchronized void endCalibration() throws Exception {
        if (calibration == null) return;
        calibration = null;
        timer.removeCallbacks(calibrationTimeout);
        if (outputBeforeCalibration) MappingActivity.apply(scene()); else MappingActivity.close();
    }

    private File referenceFile() { return new File(dir, ".room-reference.jpg"); }

    private synchronized void saveReference(String encoded) throws Exception {
        if (!encoded.startsWith("data:image/jpeg;base64,") || encoded.length() > 260_000) throw new Exception("room photo too large");
        byte[] bytes = Base64.decode(encoded.substring(encoded.indexOf(',') + 1), Base64.DEFAULT);
        android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length, o);
        if (o.outWidth <= 0 || o.outHeight <= 0 || o.outWidth > 1400 || o.outHeight > 1400) throw new Exception("invalid room photo");
        AtomicFile file = new AtomicFile(referenceFile());
        FileOutputStream out = null;
        try { out = file.startWrite(); out.write(bytes); file.finishWrite(out); }
        catch (Exception e) { if (out != null) file.failWrite(out); throw e; }
    }

    private JSONArray media() {
        JSONArray a = new JSONArray();
        File[] fs = dir.listFiles();
        if (fs != null) {
            Arrays.sort(fs, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
            for (File f : fs) if (f.isFile() && !f.equals(referenceFile()) && (isImage(f.getName()) || isVideo(f.getName()))) {
                try { a.put(new JSONObject().put("name", f.getName()).put("size", f.length()).put("type", isVideo(f.getName()) ? "video" : "image")); } catch (Exception ignored) {}
            }
        }
        return a;
    }

    private JSONArray sceneNames() {
        JSONArray a = new JSONArray();
        File[] fs = scenes.listFiles();
        if (fs != null) {
            Arrays.sort(fs);
            for (File f : fs) if (f.getName().endsWith(".json")) a.put(f.getName().substring(0, f.getName().length() - 5));
        }
        return a;
    }

    private synchronized JSONObject status() throws Exception {
        return new JSONObject().put("scene", scene()).put("scenes", sceneNames()).put("media", media())
                .put("showing", MappingActivity.showing() && calibration == null).put("calibrating", calibration != null)
                .put("referenceUpdated", referenceFile().lastModified()).put("freeMb", free() / (1024 * 1024));
    }

    private long free() {
        StatFs st = new StatFs(dir.getPath());
        return st.getAvailableBytes();
    }

    HttpServer.Response handle(HttpServer.Request r, String p, JSONObject in) throws Exception {
        switch (p) {
            case "/api/mapping": return ok(status());
            case "/api/mapping/calibration/start":
                if (PlaybackPoller.playing() && !in.optBoolean("confirm")) return err(409, "This will interrupt what is playing");
                beginCalibration(in.getJSONObject("scene"));
                return ok(new JSONObject());
            case "/api/mapping/calibration/stop":
                endCalibration();
                return ok(new JSONObject());
            case "/api/mapping/reference": {
                if (!"GET".equals(r.method)) {
                    saveReference(in.getString("image"));
                    return ok(new JSONObject().put("referenceUpdated", referenceFile().lastModified()));
                }
                if (!referenceFile().isFile()) return err(404, "no room photo");
                AtomicFile f = new AtomicFile(referenceFile());
                return HttpServer.Response.bytes("image/jpeg", f.readFully());
            }
            case "/api/mapping/scene":
                setScene(in.getJSONObject("scene"));
                return ok(new JSONObject().put("showing", MappingActivity.showing()));
            case "/api/mapping/show": {
                if (PlaybackPoller.playing() && !in.optBoolean("confirm")) return err(409, "This will interrupt what is playing");
                endCalibration();
                if (in.has("scene")) setScene(in.getJSONObject("scene"));
                ctx.startActivity(new Intent(ctx, MappingActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
                return ok(new JSONObject());
            }
            case "/api/mapping/hide":
                endCalibration();
                MappingActivity.close();
                return ok(new JSONObject());
            case "/api/mapping/scenes/save": {
                String n = safeName(in.optString("name"));
                if (n == null) return err(400, "name");
                writeAll(new File(scenes, n + ".json"), (in.has("scene") ? in.getJSONObject("scene") : scene()).toString());
                return ok(new JSONObject().put("scenes", sceneNames()));
            }
            case "/api/mapping/scenes/load": {
                String n = safeName(in.optString("name"));
                File f = n == null ? null : new File(scenes, n + ".json");
                if (f == null || !f.isFile()) return err(404, "no such scene");
                JSONObject s = new JSONObject(readAll(f));
                setScene(s);
                return ok(new JSONObject().put("scene", s));
            }
            case "/api/mapping/scenes/delete": {
                String n = safeName(in.optString("name"));
                if (n == null || !new File(scenes, n + ".json").delete()) return err(404, "no such scene");
                return ok(new JSONObject().put("scenes", sceneNames()));
            }
            case "/api/mapping/upload": {
                String n = safeName(r.params.get("name"));
                if (n == null || !(isImage(n) || isVideo(n))) return err(400, "use a jpg/png/webp/gif image or mp4/webm video");
                long len = r.stream != null ? r.streamLen : r.body.length;
                if (free() - len < MIN_FREE) return err(507, "not enough space on the projector (" + free() / (1024 * 1024) + " MB free)");
                File tmp = new File(dir, "." + n + ".part"), dst = new File(dir, n);
                try (OutputStream out = new FileOutputStream(tmp)) {
                    if (r.stream != null) {
                        InputStream s = r.stream;
                        byte[] buf = new byte[64 * 1024];
                        long left = len;
                        while (left > 0) {
                            int k = s.read(buf, 0, (int) Math.min(buf.length, left));
                            if (k < 0) throw new Exception("upload cut short");
                            out.write(buf, 0, k);
                            left -= k;
                        }
                    } else out.write(r.body);
                } catch (Exception e) {
                    tmp.delete();
                    throw e;
                }
                if (!tmp.renameTo(dst)) { tmp.delete(); return err(500, "could not save"); }
                return ok(new JSONObject().put("name", n).put("size", dst.length()).put("media", media()));
            }
            case "/api/mapping/media/delete": {
                String n = safeName(in.optString("name"));
                if (n == null || !new File(dir, n).delete()) return err(404, "no such file");
                return ok(new JSONObject().put("media", media()));
            }
            case "/api/mapping/file": {           // images only (for thumbnails in the editor)
                String n = safeName(r.params.get("name"));
                File f = n == null ? null : new File(dir, n);
                if (f == null || !f.isFile() || !isImage(n)) return err(404, "no such image");
                byte[] b = new byte[(int) f.length()];
                try (FileInputStream in2 = new FileInputStream(f)) { int o = 0, k; while (o < b.length && (k = in2.read(b, o, b.length - o)) > 0) o += k; }
                HttpServer.Response res = HttpServer.Response.bytes("image/" + ("jpg".equals(ext(n)) ? "jpeg" : ext(n)), b);
                res.headers.put("Cache-Control", "max-age=3600");
                return res;
            }
            default: return err(404, "unknown api " + p);
        }
    }
}
