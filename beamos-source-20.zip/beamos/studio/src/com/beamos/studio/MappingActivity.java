package com.beamos.studio;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;

import org.json.JSONObject;

import java.io.File;

/** Full-screen Mapping Studio output. Opened only by an explicit "Show on projector" from the phone. BACK closes. */
public class MappingActivity extends Activity {
    private static volatile MappingActivity current;
    private MappingView view;

    static File mediaDir(android.content.Context c) {
        File f = new File(c.getFilesDir(), "mapping");
        f.mkdirs();
        return f;
    }

    static File sceneFile(android.content.Context c) { return new File(mediaDir(c), "scene.json"); }

    static void apply(JSONObject scene) {
        MappingActivity a = current;
        if (a != null) a.view.setScene(scene);
    }

    static boolean showing() { return current != null; }

    static void close() {
        MappingActivity a = current;
        if (a != null) a.runOnUiThread(a::finish);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        view = new MappingView(this, mediaDir(this));
        setContentView(view);
        current = this;
        try {
            view.setScene(Mapping.get(this).outputScene());
        } catch (Exception e) {
            android.util.Log.w(Studio.TAG, "scene load: " + e);
        }
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK) { finish(); return true; }
        return super.onKeyDown(code, e);
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        if (view != null) view.release();
        super.onDestroy();
    }
}
