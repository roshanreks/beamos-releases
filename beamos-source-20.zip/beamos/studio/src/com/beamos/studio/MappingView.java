package com.beamos.studio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.MediaPlayer;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Mapping Studio renderer. A scene is a list of surfaces; each is a quad in projector space (normalised 0..1,
 * TL,TR,BR,BL) filled with a colour, an animated pattern, an image, or a looping video. Colour/pattern/image
 * surfaces are drawn with a perspective matrix on one canvas; each video surface is a TextureView transformed
 * with the same matrix. Everything is clipped to its quad, so shapes can be cut around real objects.
 */
final class MappingView extends ViewGroup {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<JSONObject> surfaces = new ArrayList<>();
    private final Map<String, Bitmap> images = new HashMap<>();
    private final Map<String, TextureView> videos = new HashMap<>();
    private final Map<String, MediaPlayer> players = new HashMap<>();
    private final File mediaDir;
    private final Overlay overlay;
    private boolean animated;
    private long t0 = System.currentTimeMillis();

    MappingView(Context c, File mediaDir) {
        super(c);
        this.mediaDir = mediaDir;
        setBackgroundColor(Color.BLACK);
        overlay = new Overlay(c);
        addView(overlay);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        for (int i = 0; i < getChildCount(); i++) getChildAt(i).layout(0, 0, r - l, b - t);
        overlay.bringToFront();
        applyVideoTransforms();
    }

    /** Replaces the scene. Safe to call from any thread. */
    void setScene(JSONObject scene) {
        post(() -> {
            surfaces.clear();
            JSONArray arr = scene.optJSONArray("surfaces");
            if (arr != null) for (int i = 0; i < arr.length(); i++) surfaces.add(arr.optJSONObject(i));
            animated = false;
            for (JSONObject s : surfaces) if ("pattern".equals(s.optString("type")) && s.optDouble("speed", 1) > 0) animated = true;
            syncMedia();
            overlay.invalidate();
        });
    }

    private Matrix matrixFor(JSONObject s, float w, float h) {
        JSONArray q = s.optJSONArray("quad");
        if (q == null || q.length() != 4) return null;
        float[] dst = new float[8];
        for (int i = 0; i < 4; i++) {
            JSONArray pt = q.optJSONArray(i);
            dst[i * 2] = (float) pt.optDouble(0) * w;
            dst[i * 2 + 1] = (float) pt.optDouble(1) * h;
        }
        Matrix m = new Matrix();
        m.setPolyToPoly(new float[]{0, 0, 1000, 0, 1000, 1000, 0, 1000}, 0, dst, 0, 4);
        return m;
    }

    private void syncMedia() {
        // images: load what's needed, drop the rest
        java.util.Set<String> wantImg = new java.util.HashSet<>(), wantVid = new java.util.HashSet<>();
        for (JSONObject s : surfaces) {
            String f = s.optString("file", "");
            if ("image".equals(s.optString("type")) && !f.isEmpty()) wantImg.add(f);
            if ("video".equals(s.optString("type")) && !f.isEmpty()) wantVid.add(s.optString("id") + "|" + f);
        }
        for (String f : new ArrayList<>(images.keySet())) if (!wantImg.contains(f)) { Bitmap b = images.remove(f); if (b != null) b.recycle(); }
        for (String f : wantImg) if (!images.containsKey(f)) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(new File(mediaDir, f).getPath(), o);
            o.inJustDecodeBounds = false;
            o.inSampleSize = Math.max(1, Math.max(o.outWidth, o.outHeight) / 1280);
            Bitmap b = BitmapFactory.decodeFile(new File(mediaDir, f).getPath(), o);
            if (b != null) images.put(f, b);
        }
        for (String key : new ArrayList<>(videos.keySet())) if (!wantVid.contains(key)) {
            removeView(videos.remove(key));
            MediaPlayer mp = players.remove(key);
            if (mp != null) { try { mp.stop(); } catch (Exception ignored) {} mp.release(); }
        }
        for (final String key : wantVid) if (!videos.containsKey(key)) {
            final String file = key.substring(key.indexOf('|') + 1);
            TextureView tv = new TextureView(getContext());
            tv.setOpaque(false);
            tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
                @Override public void onSurfaceTextureAvailable(android.graphics.SurfaceTexture st, int w, int h) {
                    try {
                        MediaPlayer mp = new MediaPlayer();
                        mp.setDataSource(new File(mediaDir, file).getPath());
                        mp.setSurface(new Surface(st));
                        mp.setLooping(true);
                        JSONObject s = find(key.substring(0, key.indexOf('|')));
                        float vol = s == null ? 0f : (float) s.optDouble("volume", 0);
                        mp.setVolume(vol, vol);
                        mp.prepare();
                        mp.start();
                        players.put(key, mp);
                    } catch (Exception e) {
                        android.util.Log.w(Studio.TAG, "video " + file + ": " + e);
                    }
                }
                @Override public void onSurfaceTextureSizeChanged(android.graphics.SurfaceTexture st, int w, int h) {}
                @Override public boolean onSurfaceTextureDestroyed(android.graphics.SurfaceTexture st) { return true; }
                @Override public void onSurfaceTextureUpdated(android.graphics.SurfaceTexture st) {}
            });
            videos.put(key, tv);
            addView(tv, 0, new LayoutParams(1000, 1000));
        }
        applyVideoTransforms();
    }

    private JSONObject find(String id) {
        for (JSONObject s : surfaces) if (id.equals(s.optString("id"))) return s;
        return null;
    }

    private void applyVideoTransforms() {
        float w = getWidth(), h = getHeight();
        if (w == 0) return;
        for (Map.Entry<String, TextureView> e : videos.entrySet()) {
            JSONObject s = find(e.getKey().substring(0, e.getKey().indexOf('|')));
            if (s == null) continue;
            Matrix m = matrixFor(s, w, h);
            if (m == null) continue;
            TextureView tv = e.getValue();
            tv.layout(0, 0, 1000, 1000);
            tv.setTransform(m);
            tv.setAlpha((float) s.optDouble("opacity", 1));
        }
    }

    void release() {
        for (MediaPlayer mp : players.values()) { try { mp.stop(); } catch (Exception ignored) {} mp.release(); }
        players.clear();
        for (Bitmap b : images.values()) b.recycle();
        images.clear();
    }

    /** Draws colour / pattern / image surfaces (and clip masks) above the video layers. */
    private final class Overlay extends View {
        Overlay(Context c) { super(c); }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float t = (System.currentTimeMillis() - t0) / 1000f;
            for (JSONObject s : surfaces) {
                String type = s.optString("type", "color");
                if ("video".equals(type)) continue;
                Matrix m = matrixFor(s, w, h);
                if (m == null) continue;
                c.save();
                c.concat(m);
                c.clipRect(0, 0, 1000, 1000);
                int alpha = (int) (255 * s.optDouble("opacity", 1));
                int col = parseColor(s.optString("color", "#ffffff"));
                p.setShader(null);
                p.setAlpha(255);
                if ("color".equals(type)) {
                    p.setColor(col); p.setAlpha(alpha);
                    c.drawRect(0, 0, 1000, 1000, p);
                } else if ("image".equals(type)) {
                    Bitmap b = images.get(s.optString("file", ""));
                    if (b != null) { p.setAlpha(alpha); c.drawBitmap(b, null, new RectF(0, 0, 1000, 1000), p); }
                } else if ("pattern".equals(type)) {
                    drawPattern(c, s.optString("pattern", "stripes"), col, parseColor(s.optString("color2", "#000000")), alpha, t * (float) s.optDouble("speed", 1));
                }
                c.restore();
            }
            if (animated) postInvalidateOnAnimation();
        }

        private void drawPattern(Canvas c, String kind, int c1, int c2, int alpha, float t) {
            p.setAlpha(alpha);
            switch (kind) {
                case "stripes": {
                    p.setColor(c2); p.setAlpha(alpha); c.drawRect(0, 0, 1000, 1000, p);
                    p.setColor(c1); p.setAlpha(alpha);
                    float off = (t * 120) % 160;
                    for (float x = -160 + off; x < 1100; x += 160) { Path path = new Path(); path.moveTo(x, 0); path.lineTo(x + 80, 0); path.lineTo(x + 80 - 300, 1000); path.lineTo(x - 300, 1000); path.close(); c.drawPath(path, p); }
                    break;
                }
                case "grid": {
                    p.setColor(c2); p.setAlpha(alpha); c.drawRect(0, 0, 1000, 1000, p);
                    p.setColor(c1); p.setAlpha(alpha); p.setStrokeWidth(6); p.setStyle(Paint.Style.STROKE);
                    float off = (t * 60) % 100;
                    for (float x = off; x < 1000; x += 100) c.drawLine(x, 0, x, 1000, p);
                    for (float y = off; y < 1000; y += 100) c.drawLine(0, y, 1000, y, p);
                    p.setStyle(Paint.Style.FILL);
                    break;
                }
                case "dots": {
                    p.setColor(c2); p.setAlpha(alpha); c.drawRect(0, 0, 1000, 1000, p);
                    p.setColor(c1); p.setAlpha(alpha);
                    float r = 25 + 15 * (float) Math.sin(t * 3);
                    for (float x = 50; x < 1000; x += 100) for (float y = 50; y < 1000; y += 100) c.drawCircle(x, y, r, p);
                    break;
                }
                case "pulse": {
                    float k = 0.5f + 0.5f * (float) Math.sin(t * 2);
                    p.setColor(Color.rgb((int) (Color.red(c1) * k + Color.red(c2) * (1 - k)), (int) (Color.green(c1) * k + Color.green(c2) * (1 - k)), (int) (Color.blue(c1) * k + Color.blue(c2) * (1 - k))));
                    p.setAlpha(alpha); c.drawRect(0, 0, 1000, 1000, p);
                    break;
                }
                default: {  // gradient sweep
                    float off = (t * 300) % 2000 - 1000;
                    p.setShader(new LinearGradient(off, 0, off + 1000, 1000, new int[]{c2, c1, c2}, null, Shader.TileMode.MIRROR));
                    p.setAlpha(alpha); c.drawRect(0, 0, 1000, 1000, p); p.setShader(null);
                }
            }
        }
    }

    private static int parseColor(String s) {
        try { return Color.parseColor(s); } catch (Exception e) { return Color.WHITE; }
    }
}
