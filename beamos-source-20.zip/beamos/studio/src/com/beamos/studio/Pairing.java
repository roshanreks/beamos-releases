package com.beamos.studio;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;

/**
 * Pairing: a 6-digit code shown on the projector (valid 10 minutes, new code after each use) is exchanged for a
 * random 128-bit token. Tokens persist until revoked. 5 wrong codes lock pairing for 60 s.
 */
final class Pairing {
    private static final long CODE_TTL_MS = 10 * 60 * 1000L;
    private static final int MAX_TOKENS = 12;
    private static Pairing instance;
    private final SharedPreferences sp;
    private final SecureRandom rnd = new SecureRandom();
    private String code;
    private long codeExpires;
    private int failures;
    private long lockedUntil;

    private Pairing(Context ctx) {
        sp = ctx.getApplicationContext().getSharedPreferences("pairing", Context.MODE_PRIVATE);
        newCode();
    }

    static synchronized Pairing get(Context ctx) {
        if (instance == null) instance = new Pairing(ctx);
        return instance;
    }

    synchronized String code() {
        if (System.currentTimeMillis() > codeExpires) newCode();
        return code;
    }

    private void newCode() {
        code = String.format("%06d", rnd.nextInt(1_000_000));
        codeExpires = System.currentTimeMillis() + CODE_TTL_MS;
    }

    /** Returns a new token, or null if the code is wrong/expired/locked. */
    synchronized String pair(String attempt, String deviceName) {
        long now = System.currentTimeMillis();
        if (now < lockedUntil) return null;
        if (attempt == null || now > codeExpires || !constantTimeEquals(attempt.trim(), code)) {
            if (++failures >= 5) { lockedUntil = now + 60_000; failures = 0; }
            return null;
        }
        failures = 0;
        newCode();
        byte[] b = new byte[16];
        rnd.nextBytes(b);
        StringBuilder t = new StringBuilder();
        for (byte x : b) t.append(String.format("%02x", x));
        Set<String> tokens = new HashSet<>(sp.getStringSet("tokens", new HashSet<>()));
        if (tokens.size() >= MAX_TOKENS) tokens.clear();
        tokens.add(t + "|" + (deviceName == null ? "phone" : deviceName.replace('|', ' ')));
        sp.edit().putStringSet("tokens", tokens).apply();
        return t.toString();
    }

    private final java.util.Map<String, Long> temp = new java.util.HashMap<>();

    /** A one-hour token for the projector's own receiver page (never shown to users). */
    synchronized String issueTemp() {
        byte[] b = new byte[16]; rnd.nextBytes(b);
        StringBuilder t = new StringBuilder(); for (byte x : b) t.append(String.format("%02x", x));
        temp.put(t.toString(), System.currentTimeMillis() + 3600_000L);
        return t.toString();
    }

    synchronized boolean valid(String token) {
        if (token == null || token.length() != 32) return false;
        Long exp = temp.get(token);
        if (exp != null) { if (exp > System.currentTimeMillis()) return true; temp.remove(token); }
        for (String e : sp.getStringSet("tokens", new HashSet<>())) {
            if (constantTimeEquals(e.substring(0, Math.min(32, e.length())), token)) return true;
        }
        return false;
    }

    synchronized int count() {
        return sp.getStringSet("tokens", new HashSet<>()).size();
    }

    synchronized void revokeAll() {
        sp.edit().remove("tokens").apply();
    }

    private static boolean constantTimeEquals(String a, String b) {
        if (a.length() != b.length()) return false;
        int r = 0;
        for (int i = 0; i < a.length(); i++) r |= a.charAt(i) ^ b.charAt(i);
        return r == 0;
    }
}
