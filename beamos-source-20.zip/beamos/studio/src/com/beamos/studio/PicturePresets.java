package com.beamos.studio;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import com.beamos.common.Contract;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.UUID;

/** Projector-owned looks. Saved once here, available to every paired phone/Mac, retained across app updates. */
final class PicturePresets {
    private static PicturePresets instance;
    private final Context ctx;
    private final SharedPreferences prefs;
    private static final String[] IDS = {"bright_room", "anime", "youtube", "netflix", "standard", "cinema", "vivid", "game", "computer"};
    private static final String[] NAMES = {"Bright room", "Anime", "YouTube", "Netflix", "Balanced", "Cinema", "Vivid", "Game", "Text / PC"};
    // Hardware IDs 1..13: image brightness, contrast, saturation, tint, sharpness, panel level,
    // temporal/spatial NR, dynamic contrast, black extension, gamma, temperature, dynamic backlight.
    private static final int[][] LOOKS = {
        {52,55,52,50,40,100,1,0,1,0,1,0,0},
        // Some room light: lift midtones via gamma, retain neutral black, avoid smearing line art.
        {50,53,52,50,25,100,0,0,0,0,1,0,0},
        {50,52,50,50,30,100,1,0,0,0,2,0,0},
        {50,50,50,50,25,100,0,0,0,0,3,0,0},
        {50,50,50,50,35,100,1,1,0,0,3,0,0},
        {50,48,48,50,30,100,1,1,0,0,3,2,0},
        {50,58,58,50,50,100,1,1,1,0,2,0,0},
        {50,52,50,50,35,100,0,0,0,0,3,0,0},
        {50,50,50,50,0,100,0,0,0,0,3,0,0}
    };

    private PicturePresets(Context c) { ctx = c.getApplicationContext(); prefs = ctx.getSharedPreferences("picture_presets", Context.MODE_PRIVATE); }
    static synchronized PicturePresets get(Context c) { if (instance == null) instance = new PicturePresets(c); return instance; }
    private JSONObject data() throws Exception { return new JSONObject(prefs.getString("data", "{\"saved\":[]}")); }
    private void store(JSONObject data) throws Exception {
        if (!prefs.edit().putString("data", data.toString()).commit()) throw new IllegalStateException("Picture applied, but preset storage failed — please retry");
    }
    private static JSONObject snapshot(JSONObject p) throws Exception {
        return new JSONObject().put("vals", p.getJSONArray("vals")).put("lampMode", p.getInt("lampMode"));
    }
    private JSONObject hardware() throws Exception {
        Bundle b = AdapterClient.get(ctx).call(Contract.PIC_GET, null);
        if (!b.getBoolean(Contract.KEY_OK)) throw new IllegalStateException(b.getString(Contract.KEY_ERR, "Picture engine unavailable"));
        return Json.fromBundle(b);
    }
    private JSONObject applyHardware(JSONObject p) throws Exception {
        Bundle b = new Bundle(); b.putIntArray("vals", Json.ints(p.getJSONArray("vals"), 13)); b.putInt("lampMode", p.getInt("lampMode"));
        Bundle result = AdapterClient.get(ctx).call(Contract.PIC_APPLY, b);
        if (!result.getBoolean(Contract.KEY_OK)) throw new IllegalStateException(result.getString(Contract.KEY_ERR, "Picture was not applied"));
        return Json.fromBundle(result);
    }
    private static JSONArray saved(JSONObject d) throws Exception {
        JSONArray a = d.optJSONArray("saved"); if (a == null) { a = new JSONArray(); d.put("saved", a); } return a;
    }
    private static String label(String id, JSONObject d) throws Exception {
        if ("custom".equals(id)) return "Custom";
        for (int i=0;i<IDS.length;i++) if (IDS[i].equals(id)) return NAMES[i];
        JSONArray a=saved(d); for(int i=0;i<a.length();i++) if(id.equals(a.getJSONObject(i).getString("id"))) return a.getJSONObject(i).getString("name");
        return "Projector settings";
    }
    private JSONObject decorate(JSONObject p, JSONObject d) throws Exception {
        String active = d.optString("active", "");
        JSONObject last = d.optJSONObject("last");
        if (last == null || !last.getJSONArray("vals").toString().equals(p.getJSONArray("vals").toString()) || last.getInt("lampMode") != p.getInt("lampMode")) active = "";
        return p.put("activePreset", active).put("activeLabel", label(active,d)).put("savedPresets", saved(d))
                .put("savedOnProjector", !active.isEmpty()).put("maxLampMode",2).put("hasCustom",d.has("custom"));
    }
    synchronized JSONObject read() throws Exception { return decorate(hardware(), data()); }
    private JSONObject remember(JSONObject actual, JSONObject d, String active, boolean custom) throws Exception {
        d.put("last", snapshot(actual)).put("active",active);
        if (custom) d.put("custom", snapshot(actual));
        store(d);
        return decorate(actual,d);
    }
    synchronized JSONObject setValues(JSONObject changes) throws Exception {
        JSONObject d=data(), current=hardware(), target=snapshot(current);
        JSONArray vals=target.getJSONArray("vals");
        java.util.Iterator<String> keys=changes.keys(); boolean any=false;
        while(keys.hasNext()) {
            String key=keys.next(); int id;
            try { id=Integer.parseInt(key); } catch(Exception e) { throw new IllegalArgumentException("Unknown picture setting"); }
            if(id<1||id>13) throw new IllegalArgumentException("Unknown picture setting "+id);
            Object value=changes.get(key);
            if(!(value instanceof Number) || ((Number)value).doubleValue()!=((Number)value).intValue()) throw new IllegalArgumentException("Picture values must be whole numbers");
            vals.put(id-1,((Number)value).intValue()); any=true;
        }
        if(!any) return decorate(current,d);
        return remember(applyHardware(target),d,"custom",true);
    }
    synchronized JSONObject select(String id) throws Exception {
        JSONObject d=data(), target=null;
        if("energy_saving".equals(id)) id="standard"; // old companion alias; Eco is now explicitly a lamp choice
        if("custom".equals(id)) target=d.optJSONObject("custom");
        for(int i=0;i<IDS.length;i++) if(IDS[i].equals(id)) target=new JSONObject().put("vals",new JSONArray(LOOKS[i])).put("lampMode",2);
        JSONArray a=saved(d); for(int i=0;i<a.length();i++) if(id.equals(a.getJSONObject(i).getString("id"))) target=a.getJSONObject(i);
        if(target==null && "custom".equals(id)) target=snapshot(hardware());
        if(target==null) throw new IllegalArgumentException("Unknown picture preset");
        return remember(applyHardware(target),d,id,"custom".equals(id));
    }
    synchronized JSONObject lamp(int mode) throws Exception {
        JSONObject d=data(), target=snapshot(hardware()); target.put("lampMode",mode);
        return remember(applyHardware(target),d,"custom",true);
    }
    private static String text(String value,int max,String field) {
        String s=value.trim(); if(s.length()>max || s.matches("(?s).*[\\p{Cntrl}].*")) throw new IllegalArgumentException(field+" is too long or contains control characters"); return s;
    }
    synchronized JSONObject save(String name,String device,String id) throws Exception {
        name=text(name,64,"Preset name"); device=text(device,64,"Device name"); if(name.isEmpty()) throw new IllegalArgumentException("Give the preset a name");
        JSONObject d=data(),actual=hardware(); JSONArray a=saved(d); int at=-1;
        for(int i=0;i<a.length();i++) if(a.getJSONObject(i).getString("id").equals(id)) at=i;
        if(!id.isEmpty()&&at<0) throw new IllegalArgumentException("Preset no longer exists");
        if(at<0 && a.length()>=32) throw new IllegalArgumentException("Maximum 32 saved presets");
        if(id.isEmpty()) id="saved-"+UUID.randomUUID();
        JSONObject p=snapshot(actual).put("id",id).put("name",name).put("device",device);
        if(at<0) a.put(p); else a.put(at,p);
        return remember(actual,d,id,false);
    }
    synchronized JSONObject delete(String id) throws Exception {
        JSONObject d=data();JSONArray a=saved(d);boolean found=false;
        for(int i=a.length()-1;i>=0;i--) if(id.equals(a.getJSONObject(i).getString("id"))) {a.remove(i);found=true;}
        if(!found) throw new IllegalArgumentException("Preset no longer exists");
        if(id.equals(d.optString("active"))) {d.put("active","custom");d.put("custom",d.getJSONObject("last"));}
        store(d);return decorate(hardware(),d);
    }
    synchronized void restore() throws Exception {
        JSONObject d=data(), last=d.optJSONObject("last"); if(last==null) return;
        applyHardware(last); Log.i(Studio.TAG,"Saved picture look restored");
    }
}
