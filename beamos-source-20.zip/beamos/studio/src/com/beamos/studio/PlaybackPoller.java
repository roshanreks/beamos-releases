package com.beamos.studio;

import android.content.Context;
import android.os.Bundle;

import com.beamos.common.Contract;

import org.json.JSONObject;

/**
 * Polls the adapter's playback guard every 2 s while phones are connected and publishes changes.
 * Everything that could interrupt playback asks {@link #playing()} first.
 */
final class PlaybackPoller {
    private static Context app;
    private static Thread thread;
    private static volatile JSONObject last = new JSONObject();
    private static volatile boolean playing;
    private static volatile long lastPlayingAt;
    private static final Object WAKE = new Object();

    private PlaybackPoller() {}

    static synchronized void start(Context ctx) {
        if (thread != null) return;
        app = ctx.getApplicationContext();
        thread = new Thread(() -> {
            while (true) {
                try { poll(); } catch (Exception ignored) {}
                synchronized (WAKE) {
                    try { WAKE.wait(Events.clients() > 0 ? 2000 : 15000); } catch (InterruptedException e) { return; }
                }
            }
        }, "beam-playback");
        thread.setDaemon(true);
        thread.start();
    }

    static void pollSoon() {
        synchronized (WAKE) { WAKE.notifyAll(); }
    }

    private static void poll() throws Exception {
        Bundle b = AdapterClient.get(app).call(Contract.PLAYBACK, null);
        JSONObject o = Json.fromBundle(b);
        o.put("t", "playback");
        boolean p = b.getBoolean("playing");
        if (p) lastPlayingAt = System.currentTimeMillis();
        playing = p;
        String prev = last.toString();
        last = o;
        if (!prev.equals(o.toString())) Events.publish(o);
    }

    static JSONObject last() { return last; }
    static boolean playing() { return playing; }
    /** Milliseconds since something was last playing (Long.MAX_VALUE if never). */
    static long idleMs() { return lastPlayingAt == 0 ? Long.MAX_VALUE : System.currentTimeMillis() - lastPlayingAt; }
}
