package com.beamos.studio;

import android.graphics.Bitmap;
import android.graphics.Color;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.util.EnumMap;
import java.util.Map;

/** QR codes via ZXing core 3.5.3 (Apache-2.0). */
final class Qr {
    private Qr() {}

    static Bitmap make(String text, int size) { return make(text,size,1); }

    static Bitmap make(String text, int size, int margin) {
        try {
            Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
            hints.put(EncodeHintType.MARGIN, margin);
            BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints);
            int[] px = new int[size * size];
            for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) px[y * size + x] = m.get(x, y) ? Color.BLACK : Color.WHITE;
            Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565);
            b.setPixels(px, 0, size, 0, 0, size, size);
            return b;
        } catch (Exception e) {
            return null;
        }
    }
}
