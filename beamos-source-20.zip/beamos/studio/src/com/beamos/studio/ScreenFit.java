package com.beamos.studio;

import android.content.Context;
import android.content.SharedPreferences;
import com.beamos.common.Contract;
import java.util.Arrays;
import org.json.JSONArray;
import org.json.JSONObject;

/** Keeps a fitted plane transform on the projector, so resizing preserves wall geometry across remotes/restarts. */
final class ScreenFit {
    private static ScreenFit instance;
    private final SharedPreferences store;
    private final CoachSession coach;
    private ScreenFit(Context ctx){store=ctx.getSharedPreferences("screen_fit",Context.MODE_PRIVATE);coach=CoachSession.get(ctx);}
    static synchronized ScreenFit get(Context ctx){if(instance==null)instance=new ScreenFit(ctx.getApplicationContext());return instance;}
    private JSONObject saved()throws Exception{return new JSONObject(store.getString("state","{}"));}
    synchronized JSONObject state()throws Exception{
        JSONObject data=saved(),model=data.optJSONObject("model");
        boolean matches=model!=null&&Arrays.equals(readInsets(model.getJSONArray("vals")),coach.vals());
        return new JSONObject().put("ok",true).put("canResize",matches).put("reference",model==null?"none":model.optString("reference"))
            .put("canUndo",data.has("before")&&Arrays.equals(readInsets(data.getJSONArray("after")),coach.vals()));
    }
    synchronized JSONObject ownedFit(JSONObject in,String owner,int[] original)throws Exception{
        synchronized(coach){
            if(!coach.ownsCameraPreview(owner))throw new IllegalStateException("Camera preview changed elsewhere; scan again");
            JSONObject result=fit(in),data=saved();
            data.put("before",new JSONArray(original));
            if(!store.edit().putString("state",data.toString()).commit())result.put("warning","Alignment saved; scan undo history could not be saved");
            return result;
        }
    }
    synchronized JSONObject fit(JSONObject in)throws Exception{
        int[] baseline=readInsets(in.getJSONArray("baseline")),target=readInsets(in.getJSONArray("vals"));
        String reference=in.getString("reference");if(!reference.equals("wall-reference")&&!reference.equals("camera-plane")&&!reference.equals("lidar"))throw new IllegalArgumentException("Unknown photo reference");
        double[] matrix=matrix(in.getJSONArray("panelToPlane"));
        validateRectangle(matrix,target);
        JSONObject model=new JSONObject().put("panelToPlane",new JSONArray(matrix)).put("reference",reference).put("vals",new JSONArray(target));
        if(reference.equals("lidar")){
            double[][] q=corners(target);double minX=Double.MAX_VALUE,minY=Double.MAX_VALUE,maxX=-Double.MAX_VALUE,maxY=-Double.MAX_VALUE;
            for(double[] p:q){double[] v=point(matrix,p);minX=Math.min(minX,v[0]);minY=Math.min(minY,v[1]);maxX=Math.max(maxX,v[0]);maxY=Math.max(maxY,v[1]);}
            model.put("clearBounds",new JSONArray(new double[]{minX,minY,maxX,maxY}));
        }
        return apply(baseline,target,model);
    }
    synchronized JSONObject resize(JSONObject in)throws Exception{
        int[] baseline=readInsets(in.getJSONArray("baseline"));
        JSONObject model=saved().optJSONObject("model");
        if(model==null||!Arrays.equals(readInsets(model.getJSONArray("vals")),baseline))throw new IllegalStateException("Fit a photo first; manual corner changes need a new fit before proportional resizing");
        int[] target=scaled(matrix(model.getJSONArray("panelToPlane")),baseline,in.getDouble("scale"));
        JSONArray bounds=model.optJSONArray("clearBounds");
        if(bounds!=null){for(double[] p:corners(target)){double[] q=point(matrix(model.getJSONArray("panelToPlane")),p);if(q[0]<bounds.getDouble(0)-0.005||q[1]<bounds.getDouble(1)-0.005||q[0]>bounds.getDouble(2)+0.005||q[1]>bounds.getDouble(3)+0.005)throw new IllegalArgumentException("Scan again to verify a larger obstacle-free screen");}}
        model.put("vals",new JSONArray(target));return apply(baseline,target,model);
    }
    synchronized JSONObject undo(JSONObject in)throws Exception{
        JSONObject old=saved();int[] baseline=readInsets(in.getJSONArray("baseline"));
        if(!old.has("before")||!Arrays.equals(baseline,readInsets(old.getJSONArray("after"))))throw new IllegalStateException("Alignment changed; this undo is no longer current");
        JSONObject result=coach.applyVerified(baseline,readInsets(old.getJSONArray("before")));
        JSONObject next=new JSONObject();if(old.optJSONObject("previousModel")!=null)next.put("model",old.getJSONObject("previousModel"));
        if(!store.edit().putString("state",next.toString()).commit())result.put("warning","Alignment restored; resize profile could not be saved");
        return result.put("fit",state());
    }
    private JSONObject apply(int[] baseline,int[] target,JSONObject model)throws Exception{
        if(!Contract.validInsets(target))throw new IllegalArgumentException("Maximum screen size for this angle reached; move the projector to go larger");
        JSONObject old=saved();JSONObject result=coach.applyVerified(baseline,target);
        JSONObject next=new JSONObject().put("model",model).put("before",new JSONArray(baseline)).put("after",new JSONArray(target));
        if(old.optJSONObject("model")!=null)next.put("previousModel",old.getJSONObject("model"));
        if(!store.edit().putString("state",next.toString()).commit())result.put("warning","Fit saved; resize profile could not be saved");
        return result.put("fit",state());
    }
    static int[] readInsets(JSONArray a)throws Exception{
        int[] out=Json.ints(a,8);for(int i=0;i<8;i++){double n=a.getDouble(i);if(!Double.isFinite(n)||n!=out[i])throw new IllegalArgumentException("Expected eight whole-number corner values");}
        if(!Contract.validInsets(out))throw new IllegalArgumentException("Corner values are outside the projector range");return out;
    }
    static double[] matrix(JSONArray input)throws Exception{
        if(input.length()!=9)throw new IllegalArgumentException("Expected a 3×3 plane transform");
        double[] h=new double[9];for(int i=0;i<9;i++){h[i]=input.getDouble(i);if(!Double.isFinite(h[i]))throw new IllegalArgumentException("Invalid plane transform");}
        inverse(h);return h;
    }
    static double[][] corners(int[] v){return new double[][]{{v[2]/1000.,v[3]/1000.},{1-v[4]/1000.,v[5]/1000.},{1-v[6]/1000.,1-v[7]/1000.},{v[0]/1000.,1-v[1]/1000.}};}
    static double[] point(double[] h,double[] p){
        double w=h[6]*p[0]+h[7]*p[1]+h[8];if(!Double.isFinite(w)||Math.abs(w)<1e-9)throw new IllegalArgumentException("Projection crosses the plane horizon");
        double[] q={(h[0]*p[0]+h[1]*p[1]+h[2])/w,(h[3]*p[0]+h[4]*p[1]+h[5])/w};
        if(!Double.isFinite(q[0])||!Double.isFinite(q[1]))throw new IllegalArgumentException("Invalid wall point");return q;
    }
    static double[] inverse(double[] h){
        double a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],i=h[7],j=h[8];
        double det=a*(e*j-f*i)-b*(d*j-f*g)+c*(d*i-e*g);
        if(!Double.isFinite(det)||Math.abs(det)<1e-12)throw new IllegalArgumentException("Plane transform is singular");
        double[] out={e*j-f*i,c*i-b*j,b*f-c*e,f*g-d*j,a*j-c*g,c*d-a*f,d*i-e*g,b*g-a*i,a*e-b*d};for(int k=0;k<9;k++)out[k]/=det;return out;
    }
    static void validateRectangle(double[] h,int[] v){
        if(!Contract.validInsets(v))throw new IllegalArgumentException("Fit exceeds projector corner limits");
        double[][] q=corners(v);for(int i=0;i<4;i++)q[i]=point(h,q[i]);
        double w=(q[1][0]-q[0][0]+q[2][0]-q[3][0])/2,ht=(q[3][1]-q[0][1]+q[2][1]-q[1][1])/2;
        if(!(w>0&&ht>0)||Math.abs(w/ht-16./9)>0.035)throw new IllegalArgumentException("Photo fit did not produce a 16:9 screen; check the marked corners and reference");
        double tol=Math.max(w,ht)*0.008;
        if(Math.abs(q[0][1]-q[1][1])>tol||Math.abs(q[2][1]-q[3][1])>tol||Math.abs(q[0][0]-q[3][0])>tol||Math.abs(q[1][0]-q[2][0])>tol)throw new IllegalArgumentException("Fitted edges are not straight; check the reference points");
    }
    static int[] scaled(double[] h,int[] v,double factor){
        if(!Double.isFinite(factor)||factor<0.8||factor>1.2)throw new IllegalArgumentException("Resize by at most 20% per step");
        validateRectangle(h,v);double[][] q=corners(v);double x=0,y=0;for(int i=0;i<4;i++){q[i]=point(h,q[i]);x+=q[i][0]/4;y+=q[i][1]/4;}
        double[] back=inverse(h);for(int i=0;i<4;i++)q[i]=point(back,new double[]{x+(q[i][0]-x)*factor,y+(q[i][1]-y)*factor});
        double[] p={q[3][0],1-q[3][1],q[0][0],q[0][1],1-q[1][0],q[1][1],1-q[2][0],1-q[2][1]};int[] out=new int[8];
        for(int i=0;i<8;i++){if(!Double.isFinite(p[i])||p[i]<0||p[i]>0.5)throw new IllegalArgumentException("Maximum screen size for this angle reached; reposition the projector to go larger");out[i]=(int)Math.round(p[i]*1000);}
        validateRectangle(h,out);return out;
    }
}
