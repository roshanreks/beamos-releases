package com.beamos.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.beamos.common.Contract;

import java.util.Arrays;
import java.util.List;

/** Settings: picture safety tools, auto keystone, updates, phones, diagnostics, vendor fallback. */
public class SettingsActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout list;
    private TextView info;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        Ui.applyBackground(sv);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 36);
        list.setPadding(pad, Ui.dp(this, 24), pad, pad);
        list.addView(Ui.text(this, "Settings", 28, Ui.TEXT, true));
        info = Ui.text(this, "Loading…", 15, Ui.MUTED, false);
        list.addView(info);
        sv.addView(list);
        setContentView(sv);
        build();
        refreshInfo();
    }

    private void item(String title, String sub, Runnable r) {
        list.addView(Ui.tile(this, title, sub, Ui.CARD, 640, 74, r));
    }

    private void build() {
        item("Auto keystone: turn OFF", "Stops the tilt sensor from overriding Screen Coach corrections", () -> autoKs(false));
        item("Auto keystone: turn ON", "Back to the factory tilt-sensor correction", () -> autoKs(true));
        item("Full-frame picture (try 15 s)", "Removes all digital shrinking — biggest, sharpest image", () -> preview(new int[8]));
        item("Restore picture from before BeamOS", "The exact corners you had when BeamOS was installed", () -> {
            String s = getSharedPreferences("first_run", MODE_PRIVATE).getString("keystone", null);
            if (s != null) preview(parse(s)); else Studio.toast(this, "No saved picture yet");
        });
        item("Check for updates", "Feed: " + new Updater(this).feedUrl(), this::checkUpdates);
        item("Forget all paired phones", "Phones will need the pairing code again", () -> {
            Pairing.get(this).revokeAll();
            Studio.toast(this, "All phones forgotten");
        });
        item("Diagnostics", "Adapter state, temperatures, memory, last crash", this::diagnostics);
        item("Vendor settings (fallback)", "The projector's original settings app", () -> open("vendor_settings"));
        list.getChildAt(2).requestFocus();
    }

    private static int[] parse(String s) {
        String[] p = s.replace("[", "").replace("]", "").split(",");
        int[] v = new int[p.length];
        for (int i = 0; i < p.length; i++) v[i] = Integer.parseInt(p[i].trim());
        return v;
    }

    private void refreshInfo() {
        CoachSession.get(this).io().execute(() -> {
            Bundle s = AdapterClient.get(this).call(Contract.STATE, null);
            String text = s.getBoolean(Contract.KEY_OK)
                    ? "BeamOS " + Studio.version(this) + " · " + s.getString("device") + " · auto keystone " + ("1".equals(s.getString("autoKeystone")) ? "ON" : "OFF")
                      + " · corners " + Arrays.toString(s.getIntArray("keystone")) + " · " + s.getString("lcdTemp") + "°C"
                    : "Adapter not available: " + s.getString(Contract.KEY_ERR);
            ui.post(() -> info.setText(text));
        });
    }

    private void autoKs(boolean on) {
        CoachSession.get(this).io().execute(() -> {
            Bundle a = new Bundle();
            a.putBoolean("on", on);
            Bundle r = AdapterClient.get(this).call(Contract.AUTO_KS, a);
            Studio.toast(this, r.getBoolean(Contract.KEY_OK) ? "Auto keystone " + (on ? "ON" : "OFF") : "Failed: " + r.getString(Contract.KEY_ERR));
            refreshInfo();
        });
    }

    /** Applies a picture through Screen Coach (single owner of geometry) with a Keep / Revert dialog. */
    private void preview(int[] vals) {
        CoachSession cs = CoachSession.get(this);
        if (cs.dirty()) { Studio.toast(this, "Finish the Screen Coach edit on the phone first (Keep or Revert)"); return; }
        cs.io().execute(() -> {
            try {
                cs.preview(vals);
                ui.post(this::keepOrRevert);
            } catch (Exception e) {
                Studio.toast(this, "Failed: " + e.getMessage());
            }
        });
    }

    private void keepOrRevert() {
        final CoachSession cs = CoachSession.get(this);
        AlertDialog d = new AlertDialog.Builder(this).setTitle("Keep this picture?").setMessage("Reverting in 15 s")
                .setPositiveButton("Keep", (x, y) -> cs.io().execute(() -> {
                    boolean ok = cs.keep();
                    Studio.toast(this, ok ? "Picture saved" : "Expired — previous picture restored");
                    refreshInfo();
                }))
                .setNegativeButton("Revert", (x, y) -> cs.io().execute(() -> { cs.revert(); refreshInfo(); }))
                .setCancelable(false).create();
        d.show();
        new CountDownTimer(15000, 1000) {
            @Override public void onTick(long ms) { d.setMessage("Reverting in " + (ms / 1000) + " s"); }
            @Override public void onFinish() {
                if (d.isShowing()) { d.dismiss(); cs.io().execute(() -> { cs.revert(); refreshInfo(); }); }
            }
        }.start();
    }

    private void open(String target) {
        CoachSession.get(this).io().execute(() -> {
            Bundle a = new Bundle();
            a.putString("target", target);
            AdapterClient.get(this).call(Contract.OPEN, a);
        });
    }

    private void checkUpdates() {
        Studio.toast(this, "Checking for updates…");
        new Thread(() -> {
            Updater u = new Updater(this);
            try {
                List<Updater.Item> items = u.check();
                if (items.isEmpty()) { Studio.toast(this, "BeamOS is up to date"); return; }
                StringBuilder s = new StringBuilder();
                for (Updater.Item i : items) s.append(i.pkg.replace("com.beamos.", "")).append(' ').append(i.versionName).append(" — ").append(i.notes).append('\n');
                ui.post(() -> new AlertDialog.Builder(this).setTitle("Update BeamOS?").setMessage(s.toString())
                        .setPositiveButton("Install", (x, y) -> new Thread(() -> AutoUpdate.runOnce(this, true)).start())
                        .setNegativeButton("Later", null).show());
            } catch (Exception e) {
                Studio.toast(this, "Update check failed: " + e.getMessage());
            }
        }).start();
    }

    private void diagnostics() {
        CoachSession.get(this).io().execute(() -> {
            Bundle s = AdapterClient.get(this).call(Contract.STATE, null);
            StringBuilder t = new StringBuilder();
            for (String k : s.keySet()) {
                Object v = s.get(k);
                t.append(k).append(": ").append(v instanceof int[] ? Arrays.toString((int[]) v) : String.valueOf(v)).append('\n');
            }
            t.append("ip: ").append(Net.lanIp()).append('\n');
            t.append("lastCrash: ").append(getSharedPreferences("diag", MODE_PRIVATE).getString("lastCrash", "none"));
            ui.post(() -> new AlertDialog.Builder(this).setTitle("Diagnostics").setMessage(t.toString()).setPositiveButton("OK", null).show());
        });
    }
}
