package com.beamos.studio;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

/** Application: starts the gateway and keeps a crash log so problems are visible in Diagnostics. */
public class Studio extends Application {
    static final String TAG = "BeamStudio";

    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            Log.e(TAG, "CRASH in " + t.getName(), e);
            getSharedPreferences("diag", MODE_PRIVATE).edit().putString("lastCrash", t.getName() + ": " + Log.getStackTraceString(e)).commit();
            if (prev != null) prev.uncaughtException(t, e);
        });
        startGateway(this);
    }

    static void startGateway(Context ctx) {
        try {
            ctx.startForegroundService(new Intent(ctx, GatewayService.class));
        } catch (Exception e) {
            Log.w(TAG, "gateway start: " + e);
        }
    }

    static String version(Context ctx) {
        try { return ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).versionName; } catch (Exception e) { return "?"; }
    }

    static void toast(Context ctx, String msg) {
        new Handler(Looper.getMainLooper()).post(() -> Toast.makeText(ctx.getApplicationContext(), msg, Toast.LENGTH_LONG).show());
    }
}
