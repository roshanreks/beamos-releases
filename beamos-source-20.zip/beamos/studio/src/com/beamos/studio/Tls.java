package com.beamos.studio;

import android.content.Context;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Calendar;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;

/**
 * Self-signed TLS for the projector (browsers only allow screen capture on https pages). The key pair and
 * certificate are generated once on the device and never leave it. Minimal X.509 v3 DER written by hand
 * (RSA-2048, SHA-256, SAN = projector IP + beam.local), valid 10 years.
 */
final class Tls {
    private static final String TAG = "BeamStudio";
    private static SSLContext context;
    private static String fingerprint = "";

    private Tls() {}

    static synchronized SSLContext get(Context ctx) throws Exception {
        if (context != null) return context;
        File dir = new File(ctx.getFilesDir(), "tls");
        dir.mkdirs();
        File keyF = new File(dir, "key.pk8"), certF = new File(dir, "cert.der");
        PrivateKey key;
        byte[] certDer;
        String ip = Net.lanIp();
        if (keyF.exists() && certF.exists() && ip.equals(read(new File(dir, "ip")))) {
            key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(readBytes(keyF)));
            certDer = readBytes(certF);
        } else {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
            kpg.initialize(2048);
            KeyPair kp = kpg.generateKeyPair();
            key = kp.getPrivate();
            certDer = selfSigned(kp, ip);
            write(keyF, key.getEncoded());
            write(certF, certDer);
            write(new File(dir, "ip"), ip.getBytes());
            Log.i(TAG, "generated TLS certificate for " + ip);
        }
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(new java.io.ByteArrayInputStream(certDer));
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
        StringBuilder fp = new StringBuilder();
        for (byte b : md.digest(certDer)) { if (fp.length() > 0) fp.append(':'); fp.append(String.format("%02X", b)); }
        fingerprint = fp.toString();
        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
        ks.load(null, null);
        ks.setKeyEntry("beam", key, new char[0], new java.security.cert.Certificate[]{cert});
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(ks, new char[0]);
        SSLContext sc = SSLContext.getInstance("TLS");
        sc.init(kmf.getKeyManagers(), null, null);
        context = sc;
        return sc;
    }

    static String fingerprint() { return fingerprint; }

    // ---------- minimal DER ----------

    private static byte[] der(int tag, byte[]... parts) {
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        for (byte[] p : parts) body.write(p, 0, p.length);
        byte[] b = body.toByteArray();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(tag);
        if (b.length < 128) out.write(b.length);
        else if (b.length < 256) { out.write(0x81); out.write(b.length); }
        else if (b.length < 65536) { out.write(0x82); out.write(b.length >> 8); out.write(b.length & 0xff); }
        else { out.write(0x83); out.write(b.length >> 16); out.write((b.length >> 8) & 0xff); out.write(b.length & 0xff); }
        out.write(b, 0, b.length);
        return out.toByteArray();
    }

    private static byte[] seq(byte[]... p) { return der(0x30, p); }
    private static byte[] set(byte[]... p) { return der(0x31, p); }
    private static byte[] oid(String dotted) {
        String[] s = dotted.split("\\.");
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(Integer.parseInt(s[0]) * 40 + Integer.parseInt(s[1]));
        for (int i = 2; i < s.length; i++) {
            int v = Integer.parseInt(s[i]);
            byte[] tmp = new byte[5]; int n = 0;
            do { tmp[n++] = (byte) (v & 0x7f); v >>= 7; } while (v > 0);
            for (int j = n - 1; j >= 0; j--) o.write(tmp[j] | (j > 0 ? 0x80 : 0));
        }
        return der(0x06, o.toByteArray());
    }
    private static byte[] integer(BigInteger v) { return der(0x02, v.toByteArray()); }
    private static byte[] utf8(String s) { return der(0x0c, s.getBytes()); }
    private static byte[] bitString(byte[] b) { ByteArrayOutputStream o = new ByteArrayOutputStream(); o.write(0); o.write(b, 0, b.length); return der(0x03, o.toByteArray()); }
    private static byte[] octet(byte[] b) { return der(0x04, b); }
    private static byte[] bool(boolean b) { return der(0x01, new byte[]{(byte) (b ? 0xff : 0)}); }
    private static byte[] time(Calendar c) {
        String s = String.format("%02d%02d%02d%02d%02d%02dZ", c.get(Calendar.YEAR) % 100, c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH),
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), c.get(Calendar.SECOND));
        return der(0x17, s.getBytes());
    }
    private static byte[] name(String cn) { return seq(set(seq(oid("2.5.4.3"), utf8(cn)))); }

    private static byte[] selfSigned(KeyPair kp, String ip) throws Exception {
        Calendar from = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
        from.add(Calendar.DAY_OF_MONTH, -1);
        Calendar to = (Calendar) from.clone();
        to.add(Calendar.YEAR, 10);
        byte[] sigAlg = seq(oid("1.2.840.113549.1.1.11"), der(0x05));   // sha256WithRSAEncryption, NULL
        byte[] serial = integer(new BigInteger(63, new SecureRandom()));
        // SubjectAltName: dNSName beam.local, iPAddress <ip>
        String[] q = ip.split("\\.");
        byte[] ipBytes = new byte[]{(byte) Integer.parseInt(q[0]), (byte) Integer.parseInt(q[1]), (byte) Integer.parseInt(q[2]), (byte) Integer.parseInt(q[3])};
        byte[] san = seq(der(0x82, "beam.local".getBytes()), der(0x82, "beamos.local".getBytes()), der(0x87, ipBytes));
        byte[] extensions = der(0xa3, seq(
                seq(oid("2.5.29.17"), octet(san)),                                  // SAN
                seq(oid("2.5.29.19"), bool(true), octet(seq(bool(false)))),           // basicConstraints CA:false (critical)
                seq(oid("2.5.29.37"), octet(seq(oid("1.3.6.1.5.5.7.3.1"))))           // extKeyUsage serverAuth
        ));
        byte[] tbs = seq(der(0xa0, integer(BigInteger.valueOf(2))), serial, sigAlg, name("BeamOS projector"),
                seq(time(from), time(to)), name("BeamOS projector"), kp.getPublic().getEncoded(), extensions);
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(kp.getPrivate());
        s.update(tbs);
        return seq(tbs, sigAlg, bitString(s.sign()));
    }

    private static byte[] readBytes(File f) throws Exception {
        try (FileInputStream in = new FileInputStream(f)) { byte[] b = new byte[(int) f.length()]; int o = 0, n; while (o < b.length && (n = in.read(b, o, b.length - o)) > 0) o += n; return b; }
    }
    private static String read(File f) { try { return new String(readBytes(f)); } catch (Exception e) { return ""; } }
    private static void write(File f, byte[] b) throws Exception { try (FileOutputStream o = new FileOutputStream(f)) { o.write(b); } }
}
