package com.beamos.studio;
import org.json.JSONObject;

/** One acknowledged text transaction at a time across all paired clients. Never logs or returns submitted text. */
final class Typing {
    static synchronized JSONObject state() throws Exception {
        BeamIme ime=BeamIme.active();
        return ime==null?new JSONObject().put("ok",true).put("active",false):ime.fieldEvent("input").put("ok",true);
    }
    static synchronized JSONObject send(JSONObject in) throws Exception {
        BeamIme ime=BeamIme.active();if(ime==null)throw new IllegalStateException("Select the text box on the projector first");
        String session=in.optString("session",""),value=in.optString("text",""),mode=in.optString("mode","insert");
        boolean ok;
        if("replace".equals(mode))ok=ime.write(session,value,true);
        else if("insert".equals(mode))ok=ime.write(session,value,false);
        else if("code".equals(mode))ok=ime.code(session,value);
        else if("action".equals(mode))ok=ime.action(session);
        else throw new IllegalArgumentException("Unknown typing mode");
        if(!ok)throw new IllegalStateException("The field changed or rejected text — select it and retry");
        boolean actionApplied=!in.optBoolean("action");
        if(in.optBoolean("action") && !"code".equals(mode))actionApplied=ime.action(session);
        JSONObject result=state().put("ok",true).put("actionApplied",actionApplied);
        if(!actionApplied)result.put("warning","Text entered. The field changed; use the projector OK button if needed.");
        return result;
    }
}
