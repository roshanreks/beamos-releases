package com.beamos.studio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * BeamOS look: deep night canvas with soft colour blobs (rendered ONCE into a bitmap — zero redraws at idle),
 * glossy gradient tiles with shadows and big emoji icons, large type for 3 m viewing, unmistakable remote focus.
 */
final class Ui {
    static final int BG = Color.rgb(10, 12, 24);
    static final int CARD = Color.rgb(30, 34, 56);
    static final int TEXT = Color.rgb(242, 244, 252);
    static final int MUTED = Color.rgb(160, 168, 196);
    static final int ACCENT = Color.rgb(199, 243, 107);
    static final int[] TILE_COLORS = {
            Color.rgb(72, 100, 255), Color.rgb(255, 96, 110), Color.rgb(30, 190, 150),
            Color.rgb(255, 165, 48), Color.rgb(160, 92, 255), Color.rgb(44, 150, 230),
            Color.rgb(240, 70, 160), Color.rgb(60, 200, 220)};
    private static Bitmap blobs;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        return t;
    }

    static GradientDrawable rounded(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    private static int lighten(int c, float f) {
        return Color.rgb(Math.min(255, (int) (Color.red(c) + (255 - Color.red(c)) * f)),
                Math.min(255, (int) (Color.green(c) + (255 - Color.green(c)) * f)),
                Math.min(255, (int) (Color.blue(c) + (255 - Color.blue(c)) * f)));
    }

    /** Colourful blob background, drawn once at 1/4 resolution and scaled (cheap on a 1 GB device). */
    static synchronized Drawable blobBackground(Context c, int w, int h) {
        if (blobs == null) {
            int bw = Math.max(320, w / 4), bh = Math.max(180, h / 4);
            blobs = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(blobs);
            cv.drawColor(BG);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            float[][] spec = {{0.12f, 0.2f, 0.55f, 0}, {0.85f, 0.15f, 0.5f, 1}, {0.5f, 0.95f, 0.6f, 2}, {0.95f, 0.8f, 0.45f, 3}, {0.25f, 0.75f, 0.4f, 4}};
            for (float[] s : spec) {
                int col = TILE_COLORS[(int) s[3]];
                float r = s[2] * bh;
                p.setShader(new RadialGradient(s[0] * bw, s[1] * bh, r,
                        Color.argb(150, Color.red(col), Color.green(col), Color.blue(col)), Color.argb(0, 0, 0, 0), Shader.TileMode.CLAMP));
                cv.drawCircle(s[0] * bw, s[1] * bh, r, p);
            }
        }
        BitmapDrawable d = new BitmapDrawable(c.getResources(), blobs);
        d.setFilterBitmap(true);
        return d;
    }

    static LinearLayout tile(Context c, String title, String sub, int color, int wDp, int hDp, Runnable onClick) {
        return tile(c, title, sub, color, wDp, hDp, null, null, onClick);
    }

    static LinearLayout tile(Context c, String title, String sub, int color, int wDp, int hDp, Drawable icon, Runnable onClick) {
        return tile(c, title, sub, color, wDp, hDp, icon, null, onClick);
    }

    /** A focusable glossy tile. Focus = scale up + bright outline + lifted shadow, obvious from the sofa. */
    static LinearLayout tile(Context c, String title, String sub, int color, int wDp, int hDp, Drawable icon, String emoji, Runnable onClick) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.BOTTOM | Gravity.START);
        int pad = dp(c, 16);
        l.setPadding(pad, pad, pad, pad);
        final GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{lighten(color, 0.18f), color, darken(color, 0.25f)});
        bg.setCornerRadius(dp(c, 22));
        l.setBackground(bg);
        l.setElevation(dp(c, 8));
        l.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        l.setClipToOutline(true);
        l.setFocusable(true);
        l.setClickable(true);
        if (icon != null) {
            android.widget.ImageView iv = new android.widget.ImageView(c);
            iv.setImageDrawable(icon);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(c, 40), dp(c, 40));
            ip.bottomMargin = dp(c, 6);
            l.addView(iv, ip);
        } else if (emoji != null) {
            TextView e = text(c, emoji, 30, Color.WHITE, false);
            LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            ep.bottomMargin = dp(c, 4);
            l.addView(e, ep);
        }
        TextView t = text(c, title, 22, Color.WHITE, true);
        t.setShadowLayer(6, 0, 2, Color.argb(120, 0, 0, 0));
        l.addView(t);
        if (sub != null) l.addView(text(c, sub, 13, Color.argb(225, 255, 255, 255), false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(c, wDp), dp(c, hDp));
        int m = dp(c, 10);
        lp.setMargins(m, m, m, m);
        l.setLayoutParams(lp);
        l.setOnFocusChangeListener((v, has) -> {
            v.animate().scaleX(has ? 1.07f : 1f).scaleY(has ? 1.07f : 1f).setDuration(120).start();
            bg.setStroke(has ? dp(c, 4) : 0, ACCENT);
            v.setElevation(has ? dp(c, 16) : dp(c, 8));
        });
        l.setOnClickListener(v -> onClick.run());
        return l;
    }

    private static int darken(int c, float f) {
        return Color.rgb((int) (Color.red(c) * (1 - f)), (int) (Color.green(c) * (1 - f)), (int) (Color.blue(c) * (1 - f)));
    }

    static LinearLayout row(Context c) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setClipChildren(false);
        r.setClipToPadding(false);
        return r;
    }

    static void applyBackground(View root) {
        root.setBackground(blobBackground(root.getContext(), 1920, 1080));
    }
}
