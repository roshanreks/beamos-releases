package com.beamos.studio;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.Base64;
import android.util.Log;

import com.beamos.common.Contract;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * BeamOS Update. Feed format (any HTTP(S) host):
 *   {"payload": base64(JSON), "sig": base64(ECDSA-P256-SHA256 over the payload bytes)}
 *   payload = {"channel":"stable","releases":{"com.beamos.adapter":{"versionCode":2,"versionName":"0.02",
 *              "url":"adapter-2.apk","sha256":"...","notes":"..."}, ...}}
 * Relative URLs resolve against the feed URL. Packages install via the adapter (pinned certificates, SHA-256).
 */
final class Updater {
    private static final String TAG = "BeamStudio";
    /** BeamOS update-signing public key (EC P-256, DER, base64). Private key lives only on the owner's Mac. */
    private static final String UPDATE_PUBLIC_KEY =
            "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEnBSsHY6IImJfLrGtxzT8uG5g8V9+hvhXA1LEgarvyl0Jik17m7hjEPxip/R9hIbFAff3QQ7GKHPygHugJB6A+g==";
    static final String DEFAULT_FEED = "https://roshanreks.github.io/beamos-releases/stable.json";   // internet (GitHub Pages)

    static final class Item {
        String pkg, versionName, url, sha256, notes;
        int versionCode, installedCode;
    }

    private final Context ctx;
    private final SharedPreferences sp;
    /** Shared across instances so the phone sees AutoUpdate/Settings progress too. */
    static volatile String status = "idle";
    private static final Object INSTALL_LOCK = new Object();

    Updater(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.sp = this.ctx.getSharedPreferences("updates", Context.MODE_PRIVATE);
    }

    String feedUrl() { return sp.getString("feed", DEFAULT_FEED); }

    void setFeedUrl(String url) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) throw new IllegalArgumentException("bad url");
        sp.edit().putString("feed", url).apply();
    }

    /** Downloads and verifies the feed; returns the packages that are newer than what is installed. */
    static final String[] FALLBACK_FEEDS = {"https://roshanreks.github.io/beamos-releases/stable.json", "http://127.0.0.1:8765/stable.json"};   // internet, then the Mac

    List<Item> check() throws Exception {
        Exception last = null;
        String configured = feedUrl();
        java.util.LinkedHashSet<String> feeds = new java.util.LinkedHashSet<>();
        feeds.add(configured);
        for (String f : FALLBACK_FEEDS) feeds.add(f);
        for (String f : feeds) {
            try { return check(f); } catch (Exception e) { last = e; }
        }
        status = "no update server reachable";
        throw last;
    }

    private List<Item> check(String feed) throws Exception {
        status = "checking";
        JSONObject outer = new JSONObject(new String(download(feed, 1024 * 1024), StandardCharsets.UTF_8));
        byte[] payload = Base64.decode(outer.getString("payload"), Base64.DEFAULT);
        byte[] sig = Base64.decode(outer.getString("sig"), Base64.DEFAULT);
        PublicKey key = KeyFactory.getInstance("EC").generatePublic(
                new X509EncodedKeySpec(Base64.decode(UPDATE_PUBLIC_KEY, Base64.DEFAULT)));
        Signature v = Signature.getInstance("SHA256withECDSA");
        v.initVerify(key);
        v.update(payload);
        if (!v.verify(sig)) throw new SecurityException("update feed signature invalid");
        JSONObject rel = new JSONObject(new String(payload, StandardCharsets.UTF_8)).getJSONObject("releases");
        List<Item> newer = new ArrayList<>();
        PackageManager pm = ctx.getPackageManager();
        for (Iterator<String> it = rel.keys(); it.hasNext(); ) {
            String pkg = it.next();
            if (!pkg.startsWith("com.beamos.")) continue;
            JSONObject r = rel.getJSONObject(pkg);
            Item i = new Item();
            i.pkg = pkg;
            i.versionCode = r.getInt("versionCode");
            i.versionName = r.optString("versionName");
            i.url = new URL(new URL(feed), r.getString("url")).toString();
            i.sha256 = r.getString("sha256");
            i.notes = r.optString("notes");
            try { i.installedCode = (int) pm.getPackageInfo(pkg, 0).getLongVersionCode(); } catch (Exception e) { i.installedCode = 0; }
            if (i.versionCode > i.installedCode) newer.add(i);
        }
        // Adapter first, studio last (installing studio restarts this app).
        newer.sort((a, b) -> Integer.compare(order(a.pkg), order(b.pkg)));
        status = newer.isEmpty() ? "up to date" : newer.size() + " update(s) available";
        return newer;
    }

    private static int order(String pkg) {
        if (Contract.ADAPTER_PKG.equals(pkg)) return 0;
        if (Contract.STUDIO_PKG.equals(pkg)) return 2;
        return 1;
    }

    /** Installs the given items through the adapter. Returns a human-readable result log. */
    String install(List<Item> items) throws Exception {
        synchronized (INSTALL_LOCK) { return installLocked(items); }
    }

    private String installLocked(List<Item> items) throws Exception {
        StringBuilder log = new StringBuilder();
        for (Item i : items) {
            status = "downloading " + i.pkg + " " + i.versionName;
            File f = File.createTempFile("beamos-", ".apk", ctx.getCacheDir());
            downloadTo(i.url, f, 150L * 1024 * 1024);
            status = "installing " + i.pkg + " " + i.versionName;
            Bundle args = new Bundle();
            args.putParcelable("fd", ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY));
            args.putString("pkg", i.pkg);
            args.putString("sha256", i.sha256);
            Bundle r = AdapterClient.get(ctx).call(Contract.INSTALL, args);
            String result = r.getBoolean(Contract.KEY_OK) ? r.getString("result") : "error: " + r.getString(Contract.KEY_ERR);
            if (!"success".equals(result)) {
                // Installing the adapter kills the process serving the call; check the real outcome (L22).
                for (int k = 0; k < 10 && !"success".equals(result); k++) {     // self-install of the adapter takes ~5 s
                    try {
                        Thread.sleep(2000);
                        int now = (int) ctx.getPackageManager().getPackageInfo(i.pkg, 0).getLongVersionCode();
                        if (now >= i.versionCode) result = "success";
                    } catch (Exception ignored) {}
                }
            }
            log.append(i.pkg).append(' ').append(i.versionName).append(": ").append(result).append('\n');
            Log.i(TAG, "update " + i.pkg + " " + i.versionName + " -> " + result);
            f.delete();
        }
        status = "done";
        return log.toString();
    }

    private static void downloadTo(String url, File f, long max) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(30000);
        try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(f)) {
            if (c.getResponseCode() != 200) throw new IllegalStateException("HTTP " + c.getResponseCode() + " for " + url);
            byte[] buf = new byte[65536];
            long total = 0;
            int n;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > max) throw new SecurityException("download too large");
                out.write(buf, 0, n);
            }
        } finally {
            c.disconnect();
        }
    }

    private static byte[] download(String url, int max) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(30000);
        try (InputStream in = c.getInputStream()) {
            if (c.getResponseCode() != 200) throw new IllegalStateException("HTTP " + c.getResponseCode() + " for " + url);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > max) throw new SecurityException("download too large");
            }
            return out.toByteArray();
        } finally {
            c.disconnect();
        }
    }
}
