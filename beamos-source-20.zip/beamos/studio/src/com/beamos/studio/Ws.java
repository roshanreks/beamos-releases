package com.beamos.studio;

import android.util.Base64;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Minimal RFC 6455 WebSocket (text frames, ping/pong, close). close() really closes the socket. */
final class Ws {
    private static final String GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    private static final int MAX_FRAME = 64 * 1024;

    private final Socket socket;
    private final DataInputStream in;
    private final OutputStream out;
    private volatile boolean closed;

    Ws(Socket socket, InputStream in, OutputStream out) {
        this.socket = socket;
        this.in = new DataInputStream(in);
        this.out = out;
    }

    static String acceptKey(String key) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-1").digest((key.trim() + GUID).getBytes(StandardCharsets.ISO_8859_1));
        return Base64.encodeToString(d, Base64.NO_WRAP);
    }

    static void handshake(OutputStream out, String key) throws Exception {
        String r = "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                + "Sec-WebSocket-Accept: " + acceptKey(key) + "\r\n\r\n";
        out.write(r.getBytes(StandardCharsets.ISO_8859_1));
        out.flush();
    }

    boolean isClosed() { return closed; }

    /** Blocks for the next text message; returns null when the connection closes. */
    String read() throws IOException {
        StringBuilder msg = null;
        while (!closed) {
            int b0 = in.read();
            if (b0 < 0) { closed = true; return null; }
            int b1 = in.readUnsignedByte();
            boolean fin = (b0 & 0x80) != 0;
            int op = b0 & 0x0F;
            boolean masked = (b1 & 0x80) != 0;
            long len = b1 & 0x7F;
            if (len == 126) len = in.readUnsignedShort();
            else if (len == 127) len = in.readLong();
            if (len < 0 || len > MAX_FRAME) { close(1009); return null; }
            byte[] mask = new byte[4];
            if (masked) in.readFully(mask);
            byte[] data = new byte[(int) len];
            in.readFully(data);
            if (masked) for (int i = 0; i < data.length; i++) data[i] ^= mask[i & 3];
            switch (op) {
                case 0x8: close(1000); return null;
                case 0x9: frame(0xA, data); continue;          // ping -> pong
                case 0xA: continue;                             // pong
                case 0x1: msg = new StringBuilder(new String(data, StandardCharsets.UTF_8)); break;
                case 0x0: if (msg != null) msg.append(new String(data, StandardCharsets.UTF_8)); break;
                default: continue;
            }
            if (fin && msg != null) return msg.toString();
            if (msg != null && msg.length() > MAX_FRAME) { close(1009); return null; }
        }
        return null;
    }

    void send(String text) throws IOException {
        frame(0x1, text.getBytes(StandardCharsets.UTF_8));
    }

    void ping() throws IOException {
        frame(0x9, new byte[0]);
    }

    private synchronized void frame(int op, byte[] data) throws IOException {
        if (closed) throw new IOException("closed");
        int n = data.length;
        byte[] head;
        if (n < 126) head = new byte[]{(byte) (0x80 | op), (byte) n};
        else if (n < 65536) head = new byte[]{(byte) (0x80 | op), 126, (byte) (n >> 8), (byte) n};
        else {
            head = new byte[10];
            head[0] = (byte) (0x80 | op);
            head[1] = 127;
            for (int i = 0; i < 8; i++) head[9 - i] = (byte) ((long) n >> (8 * i));
        }
        out.write(head);
        out.write(data);
        out.flush();
    }

    void close() { close(1000); }

    /** Sends a close frame with a code, then closes the socket so a blocked reader is released. */
    void close(int code) {
        if (closed) return;
        closed = true;
        try {
            byte[] d = {(byte) (code >> 8), (byte) code};
            synchronized (this) {
                out.write(new byte[]{(byte) 0x88, 2});
                out.write(d);
                out.flush();
            }
        } catch (IOException ignored) {
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
        }
    }
}
