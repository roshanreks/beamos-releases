package com.beamos.studio;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.beamos.common.Contract;

import org.json.JSONObject;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Real-time control channel (phone/Mac ↔ projector). Auth: paired token in ?t=, same-origin only.
 * Typing never falls back to raw key injection (that would hit the playing app). Keep/revert run on the
 * CoachSession's own executor so closing the phone never drops them.
 */
final class WsSession implements HttpServer.WsHandler {
    private final Context ctx;
    private static volatile Ws sender, receiver;

    WsSession(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    private static void relay(Ws to, String json) { if (to != null && !to.isClosed()) { try { to.send(json); } catch (Exception ignored) {} } }

    @Override
    public void session(Ws ws, HttpServer.Request r) throws Exception {
        String origin = r.header("origin"), host = r.header("host");
        if (origin != null && host != null && !origin.endsWith("://" + host)) { ws.close(4403); return; }
        if (!Pairing.get(ctx).valid(r.params.get("t"))) {
            ws.send("{\"t\":\"error\",\"err\":\"not paired\"}");
            ws.close(4401);
            return;
        }
        final LinkedBlockingQueue<String> q = Events.subscribe();
        if (q == null) {
            ws.send("{\"t\":\"error\",\"err\":\"too many devices connected\"}");
            ws.close(4002);
            return;
        }
        Thread writer = new Thread(() -> {
            try {
                while (!ws.isClosed()) {
                    String m = q.poll(20, TimeUnit.SECONDS);
                    if (m == null) { ws.ping(); continue; }
                    ws.send(m);
                }
            } catch (Exception ignored) {
            } finally {
                ws.close();
            }
        }, "beam-ws-writer");
        writer.start();
        try {
            CoachSession cs = CoachSession.get(ctx);
            if (!cs.dirty()) cs.load();          // phones never start from a stale picture
            ws.send(cs.state().toString());
            ws.send(PlaybackPoller.last().toString());
            BeamIme ime = BeamIme.active();
            if (ime != null) ws.send(ime.fieldEvent("input").toString());
            String msg;
            while ((msg = ws.read()) != null) {
                try {
                    handle(new JSONObject(msg), cs, ws);
                } catch (Exception e) {
                    ws.send(new JSONObject().put("t", "error").put("err", String.valueOf(e.getMessage())).toString());
                }
            }
        } finally {
            Events.unsubscribe(q);
            if (sender == ws) { sender = null; relay(receiver, "{\"t\":\"share_end\"}"); }
            if (receiver == ws) receiver = null;
            ws.close();
        }
    }

    private void handle(JSONObject m, CoachSession cs, Ws ws) throws Exception {
        AdapterClient a = AdapterClient.get(ctx);
        Bundle b = new Bundle();
        switch (m.getString("t")) {
            case "pic": {
                JSONObject values=new JSONObject().put(Integer.toString(m.getInt("id")),m.getInt("value"));
                ws.send(PicturePresets.get(ctx).setValues(values).put("t","picture").toString());
                break;
            }
            case "key":
                b.putInt("code", m.getInt("code"));
                b.putBoolean("long", m.optBoolean("long"));
                reply(ws, a.call(Contract.KEY, b));
                break;
            case "media":                        // transport through the app's own MediaController
                b.putString("action", m.getString("action"));
                Bundle r = a.call(Contract.MEDIA, b);
                if (!r.getBoolean(Contract.KEY_OK) || !r.getBoolean("handled")) {
                    ws.send("{\"t\":\"error\",\"err\":\"nothing is playing that accepts this\"}");
                }
                PlaybackPoller.pollSoon();
                break;
            case "text": {                       // live mirror of the whole field
                BeamIme ime = BeamIme.active();
                if (ime == null || !ime.setText(m.getString("text"))) {
                    ws.send("{\"t\":\"error\",\"err\":\"no text box is selected on the projector\"}");
                }
                break;
            }
            case "type": {                       // append into the focused text box (never raw keys)
                BeamIme ime = BeamIme.active();
                if (ime == null || !ime.commit(m.getString("text"))) {
                    ws.send("{\"t\":\"error\",\"err\":\"No text box is selected — turn on the BeamOS keyboard (More) and select a field\"}");
                }
                break;
            }
            case "action": {
                BeamIme ime = BeamIme.active();
                if (ime == null || !ime.action()) ws.send("{\"t\":\"error\",\"err\":\"No text box is selected\"}");
                break;
            }
            case "ks": cs.set(Json.ints(m.getJSONArray("vals"), 8), m.optBoolean("start")); break;
            case "nudge": cs.nudge(m.optString("mode", null), m.optInt("dx"), m.optInt("dy"), m.optInt("step")); break;
            case "mode": cs.selectMode(m.getString("mode")); break;
            case "step": cs.setStep(m.getInt("step")); break;
            case "guide": cs.setGuide(m.getString("guide")); break;
            case "undo": cs.undo(); break;
            case "keep":
                cs.io().execute(() -> {
                    boolean ok = cs.keep();
                    try { ws.send(new JSONObject().put("t", "kept").put("ok", ok).toString()); } catch (Exception ignored) {}
                });
                break;
            case "revert":
                cs.io().execute(() -> {
                    if (cs.state().optBoolean("temporary")) cs.revert(); else cs.undo();
                    try { ws.send("{\"t\":\"reverted\"}"); } catch (Exception ignored) {}
                });
                break;
            case "guides": {                     // transparent overlay on top of what is playing
                boolean on = m.optBoolean("on", true);
                if (on && !cs.dirty()) cs.io().execute(cs::load);
                if (!GuideOverlay.get(ctx).show(on)) {
                    b.putString("pkg", Contract.STUDIO_PKG);
                    a.call(Contract.GRANT_OVERLAY, b);
                    if (!GuideOverlay.get(ctx).show(on)) ws.send("{\"t\":\"error\",\"err\":\"overlay permission missing\"}");
                }
                break;
            }
            case "share_role":
                if ("receiver".equals(m.optString("role"))) receiver = ws; else sender = ws;
                if (sender == ws && receiver != null) ws.send("{\"t\":\"share_ready\"}");
                break;
            case "share_start": {                      // laptop wants to share: open the receiver (explicit user action)
                if (PlaybackPoller.playing() && !m.optBoolean("confirm")) { ws.send("{\"t\":\"error\",\"err\":\"This will interrupt what is playing\"}"); break; }
                sender = ws;
                String tok = Pairing.get(ctx).issueTemp();
                android.content.Intent i = new android.content.Intent(ctx, ReceiveActivity.class)
                        .putExtra("token", tok).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP);
                ctx.startActivity(i);
                break;
            }
            case "map":                                // live edit of the mapping scene (only visible if the output is up)
                Mapping.get(ctx).setScene(m.getJSONObject("scene"));
                break;
            case "share_offer": relay(receiver, m.toString()); break;
            case "share_answer": relay(sender, m.toString()); break;
            case "share_ice": relay(ws == receiver ? sender : receiver, m.toString()); break;
            case "share_stop": relay(receiver, "{\"t\":\"share_end\"}"); break;
            case "touch": {
                final Bundle t = new Bundle();
                t.putFloat("x", (float) m.getDouble("x"));
                t.putFloat("y", (float) m.getDouble("y"));
                t.putFloat("x2", (float) m.optDouble("x2", m.getDouble("x")));
                t.putFloat("y2", (float) m.optDouble("y2", m.getDouble("y")));
                t.putInt("dur", m.optInt("dur", 60));
                cs.io().execute(() -> a.call(Contract.TOUCH, t));
                break;
            }
            default: Log.w(Studio.TAG, "ws: unknown " + m.optString("t"));
        }
    }

    private static void reply(Ws ws, Bundle r) throws Exception {
        if (!r.getBoolean(Contract.KEY_OK)) ws.send(new JSONObject().put("t", "error").put("err", r.getString(Contract.KEY_ERR)).toString());
    }
}
