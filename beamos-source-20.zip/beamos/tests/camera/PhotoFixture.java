import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.util.Map;
import java.util.EnumMap;
import java.nio.file.Files;
import java.nio.file.Paths;
/** Render the actual versioned Android payloads into a disposable camera raster for the web decoder. */
public final class PhotoFixture {
 public static void main(String[] args)throws Exception{
  int w=960,h=540,size=Math.round(h*.18f),margin=Math.round(h*.015f);byte[] rgba=new byte[w*h*4];
  for(int i=0;i<rgba.length;i+=4){rgba[i]=rgba[i+1]=rgba[i+2]=100;rgba[i+3]=(byte)255;}
  String[] ids={"TL","TR","BR","BL"};int[][] at={{margin,margin},{w-margin-size,margin},{w-margin-size,h-margin-size},{margin,h-margin-size}};
  Map<EncodeHintType,Object> hints=new EnumMap<>(EncodeHintType.class);hints.put(EncodeHintType.MARGIN,4);
  for(int k=0;k<4;k++){BitMatrix m=new QRCodeWriter().encode("BEAM1:"+ids[k]+":0505050505050505:"+w+"x"+h,BarcodeFormat.QR_CODE,256,256,hints);
   for(int y=0;y<size;y++)for(int x=0;x<size;x++){int i=((at[k][1]+y)*w+at[k][0]+x)*4;byte c=m.get(x*256/size,y*256/size)?0:(byte)255;rgba[i]=rgba[i+1]=rgba[i+2]=c;}
  }
  Files.write(Paths.get(args[0]),rgba);
  if(args.length>1){java.awt.image.BufferedImage image=new java.awt.image.BufferedImage(w,h,java.awt.image.BufferedImage.TYPE_INT_RGB);for(int y=0;y<h;y++)for(int x=0;x<w;x++){int i=(y*w+x)*4;image.setRGB(x,y,((rgba[i]&255)<<16)|((rgba[i+1]&255)<<8)|(rgba[i+2]&255));}javax.imageio.ImageIO.write(image,"png",new java.io.File(args[1]));}
 }
}
