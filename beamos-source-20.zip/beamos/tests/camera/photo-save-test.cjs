const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const html=fs.readFileSync(path.resolve(__dirname,'../../studio/assets/web/index.html'),'utf8'),s=html.split('<script>')[1].split('</script>')[0];
const section=(a,b)=>s.slice(s.indexOf(a),s.indexOf(b,s.indexOf(a))),elements=new Map(),requests=[];let checks=0;
function element(key){if(!elements.has(key))elements.set(key,{value:'',checked:true,disabled:false,textContent:'',getContext(){return{}},classList:{remove(){}}});return elements.get(key)}
const c={$:element,token:'test',tab:'picture',setInterval(){},clearTimeout(){},setTimeout(){},console,
 safe:p=>p.catch(()=>{}),photoHandles(){},coachState(){},toast(){},api:(route,body)=>new Promise((resolve,reject)=>requests.push({route,body,resolve,reject}))};
vm.createContext(c);vm.runInContext(section('function convex(', '// Real time:')+'\n'+section('function solve(','function photoHandles(')+'\n'+section('const ph=$("#ph")','// ---------- Auto Screen ----------'),c);
const run=x=>vm.runInContext(x,c),turn=()=>new Promise(r=>setImmediate(r));const check=(label,fn)=>{fn();checks++;console.log('PASS '+label)};
(async()=>{
 run(`photoGeneration=1; refBaseline=[180,180,180,180,180,180,180,180]; refCapture={baseline:refBaseline.slice(),expected:refBaseline.slice(),gen:1};
 const optics=[[3,0,0],[.5,2,0],[.5,0,1]],cam=[[300,25,200],[20,280,120],[.09,.06,1]];
 pts=[[.18,.18],[.82,.18],[.82,.82],[.18,.82]].map(p=>hap(cam,hap(optics,p))).concat([[.5,-.4],[1.5,-.4],[1.5,-.1],[.5,-.1]].map(p=>hap(cam,p)));`);
 element('#refAspect').value=String(1/.3);
 const first=run('savePhoto("reference")');await turn();
 check('photo submits a real save endpoint rather than an unhandled socket command',()=>assert.equal(requests[0].route,'/api/coach/fit'));
 check('first save uses original capture as compare-and-set baseline',()=>assert.deepEqual(Array.from(requests[0].body.baseline),Array(8).fill(180)));
 check('plane transform is submitted with all eight corner coordinates',()=>{assert.equal(requests[0].body.panelToPlane.length,9);assert.equal(requests[0].body.vals.length,8)});
 const confirmed=Array.from(requests[0].body.vals),response={vals:confirmed,fit:{canResize:true,canUndo:true,reference:'wall-reference'}};
 requests[0].resolve(response);await turn();requests[1].resolve({ok:true});await first;
 check('success is shown after projector acknowledgement',()=>assert.match(element('#phStep').textContent,/Saved on projector/));
 check('immutable capture geometry is retained for subsequent photo-dot corrections',()=>assert.deepEqual(Array.from(run('refCapture.baseline')),Array(8).fill(180)));
 const second=run('savePhoto("reference")');await turn();
 check('reapplying the same photo compares against the last saved result',()=>assert.deepEqual(Array.from(requests[2].body.baseline),confirmed));
 requests[2].reject(new Error('Alignment changed elsewhere'));await second.catch(()=>{});
 check('failed fit remains visibly not applied',()=>assert.match(element('#phStep').textContent,/Not fitted: Alignment changed elsewhere/));
 check('failed fit does not advance the expected confirmed geometry',()=>assert.deepEqual(Array.from(run('refCapture.expected')),confirmed));
 const third=run('savePhoto("reference")');run('photoEdit++');await third;
 check('superseded queued photo edit never reaches hardware',()=>assert.equal(requests.length,3));
 console.log(`Passed ${checks} photo-save transaction checks. No live requests.`);
})().catch(e=>{console.error(e);process.exitCode=1});
