#!/bin/bash
set -euo pipefail
LAB=$(cd "$(dirname "$0")/../../.." && pwd)
TMP=$(mktemp -d);trap 'rm -rf "$TMP"' EXIT
J=/opt/homebrew/opt/openjdk@17/bin
"$J/javac" -cp "$LAB/beamos/studio/libs/zxing-core-3.5.3.jar" -d "$TMP" "$LAB/beamos/tests/camera/PhotoFixture.java"
"$J/java" -cp "$TMP:$LAB/beamos/studio/libs/zxing-core-3.5.3.jar" PhotoFixture "$TMP/photo.rgba"
node "$LAB/beamos/tests/camera/photo-test.cjs" "$TMP/photo.rgba"
