#!/bin/bash
set -euo pipefail
SERIAL=${1:?Pass an adb serial explicitly}
LAB=$(cd "$(dirname "$0")/../../.." && pwd)
SDK=${ANDROID_HOME:-/opt/homebrew/share/android-commandlinetools}
J=/opt/homebrew/opt/openjdk@17/bin
TMP=$(mktemp -d)
REMOTE="/data/local/tmp/beamos-camera-test-$$-$RANDOM"
cleanup(){ rm -rf "$TMP"; adb -s "$SERIAL" shell rm -rf "$REMOTE" >/dev/null 2>&1 || true; }
trap cleanup EXIT
mkdir -p "$TMP/classes" "$TMP/dex"
"$J/javac" --release 8 -encoding UTF-8 -cp "$SDK/platforms/android-30/android.jar" -d "$TMP/classes" \
  "$LAB/beamos/studio/src/com/beamos/studio/CameraCalibration.java" "$LAB/beamos/tests/camera/src/com/beamos/studio/CameraTest.java"
find "$TMP/classes" -name '*.class' > "$TMP/classes.list"
PATH="$J:$PATH" "$SDK/build-tools/34.0.0/d8" --min-api 30 --lib "$SDK/platforms/android-30/android.jar" --output "$TMP/dex" @"$TMP/classes.list"
adb -s "$SERIAL" shell mkdir -p "$REMOTE" >/dev/null
adb -s "$SERIAL" push "$TMP/dex/classes.dex" "$REMOTE/classes.dex" >/dev/null
adb -s "$SERIAL" shell "CLASSPATH=$REMOTE/classes.dex app_process / com.beamos.studio.CameraTest"
