package com.beamos.studio;

import android.graphics.Bitmap;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;

/** Exercises the actual publisher/green gate with an injected clock; no live geometry or media changes. */
public final class CameraTest {
    private static int checks;
    private static long time=1000,seq;
    private static final int[] FULL={0,0,0,0,0,0,0,0};
    private static String jpeg,lease;
    interface Action {void run() throws Exception;}
    static void check(String label,boolean value){if(!value)throw new AssertionError(label);checks++;System.out.println("PASS "+label);}
    static void rejects(String label,Action a)throws Exception{boolean rejected=false;try{a.run();}catch(Exception e){rejected=true;}check(label,rejected);}
    static JSONObject evidence()throws Exception{return new JSONObject().put("markers",4).put("maxErrorMm",3).put("aspectError",0.002).put("confidence",0.98).put("captureAgeMs",100).put("planeStable",true).put("obstaclesChecked",true).put("reference","lidar").put("targetId","wall-A").put("vals",new JSONArray(FULL));}
    static JSONObject input(JSONObject e)throws Exception{return new JSONObject().put("lease",lease).put("sequence",++seq).put("jpeg",jpeg).put("evidence",e);}
    static JSONObject publish(CameraCalibration c,JSONObject e)throws Exception{time+=500;return c.publish(input(e),FULL);}
    public static void main(String[] args){try{
        Bitmap bitmap=Bitmap.createBitmap(20,20,Bitmap.Config.ARGB_8888);ByteArrayOutputStream out=new ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.JPEG,65,out);bitmap.recycle();jpeg=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
        CameraCalibration c=new CameraCalibration(()->time);lease=c.start("iPhone wall camera").getString("lease");
        check("starting without image cannot be green",!c.state().getBoolean("geometryReady"));
        check("viewer status does not expose publisher lease",!c.state().has("lease"));
        rejects("second simultaneous publisher is rejected",()->c.start("other camera"));
        rejects("invalid JPEG rejected",()->c.publish(input(evidence()).put("jpeg","bm90LWEtanBlZw=="),FULL));
        for(int i=0;i<4;i++)check("settling frame "+i+" remains amber",!publish(c,evidence()).getBoolean("geometryReady"));
        check("five fresh stable measurements become green",publish(c,evidence()).getBoolean("geometryReady"));
        JSONObject replay=input(evidence());time+=500;c.publish(replay,FULL);
        rejects("replayed camera frame rejected",()->c.publish(replay,FULL));
        check("new target resets green",!publish(c,evidence().put("targetId","wall-B")).getBoolean("geometryReady"));
        check("unknown obstacles cannot be green",!publish(c,evidence().put("obstaclesChecked",false)).getBoolean("geometryReady"));
        check("low depth confidence cannot be green",!publish(c,evidence().put("confidence",0.5)).getBoolean("geometryReady"));
        check("old capture cannot be green",!publish(c,evidence().put("captureAgeMs",800)).getBoolean("geometryReady"));
        check("wrong aspect ratio cannot be green",!publish(c,evidence().put("aspectError",0.1)).getBoolean("geometryReady"));
        check("missing markers cannot be green",!publish(c,evidence().put("markers",3)).getBoolean("geometryReady"));
        check("camera-plane-only reference cannot be green",!publish(c,evidence().put("reference","photo")).getBoolean("geometryReady"));
        check("sub-permille value cannot pass actual geometry comparison",!publish(c,evidence().put("vals",new JSONArray("[0.5,0,0,0,0,0,0,0]"))).getBoolean("geometryReady"));
        check("geometry changed from captured frame cannot be green",!publish(c,evidence().put("vals",new JSONArray("[10,0,0,0,0,0,0,0]"))).getBoolean("geometryReady"));
        for(int i=0;i<5;i++)publish(c,evidence());check("valid fresh feedback recovers green",c.state().getBoolean("geometryReady"));
        time+=2500;check("expired feedback loses green and RAM frame",!c.state().getBoolean("geometryReady")&&!c.state().getBoolean("frameAvailable"));
        rejects("expired frame cannot be fetched",c::image);
        String old=lease;lease=c.start("new camera").getString("lease");
        rejects("old camera cannot resume after replacement",()->c.publish(input(evidence()).put("lease",old),FULL));
        time+=100;check("new camera image is shared",c.publish(input(evidence()),FULL).getBoolean("frameAvailable"));
        rejects("viewer cannot fetch a different frame sequence",()->c.image(seq-1));
        check("JPEG retrieval returns isolated copy",c.image()!=c.image());
        rejects("old publisher cannot stop a replacement camera",()->c.stop(old));
        check("stop clears live feedback",!c.stop().getBoolean("live"));
        System.out.println("Passed "+checks+" camera checks. Live projector untouched.");System.exit(0);
    }catch(Throwable e){e.printStackTrace();System.exit(1);}}
}
