const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync(require('node:path').resolve(__dirname,'../../studio/assets/web/camera-viewer.js'),'utf8');
const elements=new Map(),requests=[],revoked=[];let tick,checks=0;
function element(id){if(!elements.has(id))elements.set(id,{textContent:'',style:{},disabled:false,src:'',children:[],classList:{add(){},remove(){}},removeAttribute(k){delete this[k]},replaceChildren(){this.children=[]},appendChild(n){this.children.push(n)},setAttribute(k,v){this[k]=v}});return elements.get(id)}
const context={token:'paired-secret',tab:'picture',document:{hidden:false,querySelector:element,createElementNS(){return element('node-'+Math.random())},addEventListener(){}},URL:{createObjectURL:()=> 'blob:'+requests.length,revokeObjectURL:u=>revoked.push(u)},setInterval:f=>tick=f,safe:p=>p,api:(path,body)=>new Promise((resolve,reject)=>requests.push({path,body,resolve,reject})),fetch:(path,options)=>new Promise((resolve,reject)=>requests.push({path,options,resolve,reject}))};
vm.createContext(context);vm.runInContext(source,context);
const turn=()=>new Promise(r=>setImmediate(r));
const check=(label,action)=>{action();checks++;console.log('PASS '+label)};
(async()=>{
 await tick();check('viewer serializes status requests during a slow connection',()=>assert.equal(requests.length,1));
 requests[0].resolve({live:true,frameAvailable:true,sequence:3,geometryReady:false,evidence:{markers:4,maxErrorMm:12,screenQuad:[[0,0],[1,0],[1,1],[0,1]],excluded:[[.1,.2]]}});await turn();
 check('frame request is bound to the observed sequence',()=>assert.equal(requests[1].path,'/api/calibration/frame?sequence=3'));
 check('frame authenticates in a header and never leaks the pairing token in its URL',()=>{assert.equal(requests[1].options.headers['X-Beam-Token'],'paired-secret');assert(!requests[1].path.includes('secret'))});
 requests[1].resolve({ok:true,blob:async()=>({})});await turn();
 check('measured target and excluded space appear with the frame',()=>assert.equal(element('#cameraOverlay').children.length,2));
 check('unverified live feed does not claim alignment is ready',()=>assert.match(element('#cameraStatus').textContent,/scanning or correcting/));
 const expiry=tick();requests[2].resolve({live:false,frameAvailable:false,evidence:{}});await expiry;
 check('expired camera clears the image and geometry overlay',()=>{assert.equal(element('#cameraFrame').src,undefined);assert.equal(element('#cameraOverlay').children.length,0);assert.equal(revoked.length,1)});
 check('expiry disables stop and does not imply lost saved alignment',()=>{assert(element('#cameraStop').disabled);assert.match(element('#cameraMetrics').textContent,/saved alignment stays/)});
 context.document.hidden=true;await tick();check('hidden browser does not keep polling or retaining frames',()=>assert.equal(requests.length,3));
 context.document.hidden=false;const failure=tick();requests[3].reject(new Error('offline'));await failure;
 check('offline feedback cannot retain a green status',()=>{assert.match(element('#cameraStatus').textContent,/unavailable/);assert.equal(element('#cameraStatus').style.color,'var(--muted)')});
 console.log(`Passed ${checks} shared-camera viewer checks. No device or camera writes.`);
})().catch(e=>{console.error(e);process.exitCode=1});
