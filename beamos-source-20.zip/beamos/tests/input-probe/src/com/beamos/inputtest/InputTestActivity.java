package com.beamos.inputtest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.JSONObject;
import java.io.FileOutputStream;

/** Temporary visible test target. No accounts, permissions, network or real OTPs. Removed after verification. */
public class InputTestActivity extends Activity {
 EditText text;EditText[] cells=new EditText[6];Handler main=new Handler();
 @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(50,30,50,30);
 TextView title=new TextView(this);title.setText("BeamOS keyboard verification — test data only");title.setTextSize(24);root.addView(title);
 text=new EditText(this);text.setId(1001);text.setHint("TEST ordinary field");text.setSingleLine(true);text.setInputType(InputType.TYPE_CLASS_TEXT);root.addView(text);watch(text,-1);
 LinearLayout row=new LinearLayout(this);
 for(int i=0;i<6;i++){EditText cell=new EditText(this);cells[i]=cell;cell.setId(2001+i);cell.setHint("TEST "+(i+1));cell.setInputType(InputType.TYPE_CLASS_NUMBER);cell.setSingleLine(true);cell.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1)});row.addView(cell,new LinearLayout.LayoutParams(110,100));watch(cell,i);}root.addView(row);setContentView(root);
 main.postDelayed(()->{EditText target="code".equals(getIntent().getStringExtra("mode"))?cells[0]:text;target.requestFocus();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(target,InputMethodManager.SHOW_IMPLICIT);},300);
 }
 void watch(EditText target,int index){target.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int f){}public void onTextChanged(CharSequence s,int a,int b,int c){}public void afterTextChanged(Editable e){save();if(index>=0&&index<5&&e.length()==1)main.postDelayed(()->cells[index+1].requestFocus(),25);}});}
 void save(){try{StringBuilder code=new StringBuilder();for(EditText c:cells)if(c!=null)code.append(c.getText());JSONObject result=new JSONObject().put("text",text.getText().toString()).put("code",code.toString());try(FileOutputStream f=openFileOutput("result.json",MODE_PRIVATE)){f.write(result.toString().getBytes("UTF-8"));}}catch(Exception e){throw new RuntimeException(e);}}
}
