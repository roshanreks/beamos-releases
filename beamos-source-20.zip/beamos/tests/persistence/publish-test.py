#!/usr/bin/env python3
"""Exercise the real publication control flow with fake Git; never touches a real feed/repository."""
from pathlib import Path
import os
import subprocess
import tempfile

lab = Path(__file__).resolve().parents[3]
source = (lab / 'tools/beamos-publish.sh').read_text()
block = source[source.index('# Internet copy:'):]
with tempfile.TemporaryDirectory() as temp:
    root = Path(temp)
    feed = root / 'feed'
    (feed / '.git').mkdir(parents=True)
    fake_git = root / 'git'
    fake_git.write_text('''#!/bin/bash
case "$*" in
  *"diff --cached"*) exit 1;;
  *"push -q"*) exit "${TEST_PUSH_EXIT:-0}";;
esac
exit 0
''')
    fake_git.chmod(0o755)
    test = root / 'publisher-test.sh'
    test.write_text('set -euo pipefail\nFEED="$1"\nCH=test\nNOTES=test\n' + block)
    env = dict(os.environ, PATH=str(root) + os.pathsep + os.environ['PATH'])
    failed = subprocess.run(['bash', str(test), str(feed)], env=dict(env, TEST_PUSH_EXIT='42'), capture_output=True, text=True)
    assert failed.returncode == 42 and 'pushed online' not in failed.stdout and 'published →' not in failed.stdout, failed
    print('PASS failed remote push cannot report publication success')
    succeeded = subprocess.run(['bash', str(test), str(feed)], env=dict(env, TEST_PUSH_EXIT='0'), capture_output=True, text=True)
    assert succeeded.returncode == 0 and 'deployment still needs verification' in succeeded.stdout, succeeded
    print('PASS successful push distinguishes remote push from deployed feed')
    local = subprocess.run(['bash', str(test), str(feed)], env=dict(env, TEST_PUSH_EXIT='42', BEAMOS_LOCAL_ONLY='1'), capture_output=True, text=True)
    assert local.returncode == 0 and 'public feed unchanged' in local.stdout and 'pushed online' not in local.stdout, local
    print('PASS deliberate local staging never implies public deployment')
    print('Passed 3 publication checks. Fake Git only; no network or real repository writes.')
