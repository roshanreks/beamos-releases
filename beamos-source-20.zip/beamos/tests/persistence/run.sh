#!/bin/bash
# Runs real Mapping/CoachSession code in an isolated Android VM with fake display/Binder boundaries.
# No APK installation, projector geometry writes, app navigation, or live scene changes.
# Usage: bash beamos/tests/persistence/run.sh <adb-serial>
set -euo pipefail
SERIAL=${1:?Pass the connected Android adb serial explicitly}
LAB=$(cd "$(dirname "$0")/../../.." && pwd)
SDK=${ANDROID_HOME:-/opt/homebrew/share/android-commandlinetools}
J=/opt/homebrew/opt/openjdk@17/bin
TMP=$(mktemp -d)
REMOTE="/data/local/tmp/beamos-persistence-test-$$-$RANDOM"
cleanup() { rm -rf "$TMP"; adb -s "$SERIAL" shell rm -rf "$REMOTE" >/dev/null 2>&1 || true; }
trap cleanup EXIT
mkdir -p "$TMP/classes" "$TMP/dex"
"$J/javac" --release 8 -encoding UTF-8 -cp "$SDK/platforms/android-30/android.jar" -d "$TMP/classes" \
  "$LAB"/beamos/tests/persistence/src/com/beamos/studio/*.java \
  "$LAB/beamos/studio/src/com/beamos/studio/CoachSession.java" \
  "$LAB/beamos/studio/src/com/beamos/studio/CameraCalibration.java" \
  "$LAB/beamos/studio/src/com/beamos/studio/CameraControl.java" \
  "$LAB/beamos/studio/src/com/beamos/studio/ScreenFit.java" \
  "$LAB/beamos/studio/src/com/beamos/studio/Json.java" \
  "$LAB/beamos/studio/src/com/beamos/studio/Mapping.java" \
  "$LAB/beamos/common/src/com/beamos/common/Contract.java"
find "$TMP/classes" -name '*.class' > "$TMP/classes.list"
PATH="$J:$PATH" "$SDK/build-tools/34.0.0/d8" --min-api 30 --lib "$SDK/platforms/android-30/android.jar" --output "$TMP/dex" @"$TMP/classes.list"
adb -s "$SERIAL" shell mkdir -p "$REMOTE/state" >/dev/null
adb -s "$SERIAL" push "$TMP/dex/classes.dex" "$REMOTE/classes.dex" >/dev/null
adb -s "$SERIAL" shell "CLASSPATH=$REMOTE/classes.dex app_process / com.beamos.studio.PersistenceTest $REMOTE/state"
