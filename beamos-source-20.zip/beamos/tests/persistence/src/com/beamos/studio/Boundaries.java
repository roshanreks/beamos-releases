package com.beamos.studio;

import android.content.Context;
import android.os.Bundle;
import com.beamos.common.Contract;
import org.json.JSONObject;
import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

// These test doubles make it impossible for this test VM to call the display adapter or navigate apps.
final class Studio { static final String TAG = "BeamPersistenceTest"; }
final class Events { static volatile JSONObject latest; static void publish(JSONObject s) { latest = s; } }
final class PlaybackPoller { static boolean playing() { return false; } }
final class MappingActivity {
    static boolean visible;
    static JSONObject shown;
    static File mediaDir(Context c) { File f = new File(c.getFilesDir(), "mapping"); f.mkdirs(); return f; }
    static File sceneFile(Context c) { return new File(mediaDir(c), "scene.json"); }
    static boolean showing() { return visible; }
    static void close() { visible = false; }
    static void apply(JSONObject scene) { shown = scene; }
}
final class HttpServer {
    static final class Request {
        String method = "POST"; Map<String, String> params = new HashMap<>();
        InputStream stream; long streamLen; byte[] body = new byte[0];
    }
    static final class Response {
        int status; byte[] body; Map<String, String> headers = new HashMap<>();
        static Response json(int status, String body) { Response r = new Response(); r.status = status; r.body = body.getBytes(java.nio.charset.StandardCharsets.UTF_8); return r; }
        static Response bytes(String type, byte[] body) { Response r = new Response(); r.status = 200; r.body = body; return r; }
    }
}
final class AdapterClient {
    private static final AdapterClient INSTANCE = new AdapterClient();
    int[] vals = {180,180,180,180,180,180,180,180}, original;
    boolean active, confirmFails, auto = true;
    int confirms;
    volatile java.util.concurrent.CountDownLatch nextReadCaptured, nextReadRelease, nextPreviewCaptured, nextPreviewRelease;
    static AdapterClient get(Context c) { return INSTANCE; }
    Bundle call(int code, Bundle in) {
        if (code == Contract.KS_GET && nextReadCaptured != null) {
            Bundle old = new Bundle();
            java.util.concurrent.CountDownLatch captured, release;
            synchronized (this) {
                captured = nextReadCaptured; release = nextReadRelease; nextReadCaptured = null;
                old.putBoolean(Contract.KEY_OK, true); old.putIntArray("vals", vals.clone());
                old.putBoolean("previewActive", active); old.putString("previewId", active ? "test-preview" : null);
            }
            captured.countDown();
            try { release.await(5, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException e) { throw new AssertionError(e); }
            return old;
        }
        synchronized (this) {
        Bundle r = new Bundle(); r.putBoolean(Contract.KEY_OK, true);
        switch (code) {
            case Contract.KS_GET: r.putIntArray("vals", vals.clone()); r.putBoolean("previewActive", active); r.putString("previewId", active ? "test-preview" : null); break;
            case Contract.AUTO_KS: auto = in.getBoolean("on"); break;
            case Contract.KS_PREVIEW:
                if (!active) original = vals.clone();
                vals = in.getIntArray("vals").clone(); active = true; r.putString("id", "test-preview");
                if(nextPreviewCaptured!=null){java.util.concurrent.CountDownLatch captured=nextPreviewCaptured,release=nextPreviewRelease;nextPreviewCaptured=null;captured.countDown();try{release.await(5,java.util.concurrent.TimeUnit.SECONDS);}catch(InterruptedException e){throw new AssertionError(e);}}
                break;
            case Contract.KS_CONFIRM:
                if (confirmFails || !active) r.putBoolean(Contract.KEY_OK, false);
                else { active = false; original = null; confirms++; } break;
            case Contract.KS_CANCEL:
                if (active) { vals = original.clone(); active = false; original = null; } break;
            default: throw new AssertionError("Unexpected adapter operation " + code);
        }
        return r;
        }
    }
}

final class GuideOverlay {
    private static final GuideOverlay INSTANCE=new GuideOverlay();
    static GuideOverlay get(Context c){return INSTANCE;}
    boolean show(boolean on){return true;}
}
