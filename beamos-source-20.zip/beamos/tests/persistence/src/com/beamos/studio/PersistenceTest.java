package com.beamos.studio;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Looper;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.util.Arrays;

public final class PersistenceTest {
    private static int count;
    private interface Condition { boolean ok() throws Exception; }
    private static void check(String label, boolean ok) { if (!ok) throw new AssertionError(label); count++; System.out.println("PASS " + label); }
    private static void await(String label, Condition c) throws Exception {
        long until = System.currentTimeMillis() + 5000;
        while (!c.ok() && System.currentTimeMillis() < until) Thread.sleep(10);
        check(label, c.ok());
    }
    private static final class TestContext extends ContextWrapper {
        final File root;
        TestContext(File root) { super(null); this.root = root; }
        @Override public Context getApplicationContext() { return this; }
        @Override public File getFilesDir() { return root; }
        @Override public String getPackageName() { return "com.beamos.persistence.test"; }
        private final java.util.Map<String,android.content.SharedPreferences> prefs=new java.util.HashMap<>();
        @Override public android.content.SharedPreferences getSharedPreferences(String name,int mode){
            if(!prefs.containsKey(name))try{java.lang.reflect.Constructor<?> ctor=Class.forName("android.app.SharedPreferencesImpl").getDeclaredConstructor(File.class,int.class);ctor.setAccessible(true);prefs.put(name,(android.content.SharedPreferences)ctor.newInstance(new File(root,name+".xml"),mode));}catch(Exception e){throw new RuntimeException(e);}return prefs.get(name);
        }
        @Override public void startActivity(Intent i) { MappingActivity.visible = true; }
    }
    private static JSONObject scene(String name, String colour) throws Exception {
        return new JSONObject().put("surfaces", new JSONArray().put(new JSONObject().put("id", name).put("name", name)
                .put("type", "color").put("color", colour).put("quad", new JSONArray("[[0.1,0.1],[0.9,0.1],[0.9,0.9],[0.1,0.9]]"))));
    }
    private static void mapping(TestContext c) throws Exception {
        Mapping m = Mapping.get(c);
        JSONObject saved = scene("My wall", "#123456"), markers = scene("Temporary markers", "#ff0000");
        m.setScene(saved);
        byte[] before = Files.readAllBytes(MappingActivity.sceneFile(c).toPath());
        MappingActivity.visible = true;
        m.handle(new HttpServer.Request(), "/api/mapping/calibration/start", new JSONObject().put("scene", markers));
        check("calibration output uses markers", m.outputScene().toString().equals(markers.toString()));
        check("calibration preserves saved scene bytes", Arrays.equals(before, Files.readAllBytes(MappingActivity.sceneFile(c).toPath())));
        check("scene reads during calibration return user scene", m.scene().toString().equals(saved.toString()));
        m.endCalibration();
        check("calibration stop restores previous live scene", MappingActivity.visible && MappingActivity.shown.toString().equals(saved.toString()));
        MappingActivity.visible = false;
        m.handle(new HttpServer.Request(), "/api/mapping/calibration/start", new JSONObject().put("scene", markers));
        java.lang.reflect.Field timeout = Mapping.class.getDeclaredField("calibrationTimeout"); timeout.setAccessible(true);
        ((Runnable) timeout.get(m)).run();
        check("cancelled/abandoned calibration does not leave an output running", !MappingActivity.visible && !m.calibrating());
        check("calibration timeout preserves saved scene", m.scene().toString().equals(saved.toString()));
        // AtomicFile must recover a durable previous scene if a write is interrupted.
        File f = MappingActivity.sceneFile(c);
        Files.copy(f.toPath(), new File(f + ".bak").toPath());
        try (FileOutputStream out = new FileOutputStream(f)) { out.write("interrupted write".getBytes("UTF-8")); }
        check("interrupted scene write recovers atomic backup", m.scene().toString().equals(saved.toString()));
        Bitmap b = Bitmap.createBitmap(20, 10, Bitmap.Config.ARGB_8888);
        ByteArrayOutputStream photo = new ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 65, photo); b.recycle();
        m.handle(new HttpServer.Request(), "/api/mapping/reference", new JSONObject().put("image", "data:image/jpeg;base64," + Base64.encodeToString(photo.toByteArray(), Base64.NO_WRAP)));
        java.lang.reflect.Field instance = Mapping.class.getDeclaredField("instance"); instance.setAccessible(true); instance.set(null, null);
        Mapping reloaded = Mapping.get(c);
        check("scene survives store recreation", reloaded.scene().toString().equals(saved.toString()));
        HttpServer.Request get = new HttpServer.Request(); get.method = "GET";
        check("room photo survives store recreation", Arrays.equals(photo.toByteArray(), reloaded.handle(get, "/api/mapping/reference", new JSONObject()).body));
        JSONObject status = new JSONObject(new String(reloaded.handle(get, "/api/mapping", new JSONObject()).body, "UTF-8"));
        check("room reference is excluded from media library", status.getJSONArray("media").length() == 0);
        check("calibration does not persist across recreation", !reloaded.calibrating() && reloaded.outputScene().toString().equals(saved.toString()));
    }
    private static void coach(TestContext c) throws Exception {
        CoachSession cs = CoachSession.get(c);
        AdapterClient adapter = AdapterClient.get(c);
        await("coach loads current adapter values", cs::loaded);
        cs.nudge("TL", 1, 0, 5);
        await("ordinary adjustment is automatically confirmed", () -> !cs.dirty() && !adapter.active && adapter.confirms > 0);
        check("manual alignment disables automatic tilt overwrite", !adapter.auto);
        int[] kept = cs.vals();
        cs.load();
        check("reloading reads the saved adjustment", Arrays.equals(kept, cs.vals()));
        cs.undo();
        await("undo is also saved automatically", () -> !cs.dirty() && !adapter.active);
        check("undo restores the prior alignment", !Arrays.equals(kept, cs.vals()));
        adapter.confirmFails = true;
        cs.nudge("TR", -1, 0, 5);
        await("failed confirmation remains visibly unsaved", () -> cs.dirty() && !cs.state().optString("error").isEmpty());
        adapter.confirmFails = false;
        cs.nudge("TR", -1, 0, 5);
        await("retry saves after a failed confirmation", () -> !cs.dirty() && !adapter.active);
        int[] original = cs.vals();
        int[] test = original.clone(); test[2] += 5;
        cs.preview(test);
        await("explicit Settings preview remains temporary", () -> cs.dirty() && adapter.active && cs.state().optBoolean("temporary"));
        cs.revert();
        await("explicit preview can revert to the last saved alignment", () -> Arrays.equals(original, cs.vals()) && !adapter.active);
        check("save-now on an already saved adjustment succeeds", cs.keep());
        cs.preview(test);
        await("second safety preview starts", () -> cs.dirty() && adapter.active);
        cs.nudge("BL", 1, 0, 5);
        await("new manual adjustment supersedes temporary preview", () -> !cs.dirty() && !adapter.active);
        int[] latest = cs.vals();
        cs.revert(); // represents the older Settings dialog's delayed timeout
        Thread.sleep(80);
        check("old preview timeout cannot undo a newer saved adjustment", Arrays.equals(latest, cs.vals()) && !cs.dirty());
        adapter.nextReadCaptured = new java.util.concurrent.CountDownLatch(1);
        adapter.nextReadRelease = new java.util.concurrent.CountDownLatch(1);
        java.util.concurrent.CountDownLatch captured = adapter.nextReadCaptured, release = adapter.nextReadRelease;
        Thread oldRead = new Thread(cs::load); oldRead.start();
        check("delayed state read captures the old alignment", captured.await(5, java.util.concurrent.TimeUnit.SECONDS));
        cs.nudge("BR", 1, 0, 5);
        await("new adjustment saves while an older state read is delayed", () -> !cs.dirty() && !adapter.active);
        latest = cs.vals();
        release.countDown(); oldRead.join(5000);
        check("delayed old state cannot overwrite a newer saved alignment", Arrays.equals(latest, cs.vals()));
        int[] baseline=cs.vals(),photoFit={143,346,143,232,143,143,143,295};
        int[] stale=baseline.clone();stale[0]++;
        boolean rejected=false;try{cs.previewVerified(stale,photoFit);}catch(IllegalStateException expected){rejected=true;}
        check("photo captured with stale geometry cannot move the projector",rejected&&Arrays.equals(baseline,cs.vals()));
        double[] h={3,0,0,.5,2,0,.5,0,1};
        ScreenFit fit=ScreenFit.get(c);
        JSONObject applied=fit.fit(new JSONObject().put("baseline",new JSONArray(baseline)).put("vals",new JSONArray(photoFit)).put("panelToPlane",new JSONArray(h)).put("reference","wall-reference"));
        check("photo fit confirms all four actual corners and saves automatically",Arrays.equals(photoFit,adapter.vals)&&!adapter.active&&!cs.dirty()&&applied.getJSONObject("fit").getBoolean("canResize"));
        int[] bigger=ScreenFit.scaled(h,photoFit,1.025);
        JSONObject resized=fit.resize(new JSONObject().put("baseline",new JSONArray(photoFit)).put("scale",1.025));
        check("proportional resize reaches the expected hardware geometry",Arrays.equals(bigger,adapter.vals)&&!adapter.active);
        double[][] before=ScreenFit.corners(photoFit),after=ScreenFit.corners(bigger);for(int i=0;i<4;i++){before[i]=ScreenFit.point(h,before[i]);after[i]=ScreenFit.point(h,after[i]);}
        double beforeW=before[1][0]-before[0][0],beforeH=before[3][1]-before[0][1],afterW=after[1][0]-after[0][0],afterH=after[3][1]-after[0][1];
        check("resize preserves physical wall aspect under tilted optics",Math.abs(afterW/afterH-beforeW/beforeH)<0.015);
        check("resize grows both dimensions by the same requested amount",Math.abs(afterW/beforeW-1.025)<0.006&&Math.abs(afterH/beforeH-1.025)<0.006);
        java.lang.reflect.Field sf=ScreenFit.class.getDeclaredField("instance");sf.setAccessible(true);sf.set(null,null);fit=ScreenFit.get(new TestContext(c.root));
        check("fitted wall transform survives controller recreation",fit.state().getBoolean("canResize"));
        fit.undo(new JSONObject().put("baseline",new JSONArray(bigger)));
        check("undo resize restores and saves the prior fit",Arrays.equals(photoFit,adapter.vals)&&!adapter.active&&fit.state().getBoolean("canResize"));
        int[] resizedAgain=Json.ints(fit.resize(new JSONObject().put("baseline",new JSONArray(photoFit)).put("scale",1.025)).getJSONArray("vals"),8);
        cs.nudge("TL",1,0,1);await("later manual edit saves",()->!cs.dirty());
        int[] manual=cs.vals();
        rejected=false;try{fit.undo(new JSONObject().put("baseline",new JSONArray(resizedAgain)));}catch(IllegalStateException expected){rejected=true;}
        check("stale fit undo never overwrites a later manual adjustment",rejected&&Arrays.equals(manual,adapter.vals));
        check("manual corner changes invalidate proportional resize instead of distorting",!fit.state().getBoolean("canResize"));
        rejected=false;try{ScreenFit.scaled(h,photoFit,1.5);}catch(IllegalArgumentException expected){rejected=true;}
        check("unbounded resize requests are rejected",rejected);
    }
    private static long cameraTime=1000;
    private static int cameraSequence;
    private static JSONObject cameraFrame(String lease,int[] vals,String jpeg)throws Exception{
        JSONObject e=new JSONObject().put("markers",4).put("maxErrorMm",2).put("aspectError",0.001).put("confidence",0.99).put("captureAgeMs",100).put("planeStable",true).put("obstaclesChecked",true).put("reference","lidar").put("targetId","test-wall").put("vals",new JSONArray(vals));
        return new JSONObject().put("lease",lease).put("sequence",++cameraSequence).put("jpeg",jpeg).put("evidence",e);
    }
    private static void cameraOwnership(TestContext ctx)throws Exception{
        CameraCalibration camera=new CameraCalibration(()->cameraTime);
        java.lang.reflect.Field instance=CameraCalibration.class.getDeclaredField("instance");instance.setAccessible(true);instance.set(null,camera);
        CameraControl control=CameraControl.get(ctx);CoachSession coach=CoachSession.get(ctx);AdapterClient adapter=AdapterClient.get(ctx);
        Bitmap bitmap=Bitmap.createBitmap(20,20,Bitmap.Config.ARGB_8888);ByteArrayOutputStream out=new ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.JPEG,60,out);bitmap.recycle();String jpeg=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
        int[] baseline=coach.vals(),target=baseline.clone();target[2]+=2;
        String lease=camera.start("test").getString("lease");coach.setGuide("scan");camera.publish(cameraFrame(lease,baseline,jpeg),baseline);
        control.preview(new JSONObject().put("lease",lease).put("baseline",new JSONArray(baseline)).put("vals",new JSONArray(target)));
        check("camera writes stay temporary until measured verification",coach.state().optBoolean("temporary")&&adapter.active);
        cameraTime+=2500;camera.expire();
        check("lost camera rolls back only its unfinished preview",Arrays.equals(baseline,adapter.vals)&&!adapter.active&&"off".equals(coach.guide()));
        boolean rejected=false;try{control.preview(new JSONObject().put("lease",lease).put("baseline",new JSONArray(baseline)).put("vals",new JSONArray(target)));}catch(IllegalStateException expected){rejected=true;}
        check("expired camera cannot write geometry",rejected);
        lease=camera.start("second").getString("lease");coach.setGuide("scan");camera.publish(cameraFrame(lease,baseline,jpeg),baseline);
        control.preview(new JSONObject().put("lease",lease).put("baseline",new JSONArray(baseline)).put("vals",new JSONArray(target)));
        String owner=coach.cameraOwner();coach.previewVerified(target,target);
        check("new preview with identical coordinates has a different owner",!coach.ownsCameraPreview(owner));
        cameraTime+=2500;camera.expire();
        check("old camera expiry cannot cancel a later same-value preview",adapter.active&&Arrays.equals(target,adapter.vals));coach.revert();
        lease=camera.start("racing manual").getString("lease");coach.setGuide("scan");camera.publish(cameraFrame(lease,baseline,jpeg),baseline);
        adapter.nextPreviewCaptured=new java.util.concurrent.CountDownLatch(1);adapter.nextPreviewRelease=new java.util.concurrent.CountDownLatch(1);
        java.util.concurrent.CountDownLatch previewCaptured=adapter.nextPreviewCaptured,previewRelease=adapter.nextPreviewRelease;
        final JSONObject racing=new JSONObject().put("lease",lease).put("baseline",new JSONArray(baseline)).put("vals",new JSONArray(target));
        java.util.concurrent.atomic.AtomicBoolean raceRejected=new java.util.concurrent.atomic.AtomicBoolean();
        Thread cameraWrite=new Thread(()->{try{control.preview(racing);}catch(Exception expected){raceRejected.set(true);}});cameraWrite.start();
        check("camera preview reaches the isolated adapter barrier",previewCaptured.await(5,java.util.concurrent.TimeUnit.SECONDS));
        coach.preview(target);previewRelease.countDown();cameraWrite.join(5000);
        check("same-coordinate manual preview during a camera command rejects camera ownership",raceRejected.get());
        cameraTime+=2500;camera.expire();check("racing manual preview is not cancelled by old camera expiry",adapter.active&&Arrays.equals(target,adapter.vals));coach.revert();
        lease=camera.start("third").getString("lease");coach.setGuide("scan");camera.publish(cameraFrame(lease,baseline,jpeg),baseline);
        control.preview(new JSONObject().put("lease",lease).put("baseline",new JSONArray(baseline)).put("vals",new JSONArray(target)));
        coach.set(target,true);await("manual same-value adjustment saves",()->!coach.dirty());cameraTime+=2500;camera.expire();
        check("manual saved edit survives old camera expiry",!adapter.active&&Arrays.equals(target,adapter.vals));
        int[] full={0,0,0,0,0,0,0,0};coach.applyVerified(coach.vals(),full);
        lease=camera.start("save").getString("lease");coach.setGuide("scan");camera.publish(cameraFrame(lease,full,jpeg),full);
        control.preview(new JSONObject().put("lease",lease).put("baseline",new JSONArray(full)).put("vals",new JSONArray(full)));
        JSONObject save=new JSONObject().put("lease",lease).put("baseline",new JSONArray(full)).put("vals",new JSONArray(full)).put("panelToPlane",new JSONArray(new double[]{16./9,0,0,0,1,0,0,0,1})).put("reference","lidar");
        rejected=false;try{control.keep(save);}catch(IllegalStateException expected){rejected=true;}check("camera cannot save without stable measured green",rejected);
        for(int i=0;i<5;i++){cameraTime+=500;camera.publish(cameraFrame(lease,full,jpeg),full);}control.keep(save);
        check("verified LiDAR fit saves a durable resize profile",!adapter.active&&ScreenFit.get(ctx).state().getBoolean("canResize")&&"lidar".equals(ScreenFit.get(ctx).state().getString("reference")));
        cameraTime+=2500;camera.expire();check("camera expiry never reverts a confirmed fit",Arrays.equals(full,adapter.vals)&&!adapter.active);
        JSONObject small=ScreenFit.get(ctx).resize(new JSONObject().put("baseline",new JSONArray(full)).put("scale",0.9));
        int[] smaller=Json.ints(small.getJSONArray("vals"),8);boolean outside=false;
        try{ScreenFit.get(ctx).resize(new JSONObject().put("baseline",new JSONArray(smaller)).put("scale",1.2));}catch(IllegalArgumentException expected){outside=true;}
        check("LiDAR resizing cannot expand into unverified obstacle space",outside&&Arrays.equals(smaller,adapter.vals));
    }
    public static void main(String[] args) {
        try {
            Looper.prepareMainLooper();
            TestContext c = new TestContext(new File(args[0]));
            mapping(c); coach(c); cameraOwnership(c);
            System.out.println("Passed " + count + " persistence checks. Fake adapter only; live projector state untouched.");
            System.exit(0);
        } catch (Throwable t) { t.printStackTrace(); System.exit(1); }
    }
}
