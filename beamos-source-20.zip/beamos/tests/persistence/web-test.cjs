// Runs the actual companion save/load functions with deferred network responses.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '../../studio/assets/web/index.html'), 'utf8');
const script = html.split('<script>')[1].split('</script>')[0];
const section = (a, b) => script.slice(script.indexOf(a), script.indexOf(b, script.indexOf(a)));
const source = section('const mp =', 'const mcv =') + '\n' +
  section('let mapTimer =', 'function mapPos(') + '\n' +
  section('async function mapLoad(', 'function mapScenes(') + '\n' +
  section('function onEvent(', '// ---------- pairing');
let checks = 0;
function check(label, fn) { fn(); checks++; console.log('PASS ' + label); }
const scene = name => ({surfaces: [{id: 'wall', name, type: 'color', color: '#123456', quad: [[0,0],[1,0],[1,1],[0,1]]}]});
function fixture() {
  const requests = [], store = new Map(), elements = new Map(), toasts = [];
  const c = { location: {host: 'test-projector'}, token: 'test-token', mapDraw() {}, mapScenes() {}, mapSel() {},
    setTimeout() { return 1; }, clearTimeout() {}, toast: m => toasts.push(m), confirm: () => true,
    $: selector => { if (!elements.has(selector)) elements.set(selector, {textContent: ''}); return elements.get(selector); },
    localStorage: {getItem: k => store.get(k) || null, setItem: (k,v) => store.set(k,v), removeItem: k => store.delete(k)},
    api: (route, body) => new Promise((resolve, reject) => requests.push({route, body, resolve, reject})),
    safe: p => p.catch(() => {}), Image: class {}, coachState() {}, playbackState() {}, openSheet() {}, closeSheet() {}
  };
  vm.createContext(c); vm.runInContext(source, c);
  return {c, requests, store, toasts, run: code => vm.runInContext(code, c)};
}
const turn = () => new Promise(resolve => setImmediate(resolve));
(async () => {
  const f = fixture();
  f.c.data = scene('first'); f.run('mp.loaded = true; mp.scene = data; mapTouch();');
  const first = f.run('mapFlush()'); await turn();
  f.c.data = scene('second'); f.run('mp.scene = data; mapTouch();');
  const second = f.run('mapFlush()'); await turn();
  check('scene writes are serialized', () => assert.equal(f.requests.length, 1));
  check('edit is backed up before network confirmation', () => assert.match([...f.store.values()][0], /second/));
  f.requests[0].resolve({ok:true}); await first; await turn();
  check('newer draft survives an older save acknowledgement', () => assert.equal(f.store.size, 1));
  check('latest queued scene is saved second', () => assert.equal(f.requests[1].body.scene.surfaces[0].name, 'second'));
  f.requests[1].resolve({ok:true}); await second;
  check('draft clears only after newest save confirmation', () => assert.equal(f.store.size, 0));
  f.c.data = scene('offline'); f.run('mp.scene=data; mapTouch();');
  const failed = f.run('mapFlush()'); await turn(); f.requests[2].reject(new Error('offline'));
  await failed.catch(() => {});
  check('failed save keeps recoverable edit and pending status', () => { assert.equal(f.store.size,1); assert.equal(f.run('mp.pending'),true); });
  const retry = f.run('mapFlush()'); await turn(); f.requests[3].resolve({ok:true}); await retry;
  check('retry persists the current edit', () => assert.equal(f.run('mp.saved === mp.edit'), true));
  const load = f.run('mapLoad()'); await turn();
  f.c.data = scene('new edit during read'); f.run('mp.scene=data; mapTouch();');
  f.requests[4].resolve({scene: scene('stale read'), media:[],scenes:[],showing:false,freeMb:100}); await load;
  check('stale read cannot overwrite a newer local edit', () => assert.equal(f.run('mp.scene.surfaces[0].name'), 'new edit during read'));
  const restored = fixture(); restored.store.set('beamMapDraft:test-projector', JSON.stringify(scene('unsent after refresh')));
  const reload = restored.run('mapLoad()'); await turn();
  restored.requests[0].resolve({scene:scene('server'),media:[],scenes:[],showing:false,freeMb:100}); await reload;
  check('unsent edits can recover after browser refresh', () => assert.equal(restored.run('mp.scene.surfaces[0].name'), 'unsent after refresh'));
  restored.run('onEvent({t:"kept",ok:true}); onEvent({t:"reverted"});');
  check('saved and undo confirmations render without obsolete countdown state', () => assert.equal(restored.toasts.length, 2));
  console.log(`Passed ${checks} companion persistence checks. No device requests.`);
})().catch(e => { console.error(e); process.exitCode=1; });
