package com.beamos.studio;
import android.content.Context;
import android.os.Bundle;
import com.beamos.common.Contract;
final class Studio {static final String TAG="BeamPictureTest";}
final class AdapterClient {
 static final AdapterClient INSTANCE=new AdapterClient();
 int[] vals={50,50,50,50,40,100,1,1,0,0,3,0,0}; int lamp=2; boolean fail;
 static AdapterClient get(Context c){return INSTANCE;}
 synchronized Bundle call(int code,Bundle in){
  Bundle b=new Bundle();b.putBoolean(Contract.KEY_OK,true);
  if(code==Contract.PIC_APPLY){
   int[] next=in.getIntArray("vals"); int mode=in.getInt("lampMode");
   if(fail||next==null||next.length!=13||mode<0||mode>2){b.putBoolean(Contract.KEY_OK,false);b.putString(Contract.KEY_ERR,"test adapter refused preset");return b;}
   for(int i=0;i<13;i++)if(next[i]<(i==5?10:0)||next[i]>(i<6?100:i==10?4:i==12?1:3)){b.putBoolean(Contract.KEY_OK,false);b.putString(Contract.KEY_ERR,"out of range");return b;}
   vals=next.clone();lamp=mode;
  }else if(code!=Contract.PIC_GET)throw new AssertionError("Unexpected operation "+code);
  b.putString("mode","custom");b.putInt("lampMode",lamp);b.putString("panelBrightness","100");
  b.putIntArray("ids",new int[]{1,2,3,4,5,6,7,8,9,10,11,12,13});b.putIntArray("vals",vals.clone());return b;
 }
}
