package com.beamos.studio;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;

public final class PictureTest {
 static int count;
 interface Task {void run() throws Exception;}
 static void check(String name,boolean ok){if(!ok)throw new AssertionError(name);count++;System.out.println("PASS "+name);}
 static void rejects(String name,Task action)throws Exception{try{action.run();throw new AssertionError(name);}catch(IllegalArgumentException|IllegalStateException expected){check(name,true);}}
 static final class TestContext extends ContextWrapper {
  final File dir;final Map<String,SharedPreferences> all=new HashMap<>();
  TestContext(File dir){super(null);this.dir=dir;}
  @Override public Context getApplicationContext(){return this;}
  @Override public SharedPreferences getSharedPreferences(String name,int mode){
   if(!all.containsKey(name))try{
    java.lang.reflect.Constructor<?> c=Class.forName("android.app.SharedPreferencesImpl").getDeclaredConstructor(File.class,int.class);c.setAccessible(true);
    all.put(name,(SharedPreferences)c.newInstance(new File(dir,name+".xml"),mode));
   }catch(Exception e){throw new RuntimeException(e);}return all.get(name);
  }
 }
 static void run(File dir)throws Exception{
  TestContext c=new TestContext(dir);PicturePresets p=PicturePresets.get(c);AdapterClient a=AdapterClient.INSTANCE;
  String[] ids={"bright_room","anime","youtube","netflix","standard","cinema","vivid","game","computer"};
  for(String id:ids){JSONObject r=p.select(id);check(id+" applies full light output",r.getInt("lampMode")==2&&r.getJSONArray("vals").getInt(5)==100&&r.getJSONArray("vals").getInt(12)==0);check(id+" retains selected look identity",id.equals(r.getString("activePreset")));}
  p.select("bright_room");int oldContrast=a.vals[1];p.setValues(new JSONObject().put("1",57));
  check("manual edit changes brightness without resetting the rest of the look",a.vals[0]==57&&a.vals[1]==oldContrast);
  check("manual edit selects and saves Custom",p.read().getString("activePreset").equals("custom"));
  p.select("cinema");p.select("custom");check("Custom recalls the last manual settings",a.vals[0]==57&&a.vals[1]==oldContrast);
  JSONObject saved=p.save("My picture","MacBook HDMI","");String id=saved.getString("activePreset");
  check("preset stores a device label",saved.getJSONArray("savedPresets").getJSONObject(0).getString("device").equals("MacBook HDMI"));
  p.select("vivid");p.select(id);check("named preset restores its picture values",a.vals[0]==57&&a.vals[1]==oldContrast);
  java.lang.reflect.Field instance=PicturePresets.class.getDeclaredField("instance");instance.setAccessible(true);instance.set(null,null);
  a.vals[0]=23;PicturePresets reopened=PicturePresets.get(new TestContext(dir));reopened.restore();
  check("presets survive controller recreation using real Android preference files",reopened.read().getJSONArray("savedPresets").length()==1);
  check("saved look restores after restart",a.vals[0]==57&&id.equals(reopened.read().getString("activePreset")));
  reopened.setValues(new JSONObject().put("2",54));reopened.save("My updated picture","iPhone mirror",id);
  check("update preserves the existing preset id",reopened.read().getJSONArray("savedPresets").length()==1);
  reopened.select("computer");reopened.select(id);check("updated preset restores new values",a.vals[1]==54);
  byte[] prior=java.nio.file.Files.readAllBytes(new File(dir,"picture_presets.xml").toPath());a.fail=true;
  rejects("failed hardware apply is reported",()->reopened.select("cinema"));a.fail=false;
  check("failed hardware apply does not overwrite the saved look",Arrays.equals(prior,java.nio.file.Files.readAllBytes(new File(dir,"picture_presets.xml").toPath())));
  rejects("unknown setting is rejected",()->reopened.setValues(new JSONObject().put("99",1)));
  rejects("fractional setting is rejected",()->reopened.setValues(new JSONObject().put("1",42.5)));
  rejects("out-of-range setting is rejected",()->reopened.setValues(new JSONObject().put("1",101)));
  rejects("blank preset name is rejected",()->reopened.save("  ","",""));
  int[] beforeDelete=a.vals.clone();reopened.delete(id);
  check("deleting a preset preserves the current picture",Arrays.equals(beforeDelete,a.vals));
  check("deleted preset is removed from every controller's list",reopened.read().getJSONArray("savedPresets").length()==0);
  reopened.lamp(1);check("explicit Eco choice remains available",a.lamp==1);reopened.select("bright_room");check("built-in look restores maximum lamp output",a.lamp==2);
  for(int i=0;i<32;i++)reopened.save("Preset "+i,"Test device","");
  rejects("preset count is bounded",()->reopened.save("One too many","",""));
 }
 public static void main(String[] args){try{run(new File(args[0]));System.out.println("Passed "+count+" picture-preset checks. Fake adapter, real isolated preference files; no display writes.");System.exit(0);}catch(Throwable e){e.printStackTrace();System.exit(1);}}
}
