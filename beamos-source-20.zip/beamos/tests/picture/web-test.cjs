const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(path.join(__dirname,'../../studio/assets/web/index.html'),'utf8');
const script=html.split('<script>')[1].split('</script>')[0];
const section=(a,b)=>script.slice(script.indexOf(a),script.indexOf(b,script.indexOf(a)));
const source=section('const PIC =','(function buildSliders')+'\n'+section('function flushPic()','(function picPump')+'\n'+section('function renderPic(','function pictureSelection(');
const elements=new Map(),requests=[];
const buttons=['bright_room','anime','youtube','netflix','standard','cinema','vivid','game','computer','custom'].map(id=>({dataset:{pmode:id},on:false,classList:{toggle(name,value){buttons.find(b=>b.dataset.pmode===id).on=value;}}}));
const c={Promise,setTimeout(){},location:{},pictureSelection(){},Option:class{constructor(text,value){this.text=text;this.value=value;}},
 $:s=>{if(!elements.has(s))elements.set(s,{value:'',textContent:'',children:[],replaceChildren(...x){this.children=x;this.value='';},append(x){this.children.push(x)}});return elements.get(s);},
 $$:s=>s==='[data-pmode]'?buttons:[],
 api:(route,body)=>new Promise((resolve,reject)=>requests.push({route,body,resolve,reject}))};
vm.createContext(c);vm.runInContext(source,c);const run=s=>vm.runInContext(s,c);
const picture=(brightness,id='custom')=>({ids:Array.from({length:13},(_,i)=>i+1),vals:[brightness,55,52,50,40,100,1,0,1,0,1,0,0],mode:'custom',lampMode:2,panelBrightness:'100',activePreset:id,activeLabel:id==='bright_room'?'Bright room':'Custom',savedOnProjector:true,savedPresets:[]});
const turn=()=>new Promise(r=>setImmediate(r));let count=0;function check(n,f){f();count++;console.log('PASS '+n)}
(async()=>{
 c.reply=picture(50);run('renderPic(reply);picPending[1]=55;picRevision++;');const first=run('flushPic()');await turn();
 check('sliders use the implemented HTTP picture endpoint',()=>assert.equal(requests[0].route,'/api/picture/set'));
 check('slider write contains the changed parameter',()=>assert.equal(requests[0].body.values['1'],55));
 run('picPending[1]=68;picRevision++;');const next=run('flushPic()');await turn();
 check('only one picture request is in flight',()=>assert.equal(requests.length,1));
 requests[0].resolve(picture(55));await first;await turn();
 check('old acknowledgement cannot replace newer slider state',()=>assert.equal(run('picSnapshot.vals[0]'),50));
 check('latest drag value follows the first acknowledgement',()=>assert.equal(requests[1].body.values['1'],68));
 requests[1].reject(Error('connection lost'));await next.catch(()=>{});
 check('failed write retains its value for retry',()=>assert.equal(run('picPending[1]'),68));
 check('failed write stops automatic retries and reports not applied',()=>{assert.equal(run('picPaused'),true);assert.match(elements.get('#picStatus').textContent,/Not applied/)});
 const retry=run('flushPic()');await turn();requests[2].resolve(picture(68));await retry;
 check('retry renders confirmed hardware readback',()=>assert.equal(elements.get('#pic1').value,68));
 check('confirmed write removes the pending draft',()=>assert.equal(run('Object.keys(picPending).length'),0));
 c.reply=picture(25);run('renderPic(reply,0);');
 check('stale read cannot reset a newer confirmed value',()=>assert.equal(elements.get('#pic1').value,68));
 c.reply=picture(52,'bright_room');run('renderPic(reply);');
 check('look identity is independent of vendor Custom mode',()=>{assert.equal(buttons.find(b=>b.dataset.pmode==='bright_room').on,true);assert.equal(buttons.find(b=>b.dataset.pmode==='custom').on,false)});
 check('saved status includes actual lamp and panel output',()=>assert.match(elements.get('#picStatus').textContent,/High-bright.*100%/));
 console.log(`Passed ${count} picture companion checks. No network or projector writes.`);
})().catch(e=>{console.error(e);process.exitCode=1});
