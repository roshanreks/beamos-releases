package com.beamos.studio;
public class CodeEntryTest {
 static int count;
 static void check(String s,boolean ok){if(!ok)throw new AssertionError(s);count++;System.out.println("PASS "+s);}
 static final class Host implements CodeEntry.Host {
  String[] cells;int at;boolean split,filter,changed;int writes;String app="test";
  Host(boolean split){this.split=split;cells=split?new String[]{"9","9","9","9","9","9"}:new String[]{"old"};}
  public CodeEntry.Field field(){return new CodeEntry.Field("field-"+at,app,true,cells[at].length());}
  public boolean digit(String d,boolean replace){writes++;if(!filter||cells[at].length()<1||replace)cells[at]=replace?d:cells[at]+d;return true;}
  public void settle(){if(split&&at<5)at++;if(changed&&writes==2)app="other app";}
  String value(){return String.join("",cells);}
 }
 public static void main(String[] args)throws Exception{
  Host single=new Host(false);check("single-field code succeeds",CodeEntry.send(single,"field-0","012345"));check("old code is replaced, leading zero retained",single.value().equals("012345"));
  Host split=new Host(true);check("auto-advancing code cells succeed",CodeEntry.send(split,"field-0","012345"));check("each old code cell is replaced once",split.value().equals("012345")&&split.writes==6);
  Host stale=new Host(false);check("old field token cannot type into another field",!CodeEntry.send(stale,"old-field","1234")&&stale.writes==0);
  Host other=new Host(true);other.changed=true;check("code stops if the foreground editor changes app",!CodeEntry.send(other,"field-0","123456")&&other.writes==2);
  Host filtered=new Host(false);filtered.filter=true;check("silent length-filter rejection is detected",!CodeEntry.send(filtered,"field-0","123456"));
  for(String value:new String[]{"","1234567890123","123abc"})try{CodeEntry.send(new Host(false),"field-0",value);throw new AssertionError("invalid code accepted");}catch(IllegalArgumentException expected){check("invalid code rejected",true);}
  System.out.println("Passed "+count+" OTP transaction checks.");
 }
}
