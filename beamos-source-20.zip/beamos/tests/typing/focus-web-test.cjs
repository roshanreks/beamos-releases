const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const html=fs.readFileSync(path.resolve(__dirname,'../../studio/assets/web/index.html'),'utf8'),s=html.split('<script>')[1].split('</script>')[0];
let opened=0;const c={tab:'picture',openSheet(){opened++},closeSheet(){},toast(){},coachState(){},playbackState(){}};vm.createContext(c);vm.runInContext(s.slice(s.indexOf('function onEvent('),s.indexOf('// ---------- pairing')),c);
for(const tab of ['picture','map','apps','more']){c.tab=tab;vm.runInContext('onEvent({t:"input",active:true})',c);assert.equal(opened,0);}
for(const [i,tab] of ['remote','live','type'].entries()){c.tab=tab;vm.runInContext('onEvent({t:"input",active:true})',c);assert.equal(opened,i+1);}
console.log('PASS projector text focus stays out of Picture/Map/Apps/More, remains available in Remote/Live/Type (7 checks)');
