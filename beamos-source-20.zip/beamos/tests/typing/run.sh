#!/bin/bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../../.." && pwd)
TMP=$(mktemp -d);trap 'rm -rf "$TMP"' EXIT
J=/opt/homebrew/opt/openjdk@17/bin
"$J/javac" --release 8 -d "$TMP" "$ROOT/beamos/studio/src/com/beamos/studio/CodeEntry.java" "$ROOT/beamos/tests/typing/CodeEntryTest.java"
"$J/java" -cp "$TMP" com.beamos.studio.CodeEntryTest
