import Foundation
import Security
import BeamCore

struct CoachReply: Decodable {
    let ok: Bool?
    let vals: [Int]
    let temporary: Bool?
    let cameraLayout: GuideLayout?
}
struct GuideLayout: Decodable {
    let width: Double, height: Double, size: Double, margin: Double
    func centres() throws -> [Point] { try Insets.markerCentres(width:width,height:height,size:size,margin:margin) }
}
struct CalibrationReply: Decodable {
    let ok: Bool?
    let lease: String?
    let live: Bool
    let geometryReady: Bool
    let stableFrames: Int
}

enum TokenStore {
    private static func query(_ host: String) -> [String: Any] { [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:"com.beamos.companion",kSecAttrAccount as String:host] }
    static func read(host: String) -> String? {
        var q=query(host); q[kSecReturnData as String]=true; q[kSecMatchLimit as String]=kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary,&result)==errSecSuccess, let data=result as? Data else { return nil }
        return String(data:data,encoding:.utf8)
    }
    static func save(_ token: String, host: String) throws {
        let q=query(host); SecItemDelete(q as CFDictionary)
        var entry=q;entry[kSecValueData as String]=Data(token.utf8);entry[kSecAttrAccessible as String]=kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        guard SecItemAdd(entry as CFDictionary,nil)==errSecSuccess else { throw CalibrationError.invalid("Could not save pairing securely") }
    }
}

private final class LocalSessionDelegate:NSObject,URLSessionTaskDelegate {
    func urlSession(_ session:URLSession,task:URLSessionTask,willPerformHTTPRedirection response:HTTPURLResponse,newRequest request:URLRequest,completionHandler:@escaping(URLRequest?)->Void){completionHandler(nil)}
}

actor BeamClient {
    nonisolated let base: URL
    nonisolated let token: String
    private let session: URLSession
    init(base: URL, token: String) {
        self.base=base; self.token=token
        let config=URLSessionConfiguration.ephemeral;config.timeoutIntervalForRequest=5;config.timeoutIntervalForResource=8
        config.httpShouldSetCookies=false;config.urlCache=nil;session=URLSession(configuration:config,delegate:LocalSessionDelegate(),delegateQueue:nil)
    }
    static func address(_ input: String) throws -> URL {
        let raw=input.trimmingCharacters(in:.whitespacesAndNewlines)
        guard var parts=URLComponents(string:raw.contains("://") ? raw : "http://"+raw), parts.scheme=="http", let host=parts.host,parts.user==nil,parts.password==nil else {
            throw CalibrationError.invalid("Enter the projector's local Wi-Fi address")
        }
        let components=host.split(separator:".",omittingEmptySubsequences:false)
        let bytes=components.compactMap { Int($0) }
        let privateIP=components.count==4 && bytes.count==4 && bytes.allSatisfy({ (0...255).contains($0) }) && (bytes[0]==10 || (bytes[0]==192&&bytes[1]==168) || (bytes[0]==172&&(16...31).contains(bytes[1])))
        guard privateIP || host.hasSuffix(".local") else { throw CalibrationError.invalid("Use a private network IP or .local projector name") }
        parts.port=parts.port ?? 8080;parts.path="";parts.query=nil;parts.fragment=nil
        guard let url=parts.url else { throw CalibrationError.invalid("Invalid projector address") };return url
    }
    func request<T: Decodable>(_ path: String, body: [String: Any]? = nil, as type: T.Type) async throws -> T {
        var req=URLRequest(url:base.appendingPathComponent(path.trimmingCharacters(in:CharacterSet(charactersIn:"/"))))
        req.httpMethod=body == nil ? "GET" : "POST";req.setValue(token,forHTTPHeaderField:"X-Beam-Token")
        req.setValue("application/json",forHTTPHeaderField:"Content-Type");req.cachePolicy = .reloadIgnoringLocalCacheData
        if let body { req.httpBody=try JSONSerialization.data(withJSONObject:body) }
        let (data,response)=try await session.data(for:req)
        guard let http=response as? HTTPURLResponse,(200..<300).contains(http.statusCode) else {
            let object=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any]
            throw CalibrationError.invalid(object?["err"] as? String ?? "Projector is unavailable; check Wi-Fi and BeamOS 0.20")
        }
        return try JSONDecoder().decode(T.self,from:data)
    }
    static func pair(base: URL, code: String) async throws -> BeamClient {
        struct Reply: Decodable { let token: String }
        guard code.count==6,code.unicodeScalars.allSatisfy({(48...57).contains($0.value)}) else { throw CalibrationError.invalid("Enter the 6-digit code shown by BeamOS") }
        let provisional=BeamClient(base:base,token:"")
        let reply=try await provisional.request("/api/pair",body:["code":code,"name":"iPhone wall camera"],as:Reply.self)
        try TokenStore.save(reply.token,host:base.absoluteString)
        return BeamClient(base:base,token:reply.token)
    }
}
