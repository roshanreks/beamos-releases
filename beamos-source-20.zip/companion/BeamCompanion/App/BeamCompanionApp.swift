import SwiftUI
import WebKit
import BeamCore

@main struct BeamCompanionApp:App {
    @StateObject private var engine=CalibrationEngine()
    @Environment(\.scenePhase) private var phase
    var body:some Scene {
        WindowGroup {
            TabView {
                NavigationStack {ScannerView(engine:engine)}.tabItem{Label("Wall scan",systemImage:"viewfinder")}
                if let client=engine.client {RemoteView(client:client).tabItem{Label("Remote",systemImage:"appletvremote.gen4")}}
            }.tint(.green).preferredColorScheme(.dark)
                .onChange(of:phase){_,value in if value == .background && engine.running {engine.stop()}}
        }
    }
}
struct ScannerView:View {
    @ObservedObject var engine:CalibrationEngine
    var body:some View {
        ScrollView {
            VStack(alignment:.leading,spacing:18){
                Text("A straight screen, without corner taps.").font(.largeTitle.bold())
                Text("Keep the whole projection and nearby obstructions in view. Scan slowly, then hold still. A test grid briefly covers the picture while audio can continue.").foregroundStyle(.secondary)
                if engine.client == nil {
                    VStack(spacing:12){
                        TextField("Projector address",text:$engine.address).keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        SecureField("Six-digit pairing code",text:$engine.code).keyboardType(.numberPad)
                        Button(engine.pairing ? "Connecting…":"Connect to BeamOS"){Task{await engine.connect()}}.disabled(engine.pairing).buttonStyle(.borderedProminent)
                    }.textFieldStyle(.roundedBorder)
                }
                if let image=engine.image {
                    Image(uiImage:image).resizable().scaledToFit().overlay {
                        GeometryReader {proxy in
                            Path {path in
                                let points=engine.targetImage
                                if let first=points.first {path.move(to:CGPoint(x:first.x*proxy.size.width,y:first.y*proxy.size.height));for p in points.dropFirst(){path.addLine(to:CGPoint(x:p.x*proxy.size.width,y:p.y*proxy.size.height))};path.closeSubpath()}
                            }.stroke(engine.verified ? Color.green:Color.yellow,lineWidth:3)
                            ForEach(Array(engine.blockedImage.enumerated()),id:\.offset){_,p in
                                Circle().fill(.red.opacity(0.6)).frame(width:7,height:7).position(x:p.x*proxy.size.width,y:p.y*proxy.size.height)
                            }
                        }
                    }.clipShape(RoundedRectangle(cornerRadius:18)).accessibilityLabel("Live projection wall camera. Yellow outline is the selected screen; red points are measured excluded space.")
                    Text("Outline: selected screen · red: measured excluded space").font(.caption).foregroundStyle(.secondary)
                }
                Label(engine.status,systemImage:engine.verified ? "checkmark.circle.fill":engine.running ? "viewfinder.circle":"info.circle")
                    .foregroundStyle(engine.verified ? .green:.primary).font(.headline).accessibilityAddTraits(.updatesFrequently)
                if !engine.detail.isEmpty{Text(engine.detail).font(.subheadline).foregroundStyle(.secondary)}
                if engine.client != nil {
                    Button(engine.running ? "Stop scan":"Scan and fit automatically"){
                        if engine.running{engine.stop()}else{engine.start()}
                    }.buttonStyle(.borderedProminent).controlSize(.large).tint(engine.running ? .orange:.green)
                }
                Text("Uses LiDAR to measure a vertical flat wall, excludes measured obstructions and unknown areas, then checks repeated camera frames before saving a 16:9 fit. Reflections, dark surfaces, depth holes and the projector's corner range can limit a fit. The displayed error is a camera estimate, not a guarantee of absolute accuracy.").font(.footnote).foregroundStyle(.secondary)
                Text("Your camera frames stay on your local network and expire when scanning stops. Only paired remotes can view them.").font(.footnote).foregroundStyle(.secondary)
            }.padding(20)
        }.navigationTitle("BeamOS")
    }
}
/// Reuse the projector's remote in the native app; restrict the pairing token to this exact local origin.
struct RemoteView:UIViewRepresentable {
    let client:BeamClient
    func makeCoordinator()->Coordinator{Coordinator(base:client.base)}
    func makeUIView(context:Context)->WKWebView {
        let configuration=WKWebViewConfiguration();configuration.websiteDataStore = .nonPersistent()
        let origin=client.base.absoluteString.trimmingCharacters(in:CharacterSet(charactersIn:"/"))
        let tokenData=try! JSONSerialization.data(withJSONObject:[client.token]),tokenLiteral=String(data:tokenData,encoding:.utf8)!
        let originData=try! JSONSerialization.data(withJSONObject:[origin]),originLiteral=String(data:originData,encoding:.utf8)!
        let script="if(location.origin === \(originLiteral)[0])localStorage.setItem('beamToken',\(tokenLiteral)[0]);"
        configuration.userContentController.addUserScript(WKUserScript(source:script,injectionTime:.atDocumentStart,forMainFrameOnly:true))
        let view=WKWebView(frame:.zero,configuration:configuration);view.navigationDelegate=context.coordinator
        view.load(URLRequest(url:client.base));return view
    }
    func updateUIView(_ view:WKWebView,context:Context){}
    final class Coordinator:NSObject,WKNavigationDelegate {
        let base:URL;init(base:URL){self.base=base}
        func webView(_ webView:WKWebView,decidePolicyFor action:WKNavigationAction,decisionHandler:@escaping(WKNavigationActionPolicy)->Void){
            guard let u=action.request.url,u.scheme==base.scheme,u.host==base.host,u.port==base.port else{decisionHandler(.cancel);return}
            decisionHandler(.allow)
        }
    }
}
