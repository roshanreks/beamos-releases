import SwiftUI
import ARKit
import AVFoundation
import ImageIO
import BeamCore

/// The AR delegate retains only the latest frame; slow vision work never queues a stream of full images.
final class FrameInbox: NSObject, ARSessionDelegate, @unchecked Sendable {
    private let lock=NSLock()
    private var frame: ARFrame?
    func session(_ session:ARSession,didUpdate frame:ARFrame){lock.lock();self.frame=frame;lock.unlock()}
    func latest(after timestamp:Double)->ARFrame? {lock.lock();defer{lock.unlock()};guard let frame,frame.timestamp>timestamp else{return nil};return frame}
    func clear(){lock.lock();frame=nil;lock.unlock()}
}
actor ScanWorker {
    private let scanner=WallScanner()
    func reset(){scanner.reset()}
    func scan(_ frame:ARFrame,geometry:Insets,orientation:CGImagePropertyOrientation)throws->WallScan {try scanner.process(frame,geometry:geometry,orientation:orientation)}
}

@MainActor final class CalibrationEngine: ObservableObject {
    @Published var address=UserDefaults.standard.string(forKey:"projectorAddress") ?? "192.168.1.11:8080"
    @Published var code=""
    @Published var client:BeamClient?
    @Published var status="Connect once, then point your iPhone at the projection wall."
    @Published var detail=""
    @Published var image:UIImage?
    @Published var targetImage:[Point]=[]
    @Published var blockedImage:[Point]=[]
    @Published var running=false
    @Published var verified=false
    @Published var pairing=false
    private let session=ARSession(),inbox=FrameInbox(),worker=ScanWorker()
    private var task:Task<Void,Never>?
    private var orientation:CGImagePropertyOrientation = .right

    func connect()async {
        guard !pairing,!running else{return};pairing=true;defer{pairing=false}
        do {
            let base=try BeamClient.address(address)
            let connection:BeamClient
            if let token=TokenStore.read(host:base.absoluteString),code.isEmpty {connection=BeamClient(base:base,token:token)}
            else {connection=try await BeamClient.pair(base:base,code:code)}
            struct Hello:Decodable {let version:String;let paired:Bool}
            let hello=try await connection.request("/api/hello",as:Hello.self)
            guard hello.paired else {throw CalibrationError.invalid("Pair again using the current six-digit projector code")}
            guard hello.version.compare("0.20",options:.numeric) != .orderedAscending else {throw CalibrationError.invalid("Update the projector to BeamOS 0.20 before automatic scanning")}
            client=connection;code="";UserDefaults.standard.set(address,forKey:"projectorAddress");status="Connected. Start a wall scan when the whole projection is visible."
        }catch{status=error.localizedDescription}
    }
    func start(){
        guard !running,let client else{return}
        running=true;verified=false;detail="";status="Preparing the wall scan…"
        task=Task{await run(client)}
    }
    func stop(){task?.cancel();session.pause();inbox.clear();status="Stopping scan and restoring any unfinished correction…"}
    private func check()throws{try Task.checkCancellation()}
    private func cameraOrientation()->CGImagePropertyOrientation {
        switch UIDevice.current.orientation {
        case .landscapeLeft:return .up
        case .landscapeRight:return .down
        case .portraitUpsideDown:return .left
        default:return .right
        }
    }
    private func run(_ client:BeamClient)async {
        var lease="",saved=false
        do {
            guard ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) else {throw CalibrationError.invalid("Automatic wall measurement needs an iPhone or iPad with LiDAR")}
            let permission=await AVCaptureDevice.requestAccess(for:.video);try check()
            guard permission else {throw CalibrationError.invalid("Allow camera access in Settings to scan the wall")}
            await worker.reset();inbox.clear()
            session.delegate=inbox;session.delegateQueue=DispatchQueue(label:"beam-ar-inbox")
            let configuration=ARWorldTrackingConfiguration();configuration.planeDetection=[.vertical];configuration.frameSemantics=[.sceneDepth];configuration.worldAlignment = .gravity
            session.run(configuration,options:[.resetTracking,.removeExistingAnchors])
            let started=try await client.request("/api/calibration/start",body:["source":"iPhone LiDAR wall scan"],as:CalibrationReply.self)
            guard let key=started.lease else{throw CalibrationError.invalid("Projector did not grant the camera session")};lease=key
            let guide=try await client.request("/api/coach/guide",body:["guide":"scan","on":true],as:CoachReply.self)
            var acknowledged=try Insets(guide.vals),acknowledgedAt=ProcessInfo.processInfo.systemUptime,lastTimestamp = -1.0
            var feedback=Feedback(),sequence=0,iterations=0,unchanged=0,bestError=Double.infinity,owned=false
            var lastTargetID=""
            let startedAt=ProcessInfo.processInfo.systemUptime
            while true {
                try check()
                if ProcessInfo.processInfo.systemUptime-startedAt>180 {throw CalibrationError.invalid("Scan timed out. Reposition the phone and start again; the saved screen has been retained")}
                guard let frame=inbox.latest(after:lastTimestamp) else {try await Task.sleep(nanoseconds:150_000_000);continue}
                lastTimestamp=frame.timestamp;orientation=cameraOrientation()
                let scan:WallScan
                do {scan=try await worker.scan(frame,geometry:acknowledged,orientation:orientation)}
                catch {status=error.localizedDescription;try await Task.sleep(nanoseconds:350_000_000);continue}
                try check()
                let now=ProcessInfo.processInfo.systemUptime,age=now-scan.capturedAt
                // Never renew a lease with old AR frames or allow a stale scan to move the projector.
                guard age>=0,age<0.75 else {status="Camera processing is too slow. Hold still and keep the screen in view.";continue}
                image=UIImage(data:scan.jpeg);targetImage=scan.targetImage;blockedImage=scan.blockedImage;status=scan.status;sequence+=1
                if scan.targetID != lastTargetID {lastTargetID=scan.targetID;bestError = .infinity;unchanged=0;feedback.reset()}
                detail="\(scan.markers)/4 markers · \(scan.widthMetres>0 ? String(format:"%.2f × %.2f m",scan.widthMetres,scan.heightMetres):"measuring wall")"
                let errorMm=scan.maximumError.isFinite ? scan.maximumError*1000 : -1
                let evidence:[String:Any]=["markers":scan.markers,"maxErrorMm":errorMm,"aspectError":scan.aspectError.isFinite ? scan.aspectError:-1,"confidence":scan.confidence,"captureAgeMs":age*1000,"planeStable":scan.planeStable,"obstaclesChecked":scan.obstaclesChecked,"reference":"lidar","targetId":scan.targetID,"vals":acknowledged.values,"screenQuad":scan.targetImage.map{[$0.x,$0.y]},"excluded":scan.blockedImage.map{[$0.x,$0.y]}]
                let published=try await client.request("/api/calibration/publish",body:["lease":lease,"sequence":sequence,"jpeg":scan.jpeg.base64EncodedString(),"evidence":evidence],as:CalibrationReply.self)
                let measurement=CameraMeasurement(sequence:sequence,capturedAt:scan.capturedAt,geometry:acknowledged,targetID:scan.targetID,markers:scan.markers,maximumErrorMetres:scan.maximumError,aspectError:scan.aspectError,confidence:scan.confidence,planeStable:scan.planeStable,obstaclesChecked:scan.obstaclesChecked)
                let ready=feedback.update(measurement,now:now,acknowledged:acknowledged,acknowledgedAt:acknowledgedAt)
                if ready && published.geometryReady && owned,let h=scan.panelToPlane {
                    _=try await client.request("/api/calibration/keep",body:["lease":lease,"baseline":acknowledged.values,"vals":acknowledged.values,"panelToPlane":h,"reference":"lidar"],as:CoachReply.self)
                    saved=true;verified=true;status="Screen verified and saved. Your next size change will keep its proportions."
                    detail=String(format:"Measured corner error ≤ %.1f mm · aspect error %.1f%%. Focus remains manual.",errorMm,scan.aspectError*100)
                    break
                }
                if scan.planeStable && scan.confidence>=0.9 && scan.markers==4,let proposal=scan.proposal,scan.capturedAt>=acknowledgedAt+0.3 {
                    // A no-change preview gives an already aligned screen the same expiry/save ownership guarantees.
                    if proposal != acknowledged || !owned {
                        if iterations>=30 || unchanged>=8 {throw CalibrationError.invalid("Correction is not converging. Move the projector closer to square-on and scan again")}
                        if scan.maximumError<bestError-0.001 {bestError=scan.maximumError;unchanged=0}else{unchanged+=1}
                        let actual=try await client.request("/api/calibration/preview",body:["lease":lease,"baseline":acknowledged.values,"vals":proposal.values],as:CoachReply.self)
                        acknowledged=try Insets(actual.vals);acknowledgedAt=ProcessInfo.processInfo.systemUptime;owned=true;iterations+=1;feedback.reset()
                    }
                }
                try await Task.sleep(nanoseconds:350_000_000)
            }
        }catch is CancellationError {if !saved {status="Scan stopped. The last saved picture is retained."}}
        catch {status=error.localizedDescription}
        session.pause();inbox.clear()
        if !lease.isEmpty {
            // This runs even after task cancellation; the server watchdog also rolls back an abandoned preview.
            _=try? await client.request("/api/calibration/stop",body:["lease":lease],as:CalibrationReply.self)
        }
        if saved {struct Ignored:Decodable{};_=try? await client.request("/api/coach/guide",body:["guide":"off","on":false],as:Ignored.self)}
        running=false;task=nil
    }
}
