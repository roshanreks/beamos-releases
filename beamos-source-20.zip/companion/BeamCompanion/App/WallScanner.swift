import ARKit
import Vision
import CoreImage
import ImageIO
import BeamCore

struct WallScan {
    var jpeg: Data
    var capturedAt: Double
    var status: String
    var markers=0
    var confidence=0.0
    var planeStable=false
    var obstaclesChecked=false
    var targetID=""
    var maximumError=Double.infinity
    var aspectError=Double.infinity
    var proposal: Insets?
    var panelToPlane: [Double]?
    var targetImage:[Point]=[]
    var blockedImage:[Point]=[]
    var target: [Point]=[]
    var observed: [Point]=[]
    var widthMetres=0.0
    var heightMetres=0.0
}

/// All measurement work stays on the phone. One instance is used by one serial processing loop.
final class WallScanner {
    private let context=CIContext(options:[.cacheIntermediates:false])
    private var wall: Wall?
    private var wallID: UUID?
    private var target: [Point]?
    private var targetID=""
    private var lastCamera: Vector?
    private var lastForward: Vector?
    private var stableCameraFrames=0
    private var blockedFrames=0

    func reset(){wall=nil;wallID=nil;target=nil;targetID="";lastCamera=nil;lastForward=nil;stableCameraFrames=0;blockedFrames=0}

    private func vector(_ v: SIMD3<Float>) -> Vector { Vector(Double(v.x),Double(v.y),Double(v.z)) }
    private func cameraPosition(_ f: ARFrame) -> Vector { let p=f.camera.transform.columns.3;return Vector(Double(p.x),Double(p.y),Double(p.z)) }
    private func direction(_ p: Point, frame: ARFrame) -> Vector {
        let k=frame.camera.intrinsics
        let local=SIMD4<Float>((Float(p.x)-k.columns.2.x)/k.columns.0.x,-(Float(p.y)-k.columns.2.y)/k.columns.1.y,-1,0)
        let q=frame.camera.transform*local;return Vector(Double(q.x),Double(q.y),Double(q.z))
    }
    private func origin(_ a: ARPlaneAnchor) -> Vector {
        let p=a.transform*SIMD4<Float>(a.center.x,a.center.y,a.center.z,1);return Vector(Double(p.x),Double(p.y),Double(p.z))
    }
    private func normal(_ a: ARPlaneAnchor) -> Vector { let p=a.transform.columns.1;return Vector(Double(p.x),Double(p.y),Double(p.z)) }
    private func qrCentre(_ q: VNBarcodeObservation, width: Double, height: Double) throws -> Point {
        let points=[q.topLeft,q.topRight,q.bottomRight,q.bottomLeft].map { Point(Double($0.x)*width,(1-Double($0.y))*height) }
        return try Homography(from:Insets.unit,to:points).apply(Point(0.5,0.5))
    }

    func process(_ frame: ARFrame, geometry: Insets, orientation: CGImagePropertyOrientation) throws -> WallScan {
        let image=CIImage(cvPixelBuffer:frame.capturedImage).oriented(orientation)
        let scale=min(1,768/max(image.extent.width,image.extent.height)),small=image.transformed(by:CGAffineTransform(scaleX:scale,y:scale))
        guard let jpeg=context.jpegRepresentation(of:small,colorSpace:CGColorSpaceCreateDeviceRGB(),options:[CIImageRepresentationOption(rawValue:kCGImageDestinationLossyCompressionQuality as String):0.6]) else { throw CalibrationError.invalid("Camera image could not be shared") }
        var result=WallScan(jpeg:jpeg,capturedAt:frame.timestamp,status:"Move slowly to scan the wall, then hold still with all four codes visible")
        do {
        guard case .normal=frame.camera.trackingState else { return result }
        guard let depth=frame.sceneDepth,let confidence=depth.confidenceMap else { result.status="LiDAR depth is not available on this camera";return result }
        let width=Double(CVPixelBufferGetWidth(frame.capturedImage)),height=Double(CVPixelBufferGetHeight(frame.capturedImage))
        let request=VNDetectBarcodesRequest();request.symbologies=[.qr]
        try VNImageRequestHandler(cvPixelBuffer:frame.capturedImage,orientation:.up,options:[:]).perform([request])
        let detected=try (request.results ?? []).compactMap { observation -> ObservedMarker? in
            guard let text=observation.payloadStringValue,text.hasPrefix("BEAM1:") else { return nil }
            return try ObservedMarker(payload:MarkerPayload(text),centre:qrCentre(observation,width:width,height:height),confidence:Double(observation.confidence))
        }
        result.markers=detected.count
        let ordered: [ObservedMarker]
        do { ordered=try orderedMarkers(detected,current:geometry) } catch { result.status=error.localizedDescription;return result }
        result.confidence=ordered.map(\.confidence).min() ?? 0
        let position=cameraPosition(frame),forward=direction(Point(width/2,height/2),frame:frame)
        if let lastCamera,let lastForward,position.distance(to:lastCamera)<0.012,forward.dot(lastForward)/(forward.length*lastForward.length)>0.9998 { stableCameraFrames+=1 } else { stableCameraFrames=0 }
        lastCamera=position;lastForward=forward

        CVPixelBufferLockBaseAddress(depth.depthMap,.readOnly);CVPixelBufferLockBaseAddress(confidence,.readOnly);CVPixelBufferLockBaseAddress(frame.capturedImage,.readOnly)
        defer {CVPixelBufferUnlockBaseAddress(depth.depthMap,.readOnly);CVPixelBufferUnlockBaseAddress(confidence,.readOnly);CVPixelBufferUnlockBaseAddress(frame.capturedImage,.readOnly)}
        let dw=CVPixelBufferGetWidth(depth.depthMap),dh=CVPixelBufferGetHeight(depth.depthMap)
        guard let depthBase=CVPixelBufferGetBaseAddress(depth.depthMap),let confidenceBase=CVPixelBufferGetBaseAddress(confidence),let lumaBase=CVPixelBufferGetBaseAddressOfPlane(frame.capturedImage,0) else { return result }
        let depthStride=CVPixelBufferGetBytesPerRow(depth.depthMap),confidenceStride=CVPixelBufferGetBytesPerRow(confidence),lumaStride=CVPixelBufferGetBytesPerRowOfPlane(frame.capturedImage,0)
        func sample(_ x:Int,_ y:Int)->(Double,Int){
            let z=depthBase.advanced(by:y*depthStride).assumingMemoryBound(to:Float.self)[x]
            let c=confidenceBase.advanced(by:y*confidenceStride).assumingMemoryBound(to:UInt8.self)[x]
            return (Double(z),Int(c))
        }
        func markerDepth(_ pixel:Point)->Vector?{
            let cx=Int(pixel.x/width*Double(dw)),cy=Int(pixel.y/height*Double(dh));var values=[Double]()
            guard cx>=1,cy>=1,cx<dw-1,cy<dh-1 else { return nil }
            for y in cy-1...cy+1 { for x in cx-1...cx+1 { let (z,c)=sample(x,y);if c>=2&&z.isFinite&&z>0.15&&z<8 {values.append(z)} } }
            guard values.count>=4 else {return nil};values.sort();return position+direction(pixel,frame:frame)*values[values.count/2]
        }
        let anchors=frame.anchors.compactMap{$0 as? ARPlaneAnchor}.filter{$0.alignment == .vertical}.sorted{$0.extent.x*$0.extent.z>$1.extent.x*$1.extent.z}
        if wall==nil {
            for a in anchors {
                guard let candidate=try? Wall(origin:origin(a),normal:normal(a),camera:position) else {continue}
                if ordered.allSatisfy({ m in guard let p=markerDepth(m.centre) else{return false};return abs(candidate.distance(p))<0.035 }) {
                    wall=candidate;wallID=a.identifier;break
                }
            }
        }
        guard let wall,let anchor=anchors.first(where:{$0.identifier==wallID}) else {result.status="Scan more of the wall until its plane and all four codes are measured";return result}
        let newNormal=try normal(anchor).normalized()
        guard abs(wall.distance(origin(anchor)))<0.025,abs(newNormal.dot(wall.normal))>0.999 else {reset();result.status="Wall measurement changed. Scan the wall again before correction";return result}
        guard ordered.allSatisfy({ m in guard let p=markerDepth(m.centre) else{return false};return abs(wall.distance(p))<0.035 }) else {result.status="A corner is obstructed or its depth is uncertain; show all four on the flat wall";return result}
        let markerWall=try ordered.map { try wall.project(wall.intersect(origin:position,direction:direction($0.centre,frame:frame))) }
        let centres=try ordered[0].payload.centres(),toWall=try geometry.panelToWall(markerCentres:centres,measured:markerWall)
        let footprint=try Insets.unit.map {try toWall.apply($0)},current=try geometry.corners.map {try toWall.apply($0)}
        let fromWall=try Homography(from:footprint,to:Insets.unit),toContent=try Homography(from:geometry.corners,to:Insets.unit)
        let minx=footprint.map(\.x).min()!,maxx=footprint.map(\.x).max()!,miny=footprint.map(\.y).min()!,maxy=footprint.map(\.y).max()!
        let cell=0.04,columns=Int(ceil((maxx-minx)/cell)),rows=Int(ceil((maxy-miny)/cell))
        var space=try FreeSpace(origin:Point(minx,miny),columns:columns,rows:rows,cell:cell)
        struct Sample {let p:Point;let wall:Bool;let white:Bool;let luma:Int;let confidence:Int}
        var samples=[Sample](),whiteLuma=[Int]()
        let size=(Double(ordered[0].payload.height)*0.18).rounded(),margin=(Double(ordered[0].payload.height)*0.015).rounded()
        let codeX=(size+margin)/Double(ordered[0].payload.width),codeY=(size+margin)/Double(ordered[0].payload.height)
        for y in 0..<dh {for x in 0..<dw {
            let (z,c)=sample(x,y);guard c>=2,z.isFinite,z>0.15,z<8 else {continue}
            let pixel=Point((Double(x)+0.5)/Double(dw)*width,(Double(y)+0.5)/Double(dh)*height),ray=direction(pixel,frame:frame)
            guard let intersection=try? wall.intersect(origin:position,direction:ray) else {continue}
            let p=wall.project(intersection);guard contains(footprint,p) else {continue}
            let actual=position+ray*z,residual=wall.distance(actual)
            if residual>0.04 {samples.append(Sample(p:p,wall:false,white:false,luma:0,confidence:c));continue}
            guard abs(residual)<0.025 else {continue}
            let uv=try toContent.apply(fromWall.apply(p))
            let codeRegion=(uv.x<codeX||uv.x>1-codeX)&&(uv.y<codeY||uv.y>1-codeY)
            let white=uv.x>0.01&&uv.x<0.99&&uv.y>0.01&&uv.y<0.99 && !codeRegion && abs(uv.x*16-(uv.x*16).rounded())>0.05 && abs(uv.y*9-(uv.y*9).rounded())>0.05
            let px=min(Int(width)-1,max(0,Int(pixel.x))),py=min(Int(height)-1,max(0,Int(pixel.y)))
            let luma=Int(lumaBase.advanced(by:py*lumaStride).assumingMemoryBound(to:UInt8.self)[px])
            samples.append(Sample(p:p,wall:true,white:white,luma:luma,confidence:c));if white {whiteLuma.append(luma)}
        }}
        whiteLuma.sort();let whiteLevel=whiteLuma.isEmpty ? 0:whiteLuma[whiteLuma.count/2]
        for sample in samples {
            // Known white test-grid regions that stay dark may be projector shadows; exclude them too.
            let shadow=sample.white && whiteLevel>45 && Double(sample.luma)<max(28,Double(whiteLevel)*0.45)
            space.observe(sample.p,onWall:sample.wall && !shadow,confidence:sample.confidence,clearance:0.10)
        }
        result.planeStable=stableCameraFrames>=2
        if let target,space.obstructed(target) {blockedFrames+=1;if blockedFrames>=2 {self.target=nil;targetID=""}}else{blockedFrames=0}
        if target==nil {
            target=try space.rectangle(footprint:footprint,minimumHeight:0.3,accept:{q in (try? Insets(corners:q.map{try fromWall.apply($0)})) != nil})
            targetID=UUID().uuidString
        }
        guard let target else {return result}
        let wallToImage=try Homography(from:markerWall,to:ordered.map(\.centre))
        func displayed(_ point:Point)throws->Point {
            let p=try wallToImage.apply(point)
            switch orientation {
            case .right:return Point(1-p.y/height,p.x/width)
            case .left:return Point(p.y/height,1-p.x/width)
            case .down:return Point(1-p.x/width,1-p.y/height)
            default:return Point(p.x/width,p.y/height)
            }
        }
        result.targetImage=try target.map(displayed)
        let blocked=space.blockedCentres,stride=max(1,blocked.count/160)
        result.blockedImage=try blocked.enumerated().filter{$0.offset%stride==0}.prefix(160).map{try displayed($0.element)}
        result.targetID=targetID;result.target=target;result.observed=current
        result.widthMetres=target[0].distance(to:target[1]);result.heightMetres=target[1].distance(to:target[2])
        result.maximumError=zip(current,target).map{$0.distance(to:$1)}.max() ?? .infinity
        let currentWidth=(current[0].distance(to:current[1])+current[3].distance(to:current[2]))/2,currentHeight=(current[0].distance(to:current[3])+current[1].distance(to:current[2]))/2
        result.aspectError=abs(currentWidth/currentHeight/(16/9)-1)
        result.obstaclesChecked=space.covers(target)&&whiteLuma.count>=100&&whiteLevel>45&&target.allSatisfy{contains(current,$0,tolerance:0.008)}
        if !space.covers(target){result.status="Wall coverage is incomplete. Keep the whole screen and obstacles in view";return result}
        let wanted=try Insets(corners:target.map{try fromWall.apply($0)})
        if result.planeStable {result.proposal=try geometry.step(toward:wanted)}
        let h=try Homography(from:Insets.unit,to:footprint);result.panelToPlane=h.coefficients
        result.status=result.planeStable ? "Measuring clear space and correcting the screen; keep the phone still":"Hold the phone still to begin automatic correction"
        return result
        } catch {result.status=error.localizedDescription;return result}
    }
}

private extension Vector {
    func distance(to other:Vector)->Double {(self-other).length}
}
