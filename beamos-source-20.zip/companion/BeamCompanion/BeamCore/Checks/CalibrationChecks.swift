import Foundation
import BeamCore

final class CalibrationTests {
    func testVersionedMarkersRejectStaleGeometryAndDuplicates() throws {
        let value=try MarkerPayload("BEAM1:TL:0505050505050505:1920x1080")
        XCTAssertEqual(value.geometry.values,Array(repeating:5,count:8))
        let ids=["TL","TR","BR","BL"],q=Insets.unit
        let markers=try ids.enumerated().map { i,id in ObservedMarker(payload:try MarkerPayload("BEAM1:\(id):0505050505050505:1920x1080"),centre:q[i],confidence:0.99) }
        XCTAssertEqual(try orderedMarkers(markers.reversed(),current:value.geometry).map { $0.payload.corner },ids)
        XCTAssertThrowsError(try orderedMarkers(markers,current:.full))
        XCTAssertThrowsError(try orderedMarkers([markers[0],markers[0],markers[2],markers[3]],current:value.geometry))
        XCTAssertThrowsError(try MarkerPayload("BEAM1:TL:zzzzzzzzzzzzzzzz:1920x1080"))
        XCTAssertThrowsError(try MarkerPayload("BEAM:TL"))
    }
    func testHomographyRoundTripAndActiveInsets() throws {
        let active=try Insets([80,70,120,90,100,60,90,80])
        let markers=try Insets.markerCentres(width:1920,height:1080,size:194,margin:16)
        let wallCorners=[Point(-1.3,-0.7),Point(1.6,-0.8),Point(1.4,0.9),Point(-1.2,0.7)]
        let expected=try Homography(from:Insets.unit,to:wallCorners)
        let current=try Homography(from:Insets.unit,to:active.corners)
        let measured=try markers.map { try expected.apply(current.apply($0)) }
        let recovered=try active.panelToWall(markerCentres:markers,measured:measured)
        for p in Insets.unit { XCTAssertLessThan(try expected.apply(p).distance(to:recovered.apply(p)),1e-8) }
        let inverse=try Homography(from:wallCorners,to:Insets.unit)
        for p in Insets.unit { XCTAssertLessThan(try inverse.apply(recovered.apply(p)).distance(to:p),1e-8) }
    }
    func testSingularAndFoldedMarkersRejected() {
        XCTAssertThrowsError(try Homography(from:Array(repeating:Point(0,0),count:4),to:Insets.unit))
        XCTAssertThrowsError(try Insets([0,0,500,500,500,500,0,0]))
        XCTAssertThrowsError(try Insets(corners:[Point(-0.1,0),Point(1,0),Point(1,1),Point(0,1)]))
        XCTAssertFalse(contains(Insets.unit,Point(.nan,0)))
    }
    func testBoundedCorrectionsAndPayloadOrder() throws {
        let target=try Insets([100,80,90,60,70,50,80,70])
        XCTAssertEqual(try Insets(corners:target.corners),target)
        let next=try Insets.full.step(toward:target)
        XCTAssertTrue(next.values.allSatisfy { $0==20 })
        XCTAssertEqual(try target.step(toward:target),target)
    }
    func testWallRayUsesMetresAndRejectsBehindCamera() throws {
        let wall=try Wall(origin:Vector(0,0,-2),normal:Vector(0,0,1),camera:Vector(0,0,0))
        let p=try wall.intersect(origin:Vector(0,0,0),direction:Vector(0.5,-0.25,-1))
        XCTAssertEqual(p,Vector(1,-0.5,-2))
        XCTAssertEqual(wall.project(p),Point(1,0.5))
        XCTAssertThrowsError(try wall.intersect(origin:Vector(0,0,0),direction:Vector(0,0,1)))
        XCTAssertThrowsError(try wall.intersect(origin:Vector(0,0,0),direction:Vector(1,0,0)))
    }
    private func measuredSpace() throws -> FreeSpace {
        var space=try FreeSpace(origin:Point(0,0),columns:80,rows:45,cell:0.04)
        for y in 0..<45 { for x in 0..<80 { for _ in 0..<2 { space.observe(space.centre(column:x,row:y),onWall:true,confidence:2) } } }
        return space
    }
    func testMeasuredAspectAndObstacleClearance() throws {
        var space=try measuredSpace()
        let foot=[Point(0,0),Point(3.2,0),Point(3.2,1.8),Point(0,1.8)]
        let whole=try space.rectangle(footprint:foot)
        XCTAssertEqual(whole[0].distance(to:whole[1])/whole[1].distance(to:whole[2]),16/9,accuracy:1e-10)
        XCTAssertGreaterThan(whole[1].distance(to:whole[2]),1.7)
        // An AC unit creates a persistent exclusion zone, including its clearance margin.
        space.observe(Point(1.6,0.3),onWall:false,confidence:2,clearance:0.12)
        let fit=try space.rectangle(footprint:foot)
        XCTAssertTrue(space.covers(fit))
        XCTAssertFalse(contains(fit,Point(1.6,0.3)))
        XCTAssertLessThan(fit[1].distance(to:fit[2]),1.7)
    }
    func testUnknownAndLowConfidenceDepthCannotFit() throws {
        var space=try FreeSpace(origin:Point(0,0),columns:80,rows:45,cell:0.04)
        for y in 0..<45 { for x in 0..<80 { space.observe(space.centre(column:x,row:y),onWall:true,confidence:1) } }
        XCTAssertEqual(space.coverage,0)
        XCTAssertThrowsError(try space.rectangle(footprint:[Point(0,0),Point(3.2,0),Point(3.2,1.8),Point(0,1.8)]))
    }
    private func observation(sequence: Int, time: Double, target: String="wall-A", geometry: Insets = .full, error: Double=0.003, obstacles: Bool=true) -> CameraMeasurement {
        CameraMeasurement(sequence:sequence,capturedAt:time-0.05,geometry:geometry,targetID:target,markers:4,maximumErrorMetres:error,aspectError:0.002,confidence:0.98,planeStable:true,obstaclesChecked:obstacles)
    }
    func testGreenNeedsFreshStableCameraEvidenceThenExpires() throws {
        var feedback=Feedback()
        for i in 0..<4 { XCTAssertFalse(feedback.update(observation(sequence:i,time:1+Double(i)*0.5),now:1+Double(i)*0.5,acknowledged:.full,acknowledgedAt:0)) }
        XCTAssertTrue(feedback.update(observation(sequence:4,time:3),now:3,acknowledged:.full,acknowledgedAt:0))
        XCTAssertFalse(feedback.expire(now:5.5))
    }
    func testChangingCornersOrTargetResetsStability() throws {
        var feedback=Feedback()
        for i in 0..<5 { _=feedback.update(observation(sequence:i,time:1+Double(i)*0.5),now:1+Double(i)*0.5,acknowledged:.full,acknowledgedAt:0) }
        XCTAssertTrue(feedback.ready)
        XCTAssertFalse(feedback.update(observation(sequence:5,time:3.5,target:"wall-B"),now:3.5,acknowledged:.full,acknowledgedAt:0))
        let moved=try Insets([10,10,10,10,10,10,10,10])
        XCTAssertFalse(feedback.update(observation(sequence:6,time:4,geometry:moved),now:4,acknowledged:moved,acknowledgedAt:3.6))
        XCTAssertEqual(feedback.stableFrames,1)
    }
    func testMetricToleranceAndExclusionOverlay() throws {
        XCTAssertTrue(contains(Insets.unit,Point(1.003,0.5),tolerance:0.005))
        XCTAssertFalse(contains(Insets.unit,Point(1.02,0.5),tolerance:0.005))
        var grid=try FreeSpace(origin:Point(0,0),columns:10,rows:10,cell:0.04)
        grid.observe(Point(0.2,0.2),onWall:false,confidence:2,clearance:0.04)
        XCTAssertTrue(grid.obstructed(Insets.unit))
        XCTAssertFalse(grid.blockedCentres.isEmpty)
    }
    func testReplayObstaclesNaNAndPreAcknowledgementImagesCannotGreen() {
        var feedback=Feedback()
        let good=observation(sequence:1,time:1)
        _=feedback.update(good,now:1,acknowledged:.full,acknowledgedAt:0)
        XCTAssertFalse(feedback.update(good,now:1.1,acknowledged:.full,acknowledgedAt:0))
        XCTAssertEqual(feedback.stableFrames,0)
        XCTAssertFalse(feedback.update(observation(sequence:2,time:2,obstacles:false),now:2,acknowledged:.full,acknowledgedAt:0))
        XCTAssertFalse(feedback.update(observation(sequence:3,time:3,error:.nan),now:3,acknowledged:.full,acknowledgedAt:0))
        XCTAssertFalse(feedback.update(observation(sequence:4,time:4),now:4,acknowledged:.full,acknowledgedAt:3.9))
        XCTAssertFalse(feedback.update(observation(sequence:5,time:4),now:5,acknowledged:.full,acknowledgedAt:0))
    }
}
