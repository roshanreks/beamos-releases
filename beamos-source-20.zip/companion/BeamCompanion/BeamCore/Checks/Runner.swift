import Foundation

// No XCTest runtime is bundled with this Mac's Command Line Tools. These checks run without Xcode.
private var checks=0
private func evaluate<T>(_ body: () throws -> T) -> T { do { return try body() } catch { fatalError("Unexpected error: \(error)") } }
func XCTAssertTrue(_ value: @autoclosure () throws -> Bool, file: StaticString = #file, line: UInt = #line) { checks+=1; let x=evaluate(value); precondition(x,"Expected true at \(file):\(line)") }
func XCTAssertFalse(_ value: @autoclosure () throws -> Bool, file: StaticString = #file, line: UInt = #line) { checks+=1; let x=evaluate(value); precondition(!x,"Expected false at \(file):\(line)") }
func XCTAssertEqual<T: Equatable>(_ a: @autoclosure () throws -> T, _ b: @autoclosure () throws -> T, file: StaticString = #file, line: UInt = #line) { checks+=1; let x=evaluate(a), y=evaluate(b); precondition(x==y,"Expected equal at \(file):\(line): \(x), \(y)") }
func XCTAssertEqual(_ a: Double, _ b: Double, accuracy: Double, file: StaticString = #file, line: UInt = #line) { checks+=1; precondition(abs(a-b)<=accuracy,"Expected equal within tolerance at \(file):\(line)") }
func XCTAssertLessThan(_ a: @autoclosure () throws -> Double, _ b: Double, file: StaticString = #file, line: UInt = #line) { checks+=1; let x=evaluate(a); precondition(x<b,"Expected \(x) < \(b) at \(file):\(line)") }
func XCTAssertGreaterThan(_ a: Double, _ b: Double, file: StaticString = #file, line: UInt = #line) { checks+=1; precondition(a>b,"Expected greater at \(file):\(line)") }
func XCTAssertThrowsError<T>(_ body: @autoclosure () throws -> T, file: StaticString = #file, line: UInt = #line) { checks+=1; do { _=try body(); preconditionFailure("Expected rejection at \(file):\(line)") } catch {} }

@main enum Runner {
    static func main() throws {
        let t=CalibrationTests()
        try t.testMetricToleranceAndExclusionOverlay()
        try t.testVersionedMarkersRejectStaleGeometryAndDuplicates()
        try t.testHomographyRoundTripAndActiveInsets()
        t.testSingularAndFoldedMarkersRejected()
        try t.testBoundedCorrectionsAndPayloadOrder()
        try t.testWallRayUsesMetresAndRejectsBehindCamera()
        try t.testMeasuredAspectAndObstacleClearance()
        try t.testUnknownAndLowConfidenceDepthCannotFit()
        try t.testGreenNeedsFreshStableCameraEvidenceThenExpires()
        try t.testChangingCornersOrTargetResetsStability()
        t.testReplayObstaclesNaNAndPreAcknowledgementImagesCannotGreen()
        print("PASS \(checks) camera geometry, obstacle, bounded correction and feedback assertions")
    }
}
