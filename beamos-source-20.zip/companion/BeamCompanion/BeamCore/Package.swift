// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "BeamCore",
    platforms: [.iOS(.v17), .macOS(.v13)],
    products: [.library(name: "BeamCore", targets: ["BeamCore"])],
    targets: [.target(name: "BeamCore"), .executableTarget(name: "BeamCoreChecks", dependencies: ["BeamCore"], path: "Checks")]
)
