import Foundation

public struct CameraMeasurement: Sendable {
    public var sequence: Int
    public var capturedAt: Double
    public var geometry: Insets
    public var targetID: String
    public var markers: Int
    public var maximumErrorMetres: Double
    public var aspectError: Double
    public var confidence: Double
    public var planeStable: Bool
    public var obstaclesChecked: Bool
    public init(sequence: Int, capturedAt: Double, geometry: Insets, targetID: String, markers: Int, maximumErrorMetres: Double, aspectError: Double, confidence: Double, planeStable: Bool, obstaclesChecked: Bool) {
        self.sequence=sequence; self.capturedAt=capturedAt; self.geometry=geometry; self.targetID=targetID; self.markers=markers; self.maximumErrorMetres=maximumErrorMetres; self.aspectError=aspectError; self.confidence=confidence; self.planeStable=planeStable; self.obstaclesChecked=obstaclesChecked
    }
}

/// A command acknowledgement never counts as a camera measurement. All times use a monotonic clock.
public struct Feedback: Sendable {
    public private(set) var stableFrames=0
    public private(set) var ready=false
    private var sequence = -1
    private var stableSince: Double?
    private var last: Double?
    private var targetID=""
    private var geometry: Insets?
    public init() {}
    public mutating func reset() { self=Self() }
    public mutating func update(_ m: CameraMeasurement, now: Double, acknowledged: Insets, acknowledgedAt: Double) -> Bool {
        let valid=m.sequence>sequence && !m.targetID.isEmpty && m.capturedAt.isFinite && now.isFinite && now>=m.capturedAt && now-m.capturedAt<0.75 && m.capturedAt>=acknowledgedAt+0.3 && m.geometry==acknowledged && m.markers==4 && m.maximumErrorMetres.isFinite && m.maximumErrorMetres>=0 && m.maximumErrorMetres<=0.005 && m.aspectError.isFinite && m.aspectError>=0 && m.aspectError<=0.01 && m.confidence>=0.9 && m.confidence<=1 && m.planeStable && m.obstaclesChecked
        let continuous=last.map { now >= $0 && now-$0<1.25 } ?? false
        if !valid { stableFrames=0; stableSince=nil; ready=false }
        else {
            if !continuous || targetID != m.targetID || geometry != m.geometry { stableFrames=0; stableSince=nil }
            stableFrames+=1
            if stableSince==nil { stableSince=now }
            ready=stableFrames>=5 && now-stableSince!>=2
        }
        sequence=max(sequence,m.sequence); last=now; geometry=m.geometry; targetID=m.targetID
        return ready
    }
    public mutating func expire(now: Double) -> Bool {
        if last == nil || now-last!>=2.5 { ready=false; stableFrames=0; stableSince=nil }
        return ready
    }
}
