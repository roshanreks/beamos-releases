import Foundation

/// Conservative measured wall occupancy. Unknown and obstructed cells both exclude a fit.
public struct FreeSpace: Sendable {
    public let origin: Point
    public let cell: Double
    public let columns: Int, rows: Int
    private var wallHits: [UInt8]
    private var blocked: [Bool]
    public init(origin: Point, columns: Int, rows: Int, cell: Double) throws {
        guard origin.finite, cell.isFinite, cell >= 0.01, cell <= 0.1, (1...180).contains(columns), (1...140).contains(rows) else {
            throw CalibrationError.invalid("Wall measurement grid is outside the supported size")
        }
        self.origin=origin; self.columns=columns; self.rows=rows; self.cell=cell
        wallHits=Array(repeating:0,count:columns*rows); blocked=Array(repeating:false,count:columns*rows)
    }
    public func centre(column x: Int, row y: Int) -> Point { Point(origin.x+(Double(x)+0.5)*cell,origin.y+(Double(y)+0.5)*cell) }
    public mutating func observe(_ p: Point, onWall: Bool, confidence: Int, clearance: Double = 0.06) {
        guard p.finite, confidence >= 2 else { return }
        let x=Int(floor((p.x-origin.x)/cell)), y=Int(floor((p.y-origin.y)/cell))
        guard x>=0, y>=0, x<columns, y<rows else { return }
        if onWall { let i=y*columns+x; wallHits[i]=min(250,wallHits[i]+1) }
        else {
            let r=Int(ceil(max(0,clearance)/cell))
            for yy in max(0,y-r)...min(rows-1,y+r) { for xx in max(0,x-r)...min(columns-1,x+r) { blocked[yy*columns+xx]=true } }
        }
    }
    public func free(column x: Int, row y: Int) -> Bool { wallHits[y*columns+x]>=2 && !blocked[y*columns+x] }
    public var blockedCentres: [Point] {
        var points=[Point]()
        for y in 0..<rows {for x in 0..<columns where blocked[y*columns+x] {points.append(centre(column:x,row:y))}}
        return points
    }
    public var coverage: Double { Double(wallHits.filter { $0>=2 }.count)/Double(wallHits.count) }
    public func obstructed(_ quad:[Point])->Bool {
        guard convex(quad) else{return true}
        for y in 0..<rows {for x in 0..<columns where blocked[y*columns+x] {if contains(quad,centre(column:x,row:y)){return true}}}
        return false
    }
    /// Largest axis-aligned rectangle for the chosen ratio within measured free cells and a convex optical footprint.
    /// Exhausts every row band and contiguous free run; no random search and no filling depth holes as clear wall.
    public func rectangle(aspect: Double = 16/9, footprint: [Point], minimumHeight: Double = 0.2, accept: ([Point]) -> Bool = { _ in true }) throws -> [Point] {
        guard aspect.isFinite, aspect > 0.2, aspect < 10, convex(footprint) else { throw CalibrationError.invalid("Invalid wall footprint or aspect ratio") }
        var allowed=Array(repeating:false,count:rows*columns)
        for y in 0..<rows { for x in 0..<columns where free(column:x,row:y) {
            let p=Point(origin.x+Double(x)*cell,origin.y+Double(y)*cell)
            allowed[y*columns+x]=[p,Point(p.x+cell,p.y),Point(p.x+cell,p.y+cell),Point(p.x,p.y+cell)].allSatisfy { contains(footprint,$0) }
        } }
        var best: [Point] = [], bestHeight=minimumHeight
        for top in 0..<rows {
            var runAllowed=Array(repeating:true,count:columns)
            for bottom in top..<rows {
                for x in 0..<columns { runAllowed[x] = runAllowed[x] && allowed[bottom*columns+x] }
                var start=0
                while start<columns {
                    if !runAllowed[start] { start+=1; continue }
                    var end=start+1
                    while end<columns && runAllowed[end] { end+=1 }
                    let height=min(Double(bottom-top+1)*cell,Double(end-start)*cell/aspect)
                    if height>bestHeight {
                        let cx=origin.x+Double(start+end)*cell/2, cy=origin.y+Double(top+bottom+1)*cell/2
                        let w=height*aspect
                        let candidate=[Point(cx-w/2,cy-height/2),Point(cx+w/2,cy-height/2),Point(cx+w/2,cy+height/2),Point(cx-w/2,cy+height/2)]
                        if accept(candidate) { best=candidate;bestHeight=height }
                    }
                    start=end
                }
            }
        }
        guard best.count==4 else { throw CalibrationError.invalid("No measured clear screen fits yet; scan the wall and obstacles") }
        return best
    }
    public func covers(_ quad: [Point]) -> Bool {
        guard convex(quad), quad.allSatisfy({ $0.x>=origin.x-1e-8 && $0.y>=origin.y-1e-8 && $0.x<=origin.x+Double(columns)*cell+1e-8 && $0.y<=origin.y+Double(rows)*cell+1e-8 }) else { return false }
        let x0=max(0,Int(floor((quad.map(\.x).min()!-origin.x)/cell+1e-7)))
        let x1=min(columns-1,Int(ceil((quad.map(\.x).max()!-origin.x)/cell-1e-7))-1)
        let y0=max(0,Int(floor((quad.map(\.y).min()!-origin.y)/cell+1e-7)))
        let y1=min(rows-1,Int(ceil((quad.map(\.y).max()!-origin.y)/cell-1e-7))-1)
        guard x0<=x1, y0<=y1 else { return false }
        // Bounding-box validation is deliberately conservative for a rotated quad.
        for y in y0...y1 { for x in x0...x1 where !free(column:x,row:y) { return false } }
        return true
    }
}
