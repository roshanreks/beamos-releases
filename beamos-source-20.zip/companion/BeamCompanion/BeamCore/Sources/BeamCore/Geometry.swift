import Foundation

public enum CalibrationError: Error, LocalizedError {
    case invalid(String)
    public var errorDescription: String? { if case let .invalid(s) = self { return s }; return nil }
}

public struct Point: Codable, Hashable, Sendable {
    public var x: Double
    public var y: Double
    public init(_ x: Double, _ y: Double) { self.x = x; self.y = y }
    public var finite: Bool { x.isFinite && y.isFinite }
    public func distance(to p: Point) -> Double { hypot(x - p.x, y - p.y) }
}

public struct Vector: Codable, Hashable, Sendable {
    public var x: Double, y: Double, z: Double
    public init(_ x: Double, _ y: Double, _ z: Double) { self.x = x; self.y = y; self.z = z }
    public static func + (a: Self, b: Self) -> Self { .init(a.x+b.x, a.y+b.y, a.z+b.z) }
    public static func - (a: Self, b: Self) -> Self { .init(a.x-b.x, a.y-b.y, a.z-b.z) }
    public static func * (a: Self, s: Double) -> Self { .init(a.x*s, a.y*s, a.z*s) }
    public func dot(_ b: Self) -> Double { x*b.x + y*b.y + z*b.z }
    public func cross(_ b: Self) -> Self { .init(y*b.z-z*b.y, z*b.x-x*b.z, x*b.y-y*b.x) }
    public var length: Double { sqrt(dot(self)) }
    public func normalized() throws -> Self {
        guard length.isFinite, length > 1e-9 else { throw CalibrationError.invalid("Invalid wall direction") }
        return self * (1 / length)
    }
}

/// A gravity-aligned wall frame, with metres to the right and down. Retain this frame through a session.
public struct Wall: Sendable {
    public let origin: Vector, right: Vector, down: Vector, normal: Vector
    public init(origin: Vector, normal: Vector, camera: Vector) throws {
        var n = try normal.normalized()
        if (camera-origin).dot(n) < 0 { n = n * -1 }
        guard abs(n.y) < 0.2 else { throw CalibrationError.invalid("Point at a vertical wall") }
        let r = try Vector(0, 1, 0).cross(n).normalized()
        self.origin = origin; self.normal = n; self.right = r
        self.down = try r.cross(n).normalized()
    }
    public func project(_ p: Vector) -> Point { let d = p-origin; return Point(d.dot(right), d.dot(down)) }
    public func distance(_ p: Vector) -> Double { (p-origin).dot(normal) }
    public func intersect(origin o: Vector, direction d: Vector) throws -> Vector {
        let divisor = d.dot(normal)
        guard divisor.isFinite, abs(divisor) > 1e-5 else { throw CalibrationError.invalid("Camera is too oblique to the wall") }
        let t = (origin-o).dot(normal) / divisor
        guard t.isFinite, t > 0, t*d.length < 8 else { throw CalibrationError.invalid("Wall is outside the camera measurement range") }
        return o + d*t
    }
}

public func convex(_ q: [Point], minimumCross: Double = 1e-9) -> Bool {
    guard q.count == 4, q.allSatisfy(\.finite) else { return false }
    for i in 0..<4 {
        let a=q[i], b=q[(i+1)%4], c=q[(i+2)%4]
        if (b.x-a.x)*(c.y-b.y)-(b.y-a.y)*(c.x-b.x) <= minimumCross { return false }
    }
    return true
}

public func contains(_ polygon: [Point], _ p: Point) -> Bool {
    guard polygon.count >= 3, p.finite else { return false }
    var sign = 0
    for i in polygon.indices {
        let a=polygon[i], b=polygon[(i+1)%polygon.count]
        let c=(b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x)
        if abs(c) < 1e-9 { continue }
        let s=c > 0 ? 1 : -1
        if sign != 0 && s != sign { return false }; sign=s
    }
    return sign != 0
}

/// A metric tolerance accommodates projector inset quantization without accepting a wrong aspect ratio.
public func contains(_ polygon: [Point], _ p: Point, tolerance: Double) -> Bool {
    guard convex(polygon), p.finite, tolerance.isFinite, tolerance >= 0 else { return false }
    for i in polygon.indices {
        let a=polygon[i], b=polygon[(i+1)%polygon.count]
        let cross=(b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x)
        if cross < -tolerance*a.distance(to:b) { return false }
    }
    return true
}

public struct Homography: Sendable {
    private let h: [Double]
    public var coefficients: [Double] {h}
    public init(from src: [Point], to dst: [Point]) throws {
        guard convex(src), convex(dst) else { throw CalibrationError.invalid("Four distinct ordered wall markers are required") }
        var a = [[Double]]()
        for i in 0..<4 {
            let x=src[i].x, y=src[i].y, u=dst[i].x, v=dst[i].y
            a.append([x,y,1,0,0,0,-u*x,-u*y,u])
            a.append([0,0,0,x,y,1,-v*x,-v*y,v])
        }
        for c in 0..<8 {
            let p=(c..<8).max(by: { abs(a[$0][c]) < abs(a[$1][c]) })!
            guard abs(a[p][c]) > 1e-10 else { throw CalibrationError.invalid("Wall markers cannot resolve a stable projection") }
            a.swapAt(c,p)
            let divisor=a[c][c]
            for k in c..<9 { a[c][k] /= divisor }
            for r in 0..<8 where r != c {
                let f=a[r][c]
                for k in c..<9 { a[r][k] -= f*a[c][k] }
            }
        }
        h=a.map { $0[8] } + [1]
    }
    public func apply(_ p: Point) throws -> Point {
        let w=h[6]*p.x+h[7]*p.y+h[8]
        guard w.isFinite, abs(w) > 1e-8 else { throw CalibrationError.invalid("Projection crosses the wall horizon") }
        let q=Point((h[0]*p.x+h[1]*p.y+h[2])/w,(h[3]*p.x+h[4]*p.y+h[5])/w)
        guard q.finite else { throw CalibrationError.invalid("Invalid projection") }; return q
    }
}

public struct Insets: Codable, Equatable, Sendable {
    public let values: [Int]
    public static let full = try! Insets([0,0,0,0,0,0,0,0])
    public static let unit = [Point(0,0),Point(1,0),Point(1,1),Point(0,1)]
    /// LBx,LBy,LTx,LTy,RTx,RTy,RBx,RBy; matches the projector Binder protocol.
    public init(_ v: [Int]) throws {
        guard v.count == 8, v.allSatisfy({ (0...500).contains($0) }) else { throw CalibrationError.invalid("Fit exceeds projector corner limits; reposition it") }
        self.values=v
        guard convex(corners, minimumCross: 0.005), v[2]+v[4] <= 900, v[0]+v[6] <= 900, v[3]+v[1] <= 900, v[5]+v[7] <= 900 else {
            throw CalibrationError.invalid("Fit would fold the picture; reposition the projector")
        }
    }
    public init(corners q: [Point]) throws {
        guard convex(q), q.allSatisfy({ (-0.0001...1.0001).contains($0.x) && (-0.0001...1.0001).contains($0.y) }) else {
            throw CalibrationError.invalid("Requested screen is outside the optical footprint")
        }
        try self.init([q[3].x,1-q[3].y,q[0].x,q[0].y,1-q[1].x,q[1].y,1-q[2].x,1-q[2].y].map { Int(($0*1000).rounded()) })
    }
    public var corners: [Point] {
        let v=values.map { Double($0)/1000 }
        return [Point(v[2],v[3]),Point(1-v[4],v[5]),Point(1-v[6],1-v[7]),Point(v[0],1-v[1])]
    }
    public func step(toward target: Insets, maximum: Int = 20, damping: Double = 0.65) throws -> Insets {
        guard maximum > 0, damping > 0, damping <= 1 else { throw CalibrationError.invalid("Invalid correction rate") }
        let v=zip(values,target.values).map { a,b -> Int in
            let delta=b-a
            if delta == 0 { return a }
            let movement=max(1,min(maximum,Int((Double(abs(delta))*damping).rounded())))
            return a+(delta > 0 ? movement : -movement)
        }
        return try Insets(v)
    }
    /// QR centres in the unwarped video canvas. Size/margin must match the Android guide metadata.
    public static func markerCentres(width: Double, height: Double, size: Double, margin: Double) throws -> [Point] {
        guard width > size+2*margin, height > size+2*margin, size > 0, margin >= 0 else { throw CalibrationError.invalid("Invalid guide layout") }
        let x=(margin+size/2)/width, y=(margin+size/2)/height
        return [Point(x,y),Point(1-x,y),Point(1-x,1-y),Point(x,1-y)]
    }
    public func panelToWall(markerCentres: [Point], measured: [Point]) throws -> Homography {
        let contentToPanel=try Homography(from: Self.unit,to: corners)
        return try Homography(from: markerCentres.map { try contentToPanel.apply($0) },to: measured)
    }
}
