import Foundation

public struct MarkerPayload: Equatable, Sendable {
    public let corner: String
    public let geometry: Insets
    public let width: Int, height: Int
    public init(_ text: String) throws {
        let pieces=text.split(separator:":",omittingEmptySubsequences:false)
        guard pieces.count==4,pieces[0]=="BEAM1",["TL","TR","BR","BL"].contains(String(pieces[1])),pieces[2].utf8.count==16 else { throw CalibrationError.invalid("Unrecognised projection marker") }
        let chars=Array(pieces[2]);var values=[Int]()
        for i in stride(from:0,to:16,by:2) {
            guard chars[i].isASCII,chars[i+1].isASCII,let v=Int(String(chars[i...i+1]),radix:36) else { throw CalibrationError.invalid("Invalid marker geometry") };values.append(v)
        }
        let size=pieces[3].split(separator:"x")
        guard size.count==2,let w=Int(size[0]),let h=Int(size[1]),(320...7680).contains(w),(240...4320).contains(h) else { throw CalibrationError.invalid("Invalid projection guide size") }
        corner=String(pieces[1]);geometry=try Insets(values);width=w;height=h
    }
    public func centres() throws -> [Point] { try Insets.markerCentres(width:Double(width),height:Double(height),size:(Double(height)*0.18).rounded(),margin:(Double(height)*0.015).rounded()) }
}

public struct ObservedMarker: Sendable {
    public let payload: MarkerPayload
    public let centre: Point
    public let confidence: Double
    public init(payload: MarkerPayload, centre: Point, confidence: Double) { self.payload=payload;self.centre=centre;self.confidence=confidence }
}

public func orderedMarkers(_ observations: [ObservedMarker], current: Insets) throws -> [ObservedMarker] {
    guard observations.count==4 else { throw CalibrationError.invalid("Keep all four projection codes in the camera view") }
    let ordered=try ["TL","TR","BR","BL"].map { id -> ObservedMarker in
        let group=observations.filter { $0.payload.corner==id }
        guard group.count==1 else { throw CalibrationError.invalid("Duplicate or missing projection code") };return group[0]
    }
    let first=ordered[0].payload
    guard ordered.allSatisfy({ $0.payload.geometry==current && $0.payload.width==first.width && $0.payload.height==first.height && $0.centre.finite && $0.confidence>=0.9 && $0.confidence<=1 }) else {
        throw CalibrationError.invalid("Wait for fresh, sharp codes matching the current projector corners")
    }
    guard convex(ordered.map(\.centre)) else { throw CalibrationError.invalid("The projection codes are crossed or too oblique") }
    return ordered
}
