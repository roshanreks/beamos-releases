# BeamOS iPhone companion

A native no-corner-tapping wall scan for a LiDAR-equipped iPhone, with the BeamOS remote in a second tab. Source implementation only: it has not yet been iOS SDK-built, signed or installed. See `../../docs/LIVE-CALIBRATION.md` for the precise validation boundary and remaining work.

The app pairs with BeamOS 0.20 over the local network. It measures a vertical wall, excludes measured obstructions and unknown cells, picks a 16:9 screen, applies bounded temporary corrections, checks fresh camera feedback and saves an acknowledged fit. The native app must stay open while a Mac or another browser watches the feed. Focus is manual.

Run the independent geometry checks with the existing Mac Command Line Tools:

```sh
swift run --package-path BeamCore BeamCoreChecks
```

Generate the checked-in Xcode project without extra dependencies:

```sh
python3 generate-project.py
```

After compatible Xcode and the iOS platform are installed:

```sh
xcodebuild -project BeamCompanion.xcodeproj -scheme BeamCompanion -configuration Release -destination 'generic/platform=iOS' CODE_SIGNING_ALLOWED=NO build
```

Then open `BeamCompanion.xcodeproj`, choose the owner's signing team and connected iPhone, and run. Device trust, Developer Mode and any Apple agreement require the owner to act on their devices. Do not add signing credentials or local provisioning files to git. `project.yml` is an optional XcodeGen alternative; `generate-project.py` is the dependency-free path used here.

The first run needs the projector's local address and its six-digit BeamOS pairing code. Camera permission and local-network permission are required for the requested scan. The Keychain stores pairing locally; no streaming-account credentials are requested.

Camera estimates are not a 100% accuracy guarantee. Reflections, dark surfaces, wall-plane drift, depth holes, scan-pattern shadows, projector corner limits and processing latency must be tested with the real device. There is no installable IPA in this repository yet.
