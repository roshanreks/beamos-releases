#!/usr/bin/env python3
"""Generate a small reproducible Xcode app project without requiring XcodeGen or extra packages."""
from pathlib import Path
import hashlib,plistlib,json
root=Path(__file__).resolve().parent
obj={}
def key(name):return hashlib.sha256(name.encode()).hexdigest()[:24].upper()
def add(identity,isa,**fields):
    ident=key(identity);obj[ident]={'isa':isa,**fields};return ident
sources=[];refs=[]
for path in sorted((root/'App').glob('*.swift')):
    ref=add('file:'+path.name,'PBXFileReference',lastKnownFileType='sourcecode.swift',path=path.name,sourceTree='<group>');refs.append(ref)
    sources.append(add('build:'+path.name,'PBXBuildFile',fileRef=ref))
info={'CFBundleDevelopmentRegion':'en','CFBundleDisplayName':'BeamOS','CFBundleExecutable':'$(EXECUTABLE_NAME)','CFBundleIdentifier':'$(PRODUCT_BUNDLE_IDENTIFIER)','CFBundleInfoDictionaryVersion':'6.0','CFBundleName':'$(PRODUCT_NAME)','CFBundlePackageType':'APPL','CFBundleShortVersionString':'0.1.0','CFBundleVersion':'1','LSRequiresIPhoneOS':True,'NSCameraUsageDescription':'Measure your projection wall, detect obstacles and verify screen alignment.','NSLocalNetworkUsageDescription':'Connect to your BeamOS projector and share camera feedback with your paired remotes.','NSAppTransportSecurity':{'NSAllowsLocalNetworking':True},'UIApplicationSceneManifest':{'UIApplicationSupportsMultipleScenes':False,'UISceneConfigurations':{}},'UILaunchScreen':{},'UISupportedInterfaceOrientations':['UIInterfaceOrientationPortrait','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight']}
(root/'App/Info.plist').write_bytes(plistlib.dumps(info))
product=add('product','PBXFileReference',explicitFileType='wrapper.application',includeInIndex=0,path='BeamCompanion.app',sourceTree='BUILT_PRODUCTS_DIR')
appgroup=add('appgroup','PBXGroup',children=refs,path='App',sourceTree='<group>')
products=add('products','PBXGroup',children=[product],name='Products',sourceTree='<group>')
main=add('main','PBXGroup',children=[appgroup,products],sourceTree='<group>')
package=add('package','XCLocalSwiftPackageReference',relativePath='BeamCore')
dependency=add('dependency','XCSwiftPackageProductDependency',package=package,productName='BeamCore')
framework=add('framework','PBXBuildFile',productRef=dependency)
sourcesphase=add('sources','PBXSourcesBuildPhase',buildActionMask=2147483647,files=sources,runOnlyForDeploymentPostprocessing=0)
frameworkphase=add('frameworks','PBXFrameworksBuildPhase',buildActionMask=2147483647,files=[framework],runOnlyForDeploymentPostprocessing=0)
resources=add('resources','PBXResourcesBuildPhase',buildActionMask=2147483647,files=[],runOnlyForDeploymentPostprocessing=0)
configs=[];projectconfigs=[]
for mode in ('Debug','Release'):
    settings={'PRODUCT_BUNDLE_IDENTIFIER':'com.beamos.companion','PRODUCT_NAME':'$(TARGET_NAME)','SDKROOT':'iphoneos','IPHONEOS_DEPLOYMENT_TARGET':'17.0','TARGETED_DEVICE_FAMILY':'1,2','SWIFT_VERSION':'5.0','CODE_SIGN_STYLE':'Automatic','INFOPLIST_FILE':'App/Info.plist','CURRENT_PROJECT_VERSION':'1','MARKETING_VERSION':'0.1.0','GENERATE_INFOPLIST_FILE':'NO','INFOPLIST_KEY_UIApplicationSceneManifest_Generation':'YES','SWIFT_OPTIMIZATION_LEVEL':'-O','LD_RUNPATH_SEARCH_PATHS':['$(inherited)','@executable_path/Frameworks']}
    configs.append(add('target-'+mode,'XCBuildConfiguration',name=mode,buildSettings=settings))
    projectconfigs.append(add('project-'+mode,'XCBuildConfiguration',name=mode,buildSettings={'CLANG_ENABLE_MODULES':'YES','SWIFT_VERSION':'5.0'}))
targetconfig=add('targetconfig','XCConfigurationList',buildConfigurations=configs,defaultConfigurationIsVisible=0,defaultConfigurationName='Release')
projectconfig=add('projectconfig','XCConfigurationList',buildConfigurations=projectconfigs,defaultConfigurationIsVisible=0,defaultConfigurationName='Release')
target=add('target','PBXNativeTarget',name='BeamCompanion',buildConfigurationList=targetconfig,buildPhases=[sourcesphase,frameworkphase,resources],buildRules=[],dependencies=[],packageProductDependencies=[dependency],productName='BeamCompanion',productReference=product,productType='com.apple.product-type.application')
project=add('project','PBXProject',attributes={'LastUpgradeCheck':'2660'},buildConfigurationList=projectconfig,compatibilityVersion='Xcode 14.0',developmentRegion='en',hasScannedForEncodings=0,knownRegions=['en','Base'],mainGroup=main,packageReferences=[package],productRefGroup=products,projectDirPath='',projectRoot='',targets=[target])
def encode(value,indent=0):
    if isinstance(value,dict):return '{\n'+''.join('\t'*(indent+1)+encode(k)+' = '+encode(v,indent+1)+';\n' for k,v in value.items())+'\t'*indent+'}'
    if isinstance(value,list):return '( '+', '.join(encode(v,indent) for v in value)+' )'
    if isinstance(value,int):return str(value)
    return json.dumps(value,ensure_ascii=False)
out=root/'BeamCompanion.xcodeproj';out.mkdir(exist_ok=True)
(out/'project.pbxproj').write_text('// !$*UTF8*$!\n'+encode({'archiveVersion':1,'classes':{},'objectVersion':56,'objects':obj,'rootObject':project})+'\n')
scheme=out/'xcshareddata/xcschemes';scheme.mkdir(parents=True,exist_ok=True)
(scheme/'BeamCompanion.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="2660" version="1.3"><BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="BeamCompanion.app" BlueprintName="BeamCompanion" ReferencedContainer="container:BeamCompanion.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction><LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="BeamCompanion.app" BlueprintName="BeamCompanion" ReferencedContainer="container:BeamCompanion.xcodeproj"/></BuildableProductRunnable></LaunchAction><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/></Scheme>''')
print(out)
