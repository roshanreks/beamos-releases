# Device change log — every write made to the projector, with its undo

Rule: nothing is changed on the projector without the user's OK and an entry here.

## 2026-10-20 — Final persistence release: Studio 0.16

- Follow-up within the approved persistence fix: prevent a delayed old adapter read or an old Settings preview timeout from undoing a newer saved phone adjustment. Source commit `d555abd`.
- Installed signed Studio 0.16 with app data retained; adapter remains 0.13. Picture corners, saved scene, playback app and preview status verified before/after.
- Published stable 0.16 and verified its deployed signature and both APK hashes. Studio SHA-256: `2A73B50A2FFC2198C672ED6A7EDB2A2982AA77E9FA797E9DA4FBE5BF4A8C29EF`.
- 28 isolated Android persistence checks, 10 companion checks and 2 fake-publisher checks passed. No real scene/geometry writes were used in the test VM.
- 0.15 remains an immutable earlier release; 0.16 is the current installed and stable version. Restore code through a higher-version signed update rather than uninstalling/clearing saved data.

## 2026-10-20 — BeamOS 0.15 persistence update

- Owner requested that both picture alignment and lighting mapping remain until explicitly changed, then approved: “Install the tested fix now”.
- Saved the current in-flight alignment through the existing Keep operation before updating; the picture values themselves were not changed.
- Installed the signed Studio 0.15 update with `adb install -r`; adapter remains 0.13, existing application data retained.
- Verified healthy hello/state/playback/mapping APIs, identical corners and saved scene before/after installation, same playback app and no active temporary preview. Alignment remained identical more than 120 seconds later.
- Published stable 0.15 to the existing release repository; verified deployed feed signature and both package SHA-256 hashes. Source implementation commit: `bb460c2`.
- Validation: 22 isolated Android persistence checks, 10 companion save/load checks, 2 fake-publisher checks, JS syntax and signed app build. The isolated test VM uses fake display/navigation boundaries and temporary files; it never changes live mapping or geometry.
- Behaviour: ordinary changes now save automatically; Undo saves its result. Explicit Settings safety previews still require Keep. Room-photo markers never replace the saved scene; room reference photos persist separately. Mapping output blocks scheduled updates.
- Recovery: current geometry is recorded in the private Codex review evidence. Older overwritten lighting coordinates were not recoverable from the device's empty scene/no named scenes. Do not clear app data or uninstall as a rollback. A code revert should be released with a higher versionCode; normal updates retain saved data.


## 2026-10-20 — Security cleanup (user approved: "Yes, disable the risky ones")

| Package | Why | Undo |
|---|---|---|
| `com.htc.storeos` | vendor App Store: silent remote install/uninstall/launch as system; self-updated v30→v46 without consent | `adb shell pm enable com.htc.storeos` |
| `com.htc.eventuploadservice` | per-app usage telemetry uploaded every 2 h over HTTP with MAC + serial | `adb shell pm enable com.htc.eventuploadservice` |
| `com.htc.expandsdk` | ad overlay (foreground-app polling, video ads) | `adb shell pm enable com.htc.expandsdk` |
| `com.htc.hyk_test` | factory test app (calls su) | `adb shell pm enable com.htc.hyk_test` |
| `com.htc.htcotaupdate` | firmware OTA over plain HTTP + remote "unauthorized → reboot" switch | `adb shell pm enable com.htc.htcotaupdate` |
| `android.rockchip.update.service` | sends serial to a LAN host; Android-level USB update.zip flasher | `adb shell pm enable android.rockchip.update.service` |

Command used: `adb -s 192.168.1.11:5555 shell pm disable-user --user 0 <pkg>` → all six report `disabled-user`; none running.
Expected effects: vendor "App Store" tile stops working (Google Play unaffected); no vendor firmware update prompts;
Android-level USB update.zip auto-flasher off (bootloader `auto_update` pen-drive path is independent).

## 2026-10-20 — Read-only probes that touched UI state (no lasting change)
- `service call SurfaceFlinger 1050` with the current values → denied, no change.
- Opened Settings → Projection Setting → Keystone Correction via D-pad, backed out without changes.
- Pressed RIGHT then LEFT on the launcher (focus moved and returned).
Keystone/zoom props verified unchanged afterwards.

## 2026-10-20 13:50–13:53 — System-uid probe (user approved plan: "Everything sounds great… start working")
- Installed `com.beamos.probe` (platform-signed with the PUBLIC AOSP key, `sharedUserId=android.uid.system`):
  `adb install` → Success, `userId=1000`, `sharedUser=android.uid.system`.
- `--es cmd ks_reapply` → **`transact1050 ok=true`** re-sending the existing values [183,187,166,165,166,165,183,187]
  → no visible change, no permission denial. **BeamOS can drive SurfaceFlinger keystone directly as uid 1000.**
- Uninstalled: `adb uninstall com.beamos.probe` → Success. Keystone props verified unchanged.
- Note: `am start -W` on a Theme.NoDisplay activity blocks ~2 min — use `am start` without `-W`.

## 2026-10-20 15:44–15:46 — Guarded keystone test 1 (owner present at the wall)
- Snapshot: recon/snapshots/picture-20261020-154450.txt (29 props).
- Installed probe v0.2 (`com.beamos.probe`, uid 1000). `ks_test` top-left inward: [183,187,266,265,166,165,183,187], 30 s.
- Finding: txn 1050 persisted the test values into `persist.display.keystone_lt*`; the probe's rollback re-read props and
  therefore re-applied the test values (bug). At 15:45:58 the original values [183,187,166,165,166,165,183,187] were
  re-applied; props verified identical to the snapshot.
- Probe fixed: rollback applies the captured copy and verifies props match. Probe remains installed for further tests
  (remove: `adb uninstall com.beamos.probe`).

## 2026-10-20 15:50–15:59 — Sideways (yaw) correction from a phone photo (owner present)
- Accelerometer: x=203, y=6, z=1004 (≈1g) → pitch ≈10–11° (firmware keystoneAngle −10), roll ≈0.3°; yaw is invisible
  to the sensor. Projector sits on the kitchen counter firing diagonally at the AC wall.
- Calibration pattern shown by the probe (`--es cmd pattern`). Photo IMG_8868 (1×, 24 mm) measured with
  tools/fit_from_photo.py using the AC unit as the wall reference (aspect 3.15 assumed): current picture on the wall is
  ~1.27× taller on the left than the right.
- Preview of computed insets [187,236,204,241,228,168,265,187] (LB,LT,RT,RB) for 60 s via `ks_test` with
  `am start -f 0x18000000` (second `am start` without NEW_TASK|MULTIPLE_TASK was swallowed by the open pattern task
  — no change at 15:56). Auto-restore at 15:58:52 → `match=true`; props equal the snapshot.
- Probe v0.4 adds `ks_set` (owner-confirmed apply, logs previous values) and `pattern`.

## 2026-10-20 16:23–16:27 — BeamOS installed (owner: "install it whenever you say … let's go")
- Snapshot: recon/snapshots/install-20261020-162328.txt.
- `tools/beamos-install.sh`: installed `com.beamos.adapter` 0.01 (uid 1000, AOSP platform key) and `com.beamos.studio` 0.01
  (BeamOS release key). Gateway on :8080; first-run picture saved [183,187,166,165,166,165,183,187].
- API tests: wrong code rejected, unpaired rejected, cross-origin rejected, POWER key rejected; pair (Mac-test token),
  state, keystone read, key RIGHT/LEFT, apps, icons all OK.
- **First over-the-air update**: published signed feed v0.02 on the Mac (macOS firewall blocks inbound → served through
  `adb reverse tcp:8765 tcp:8765`, feed URL set to http://127.0.0.1:8765/stable.json). Projector verified the ECDSA
  signature, adapter 0.01→0.02 and studio 0.01→0.02 installed silently by the adapter in ~6 s; gateway came back alone.
- Uninstalled `com.beamos.probe` (superseded by the adapter). BeamOS home reopened. NOT yet set as default HOME.
- Undo: `tools/beamos-uninstall.sh` (removes both apps, gives HOME back to the vendor launcher).
- Known issues for v0.03: AdapterClient rebind loop without back-off while the adapter package is being replaced;
  adapter start log prints Contract.VERSION instead of its package version.

## 2026-10-20 16:3x–16:40 — v0.03 over the air; WebSocket test collided with the owner's live session
- v0.03 (real-time Screen Coach + wall guides, BeamOS keyboard service, Live View) installed via OTA in ~6 s.
- 16:39:40 my WebSocket latency test (nudge latency measured 26 ms) ran on the shared coach session while the session
  had not loaded the real picture (vals all 0) → ~0.2 s near-full-frame flash, then `restore(cancel)` put back the
  owner's already-kept picture [328,357,329,175,196,179,204,358]. No owner changes lost (no preview was pending).
- Bug fixed in v0.04: CoachSession loads the real values at start and before any edit; phones ignore drags until loaded.
- Rule adopted: no device-write tests while the owner may be using the projector without telling him first.
- v0.04 published to the feed (not installed): owner installs it from the phone (More → Updates) when convenient.

## 2026-10-20 16:52 — Debloat + BeamOS as home (owner: "deblot … whatever you suggest, I'm fine with it")
- `tools/beamos-debloat.sh apply`: HOME role → com.beamos.studio (resolve-activity confirms BeamOS);
  disabled (pm disable-user): htclauncherhighenglishd08, allshare.edisplay.idisp, eshare.linedisplay.receiver,
  ecloud.emedia, softwinner.awlogsettings, android.music, mobisystems.office, google.android.youtube (phone);
  window/transition animation 1.0→0.5, animator_duration_scale unset→0.5; `pm trim-caches 4G`.
- Kept: htcsettings, closedialog, vafocus, TV input/HDMI, eshare.server + eairplay (screen sharing), Google services,
  file manager, screensaver.
- MemAvailable 298 MB → 344 MB immediately after (YouTube TV running).
- Undo everything: `tools/beamos-debloat.sh undo`.
- Note: at 16:52:01 the owner's phone (v0.04) opened the full-screen CoachActivity over YouTube (pauses playback) —
  fixed in v0.05 (transparent overlay). 16:52:12 studio restart = owner-initiated 0.03→0.04 update (not a crash).

## 2026-10-20 ~17:00 — v0.06 pushed; automatic update pipeline
- Owner report: opening Picture on the desktop showed the full-screen adjustment screen over YouTube (old page / auto
  guide). v0.06: the Picture tab never shows anything on the projector by itself; optional see-through guide only on
  "Show guide on wall"; phone/desktop can no longer open the full-screen CoachActivity (WS "coach_open" removed);
  pages auto-reload when BeamOS updates; AutoUpdate checks every 5 min and installs at once (waits only for unsaved
  picture edits); "type" now appends.
- Mac: LaunchAgent `com.beamos.feedkeeper` (tools/install-feed-keeper.sh; remove: `tools/install-feed-keeper.sh remove`)
  serves ~/Library/Application Support/BeamOS/feed on 127.0.0.1:8765 and keeps `adb reverse` + the connection alive
  (finds the projector by MAC if its IP changes). launchd cannot read ~/Desktop (TCC) → helper + feed live in App Support;
  `beamos/feed` is a symlink there.
- `tools/beamos-release.sh "notes"` bumped 0.05→0.06, built, published and pushed; projector updated itself; YouTube TV
  back in front; `appops set com.beamos.studio SYSTEM_ALERT_WINDOW allow` (guide overlay).

## 2026-10-20 17:32 — v0.07 (code-review + UX-rulebook fixes), pushed with nothing playing
- Adapter 0.07: Keystone restore retries every 5 s until confirmed (never forgets the original), preview validates before
  persisting, timeout race fixed, KS_GET returns previewId; Playback guard (MediaSessionManager) + MEDIA transport;
  Installer: one at a time, temp file, INSTALL_PACKAGES-protected result receiver + session-id check; IME list edited
  not replaced; `open` targets reduced to hdmi/vendor_settings/wifi/bluetooth/sound/projection; Picture re-inits after
  tvserver restart. Contract.validInsets now rejects concave/folded shapes.
- Studio 0.07: CoachSession is the single owner of geometry (fresh baseline before each edit, adopts a pending preview
  after restart, detects adapter-side expiry, keep returns a result, late previews cancelled, multi-value moves stop at
  limits, one notifier thread); HttpServer: 4 HTTP threads + capped WebSocket pool (6, 503 beyond), sockets really
  close, 10 s header deadline, Host allow-list (421); WsSession: no raw-key fallback for typing, 4401/4002 close codes,
  keep/revert on the session executor, Now Playing + media; AutoUpdate waits for idle (max 10 min while playing),
  single run, shared status; Updater streams downloads, install lock, re-checks the real outcome; Settings goes
  through CoachSession; CoachActivity nudges off the UI thread, text ≥28 px; web app: single socket, live-view cap
  (500 ms while playing), drag end handlers, Mac modifier keys ignored, confirm before launch/open while playing,
  Now Playing card, fit needs loaded values, update 409 explained.
- Scripts: quoted SDK paths, keystore password via file, atomic feed writes, no overwrite of a published APK with
  different bytes, adapter bump only on change, `curl -fsS` push with honest messages.
- Verified after install: both 0.07, hello OK, wrong Host → 421, /api/playback OK, removed endpoints 404, coach loaded.

## 2026-10-20 17:45–17:55 — Black screen explained; sleep timeout; boot videos installed
- Owner reported: projector on, black screen, no response to remote/phone/Mac, pings OK, ADB "offline". No
  watchdog/ANR/panic record in dropbox. Cause: `screen_off_timeout` = 300000 ms (5 min); the vendor launcher used to
  keep the screen awake, BeamOS home did not → device slept (`mLastSleepReason=application`). Owner power-cycled.
- Fix: `settings put system screen_off_timeout 10800000` + `setprop persist.sys.screentimeout 10800000` (3 h).
  Undo: `settings put system screen_off_timeout 300000; setprop persist.sys.screentimeout 300000`.
- Boot/shutdown videos: `adb push` to /oem fails with `fchown` → pushed to /data/local/tmp and `cp` into
  `/oem/media/{bootvideo,shutdownanimation}.mp4` (md5 edfb3d4c… matches). Not yet seen on a boot.
- ADB note: `adb push`/`shell` hang while the device sleeps; `adb kill-server` + reconnect after wake.

## 2026-10-20 17:59 — v0.08 pushed (YouTube TV was in front; only BeamOS restarted)
- Home keeps the screen awake (FLAG_KEEP_SCREEN_ON); `/api/sleep` + phone control (currently 180 min);
  adapter LogKeeper: 3×1 MB persistent logcat ring in /data/data/com.beamos.adapter/files/logs, readable via
  More → Logs → "Since before last restart"; first verification shows 48 KB captured within a minute.
- Verified: adapter 0.08, studio 0.08, hello OK, sleep API answers 180 min.

## 2026-10-20 18:10 — v0.09 pushed; internet updates live
- v0.09: Auto Screen (photo → automatic corner detection → applied live → refine), remote pad + volume under Live
  View, "Close background apps" (TRIM via killBackgroundProcesses, first run freed 14 MB), feed served from GitHub
  Pages (public repo roshanreks/beamos-releases: signed stable.json + APKs only) with the Mac tunnel as fallback.
- Projector feed set to https://roshanreks.github.io/beamos-releases/stable.json (undo: POST /api/update/feed with
  http://127.0.0.1:8765/stable.json). Pages verified serving 0.09.
- One-time `cmd package compile -m speed-profile -f` for BeamOS + YouTube TV and `bg-dexopt-job` (benign; no undo needed).
- Feed repo needs `http.version=HTTP/1.1` for pushes (set in its git config).


## 2026-10-20 — v0.17 picture controls and white-wall viewing profiles
- Owner authorised immediate installation and publication: “Check that, fix that, and publish the update right away through everything.” Later confirmed separate picture modes in the Mac/web remote, some room lighting, and requested maximum supported output/cooling.
- Root cause: companion slider `pic` WebSocket messages had no server handler. Fixed legacy WS handler; new companion uses serialized/coalesced acknowledged HTTP writes with retry and stale-reply protection.
- Adapter: complete 13-parameter bounded picture apply with readback verification and best-effort rollback; preserve other current values when editing native Custom; supported maximum panel setter (level 3 = 100) with High-bright mode 2. No geometry, source or media transport commands.
- Studio: projector-owned custom/named presets, optional device/room labels, apply/update/delete, 32-preset limit; retain active look and presets through controller restart and APK update. Labels do not automatically switch by device/app.
- Nine built-ins: Anime, YouTube, Netflix, Cinema, Bright room, Balanced, Vivid, Game, Text / PC. All use High-bright + PQ panel 100, dynamic backlight off; conservative image controls preserve details. Anime uses gamma selector 2.0 with noise smoothing off as a starting point for the owner's white wall and some room lighting. Netflix is a picture look, not a streaming-service certification or resolution unlock.
- Preserved “Before picture update” recovery preset on the projector. Current keystone/mapping is never replaced by a picture preset.
- Brightness investigation: driver brightness 100 / max_brightness 100, vendor lamp property 2, panel level property 3, no custom array. No additional brightness reserve established. No claim of measured lumens or colour calibration.
- Fan request: stock UI's highest menu level 4 attempted; real speedlevel write denied, remained 2/iopwm50. Restored ineffective fan property to original unset value. /sys/class/prj/mode and RPM tach node absent; do not claim full-speed cooling. LCD 57 °C at check. Temperature cutoffs, fan protection and raw PWM unchanged.
- Validation: 38 isolated Android picture-preset checks + 12 companion picture checks; existing 28 Android geometry/mapping and 10 web persistence checks pass. Both signed APK builds pass. Live hardware/UI and update-retention evidence recorded in this chat's outputs. See docs/PICTURE-LOOKS.md for settings, primary GitHub research and measurement plan.

## 2026-10-20 — Studio 0.18 photo fit, typing and camera foundation

- Owner requested fixing both photo controls, automatic saving and proportional resizing, continuing live phone-camera work. Studio 0.18 installed with application data retained; Adapter remains 0.17. Final publication/byte verification is recorded in the Codex output evidence.
- Existing corner values, picture settings and mapping scene retained; no synthetic photo fit was applied to the physical wall. Original HEIC and generated four-code photo tested in Chrome with automatic apply disabled. Physical wall fit still needs a fresh photo/reference.
- Versioned QR capture metadata, acknowledged hardware apply/save, persisted plane model, bounded proportional resize and guarded undo. Realistic tilted projector/oblique camera math and persistence tests pass.
- Phone text/OTP tests used a disposable test app and dummy values; ordinary text and six advancing cells passed. Test app removed; YouTube restored.
- Unused EShare/AirPlay receivers force-stopped to reduce memory pressure; packages retained and can be reopened. A full-resolution digital screenshot caused Android low-memory restarts; no thermal protections or RAM-killer limits changed.
- Live-camera API gate and Swift geometry library tested; no complete iPhone app, automatic live writer or shared camera viewer yet. No Netflix licences, pirated APKs or undocumented fan/current overrides installed.
- Roll back code with a higher signed version rather than uninstalling/clearing saved data. Fit/resize Undo is guarded by the currently confirmed geometry.

## 2026-10-20 — Studio 0.19 final photo workflow follow-up

- Browser verification found projector input focus could cover the Picture form with the remote typing sheet. Restrict automatic sheets to Remote/Live/Type; close them when navigating to other tools. Seven routing checks pass.
- Signed Studio 0.19 installed retaining app data. Adapter stays 0.17. 0.18 remains immutable. Final signed-public-feed/hash checks are recorded in the output release manifest.
