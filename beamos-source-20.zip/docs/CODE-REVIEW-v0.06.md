# BeamOS v0.06 — correctness review (read-only)

Date: 2026-10-20 · Scope: `beamos/adapter`, `beamos/studio` (Java + `assets/web/index.html`), `beamos/common`,
`beamos/geometry`, `tools/build-apk.sh`, `tools/beamos-release.sh`, `tools/beamos-publish.sh`,
`tools/beamos-feed-keeper.sh`. Method: every file was read in full. Nothing was built or modified, adb was not run,
and no device was touched. The only thing executed was a Python arithmetic check of `Contract.validInsets` (M4).
Paths are relative to `projector-lab/beamos/` unless they start with `tools/`.

Severity: **critical** = unauthenticated takeover or automatic playback interruption · **high** = realistic picture
jump/desync, crash, or loss of the remote · **medium** = real bug with a narrower trigger · **low** = robustness,
hygiene, or UI honesty.

No critical findings. I found no background feature that starts an Activity, takes focus, or requests audio focus.
The remaining playback risks need a user action or a paired client (M1, M2, M3, M15).

| ID | Sev | Area | One line |
|----|-----|------|----------|
| H1 | high | geometry | `keep()` ignores a failed confirm; the session never learns the adapter auto-reverted → "Saved ✓" while the wall shows the old picture, and the next nudge jumps |
| H2 | high | geometry | `CoachSession.vals` is loaded once per process, so the next nudge after any outside keystone change jumps the picture back |
| H3 | high | geometry/update | A studio restart during an unsaved edit adopts the preview values as "Saved ✓" and the adapter reverts ≤120 s later. The update push and the Install button don't check for edits |
| H4 | high | lifecycle | `CoachActivity` nudges on the UI thread. When values aren't loaded this blocks for ~125 s (ANR), then throws → studio crash (HOME, gateway, IME) |
| H5 | high | concurrency | WebSockets pin the 12-thread HTTP pool. `Ws.close()` never closes the socket, so evicted or vanished clients hold threads forever → remote dead |
| M1 | med | playback | "type"/"action" fall back to raw key injection into the focused app: Space → play/pause, Enter → OK |
| M2 | med | playback | Adapter `OPEN` still accepts `coach` (full-screen CoachActivity) and `studio_home`: the removed v0.04 incident path |
| M3 | med | playback/web | Live View loop can multiply and has no fps cap (screen captures while video plays); object-URL leak |
| M4 | med | geometry | `Contract.validInsets` accepts concave quads, e.g. dragging TL to the canvas centre from stock |
| M5 | med | geometry | Adapter rollback can fail permanently: no retry, a `false` result still clears state, restore uses the edit validator |
| M6 | med | geometry | Settings "Full-frame (15 s)" / "Restore" and `/api/keystone/*` share the coach's preview slot. They shorten its timer and commit or cancel its edits |
| M7 | med | web | Canvas drag never ends on pointercancel/lostpointercapture. On a Mac, hovering then keeps moving a corner on the wall |
| M8 | med | web | Keep/Revert toast "Saved"/"Reverted" unconditionally, even when nothing was sent |
| M9 | med | security | DNS rebinding passes the Origin==Host check → any website can brute-force or lock out pairing |
| M10 | med | concurrency | WebSocket close → `shutdownNow()` drops or interrupts a pending keep/revert |
| M11 | med | geometry | Edge/whole-picture nudges clamp each inset separately → the picture narrows or skews at the panel limit instead of stopping |
| M12 | med | concurrency/web | 5+ clients cause an endless evict/reconnect loop (MAX_CLIENTS 4, 500 ms reconnect) |
| M13 | med | update | Concurrent installs share temp files on both sides with no lock; AutoUpdate runs can overlap |
| M14 | med | web/playback | Mac keyboard handler ignores modifiers, focus and repeat: ⌘=/⌘- change volume, Space/Enter on Picture tab hit the movie |
| L1–L23 | low | various | see §7 |

---

## 1. Playback interruption / Activity starts

### M1 — Typing falls back to raw key events into the playing app (medium)
- `studio/src/com/beamos/studio/WsSession.java:86-96`, `studio/assets/web/index.html:212-219, 275, 305-309`,
  `adapter/src/com/beamos/adapter/Input.java:60-73`
- Scenario: the BeamOS keyboard is OFF (the default) or no text box has focus, and a video is playing. The user
  opens ⌨︎ Type and taps **Send + Enter**. `BeamIme.active()` is null, so `"type"` becomes `Contract.TEXT`, which
  injects one KeyEvent per character into the focused window: the player. The space becomes `KEYCODE_SPACE`, which
  most players treat as play/pause, and letters can trigger player shortcuts. The follow-up `"action"` injects
  `KEYCODE_ENTER` (66), which players treat as OK and use to toggle pause or show controls.
- The same happens with the IME active whenever the field has lost focus by the time `"action"` arrives. That
  message is sent 120–150 ms after the text (L275, L307–308).
- The HTTP fallback in `send()` (L215–216) does the same raw injection whenever the WebSocket is down.
- Fix:
  ```java
  case "type": {
      BeamIme ime = BeamIme.active();
      if (ime == null) { ws.send("{\"t\":\"error\",\"err\":\"No text box is selected on the projector\"}"); break; }
      ime.commit(m.getString("text")); break;
  }
  case "action": {
      BeamIme ime = BeamIme.active();
      if (ime == null || !ime.action()) ws.send("{\"t\":\"error\",\"err\":\"No text box is selected\"}");
      break;   // never inject KEYCODE_ENTER blindly
  }
  ```
  In the web app, drop the `"type"` HTTP fallback. If raw typing is still wanted for apps without an IME, make it
  a separate, explicitly labelled button, and strip `' '`/`'\n'` unless the user confirms.

### M2 — The adapter can still start CoachActivity / HomeActivity over playback (medium, defense in depth)
- `adapter/src/com/beamos/adapter/AdapterService.java:198-199`, `common/src/com/beamos/common/Contract.java:32`,
  `studio/src/com/beamos/studio/Api.java:139-141`
- The v0.06 changelog says phones can no longer open the full-screen CoachActivity, because WS `coach_open` was
  removed. But `OPEN {target:"coach"}` and `{target:"studio_home"}` still exist, and `/api/open` forwards any
  target. Any paired client, script, or stale cached page can still put a full-screen activity over YouTube with
  one POST. That is exactly the incident class in `docs/CHANGELOG-DEVICE.md`. Neither target is used anywhere:
  the home tile starts CoachActivity directly.
- Fix: delete both branches from `open()` and update the Contract comment. Consider an allow-list in `Api` for
  `/api/open` too: `hdmi|wifi|bluetooth|sound|projection|vendor_settings`.

### M3 — Live View: loops multiply and nothing caps the capture rate (medium)
- `studio/assets/web/index.html:341-359`
- `liveRun()` starts a loop whenever `!liveBusy`, but `liveBusy` is false between iterations, while the next
  `requestAnimationFrame(liveLoop)` is pending.
  - Scenario: Live tab open, page hidden (rAF is paused with one callback queued), then visible again.
    `visibilitychange` calls `liveRun(true)`, which starts loop B, and then the queued rAF resumes loop A. Every
    hide/show or `go("live")` in that gap adds another loop.
  - Each loop runs as fast as fetch allows (rAF only). Each frame is a `SurfaceControl.screenshot` plus a JPEG
    encode on the projector (`adapter/.../Screen.java:38-53`) and holds one of the 12 HTTP threads (H5).
  - Two or three loops at full rate while a movie plays is real GPU/CPU load on an H713 and risks dropped video
    frames.
- Leak: `liveImg.onload = () => URL.revokeObjectURL(u)` (L352) is a single property. If the next frame is assigned
  before the previous one decodes, or decoding fails, the previous blob URL is never revoked.
- Fix:
  ```js
  let liveGen = 0, liveUrl = null;
  function liveRun(on) { const want = on && !document.hidden; if (want === liveOn) return; liveOn = want; if (want) liveLoop(++liveGen); }
  async function liveLoop(gen) {
    while (liveOn && gen === liveGen) {
      const t0 = performance.now();
      try {
        const r = await fetch("/api/screen?w=" + $("#liveQ").value + "&q=55&t=" + token, { cache: "no-store" });
        if (r.ok) { const u = URL.createObjectURL(await r.blob()); liveImg.src = u; await liveImg.decode().catch(() => {});
                    if (liveUrl) URL.revokeObjectURL(liveUrl); liveUrl = u; }
        else await new Promise(s => setTimeout(s, 800));
      } catch (e) { await new Promise(s => setTimeout(s, 1000)); }
      await new Promise(s => setTimeout(s, Math.max(0, 150 - (performance.now() - t0))));   // ≤ ~6–7 fps
    }
  }
  ```

### M14 — Mac keyboard shortcuts leak into the playing app (medium)
- `studio/assets/web/index.html:262-271`
- The handler skips only INPUT/TEXTAREA/SELECT. It never checks `e.metaKey/ctrlKey/altKey`, `e.repeat`, or a
  focused BUTTON.
  - ⌘= and ⌘- (browser zoom; Chrome and Safari deliver these keydowns to the page) match `"="`/`"-"`. They change
    projector volume, and `preventDefault()` also blocks the zoom.
  - Holding Space sends repeated play/pause toggles.
  - On the Picture tab ("adjust while you watch"), Enter and Space are not consumed. They go to the foreground app
    as OK and Play/Pause, which pauses the movie. CoachActivity users expect OK to mean "next corner".
- Fix: at the top of the handler, add
  `if (e.metaKey || e.ctrlKey || (e.repeat && !e.key.startsWith("Arrow"))) return;`
  and on the Picture tab map Enter to "next corner" and ignore Space. Also skip Space/Enter when
  `document.activeElement.tagName === "BUTTON"`.

### Checked: no background feature interrupts playback
- AutoUpdate, FirstRun, GatewayService, AdapterClient (re)binds, the Keystone timer and BootReceivers start only
  services.
- `GuideOverlay` uses `FLAG_NOT_FOCUSABLE|FLAG_NOT_TOUCHABLE`. Nothing calls `requestAudioFocus`. Toasts don't take
  focus.
- Stale claim: the web app says auto-update "installs when nothing is playing" (index.html:532). `AutoUpdate` only
  checks `CoachSession.dirty()`. A studio update kills BeamIme mid-typing and removes the wall guide. Fix the text
  or add a check.

---

## 2. Keystone / geometry safety

### H1 — Keep can silently fail; the session never learns the adapter reverted (high)
- `studio/src/com/beamos/studio/CoachSession.java:174-192` (confirm result ignored), `:222-245` (no expiry
  tracking), `adapter/src/com/beamos/adapter/Keystone.java:85-89, 94-101`
- Scenario:
  1. The user adjusts corners, gets distracted, and comes back after more than 2 minutes.
  2. The adapter's 120 s timer has already restored the original and cleared `id`.
  3. The user taps **Keep**. `KS_CONFIRM(oldId)` returns `ok=false`, which `keep()` ignores. It sets `dirty=false`
     and publishes "Saved ✓" with the edited `vals`, while the wall shows the original.
  4. The next nudge computes from the edited `vals` (a new adapter preview is created against the original), so
     the picture jumps back to the old edit plus one step.
- The same happens with the CoachActivity BACK → Keep dialog after 120 s of idle time.
- Fix:
  ```java
  boolean keep() {
      String id; synchronized (this) { waitIdle(); id = previewId; }
      boolean ok = id != null && AdapterClient.get(ctx).call(Contract.KS_CONFIRM, bundle("id", id)).getBoolean(Contract.KEY_OK);
      synchronized (this) {
          previewId = null; undo.clear(); dirty = false;
          if (!ok && id != null) lastError = "The edit had expired after 2 min — the previous picture was restored";
      }
      if (!ok) load(); else changed();    // resync vals with the wall
      return ok;
  }
  ```
  Also mirror the adapter timer. After each successful `KS_PREVIEW`, record `lastOkAt` and schedule a check at
  `PREVIEW_SECS*1000 + 500` on a scheduled executor. If no newer preview happened and `KS_GET.previewActive` is
  false, set `dirty=false; previewId=null; undo.clear(); lastError="reverted after 2 min idle"` and `load()`.
  Return the keep result to clients as `{"t":"kept","ok":…}` (see M8).

### H2 — The baseline is never refreshed after outside keystone changes (high)
- `studio/src/com/beamos/studio/CoachSession.java:52-61, 76-86, 90-113`. `load()` is called only by the
  constructor, `CoachActivity.onCreate` and `revert()`. `ensureLoaded()` from WsSession (L50, L107) is a no-op once
  `loaded` is set.
- Scenario: the web app's 🎯 Projection button opens the vendor keystone screen
  (`index.html:154`, `AdapterService.java:204`). Other sources of change: Settings "Full-frame (try 15 s)" → Keep,
  "Restore picture from before BeamOS", `/api/keystone/*`, or auto keystone if it rewrites the corners.
  1. The geometry changes through one of these paths.
  2. Hours later the user opens Picture on the phone and taps ▲. `nudgeLocked` computes from `vals` loaded at
     process start.
  3. The adapter applies that old geometry plus 5 → the picture jumps to a stale shape. The phone canvas also
     shows the stale quad, because the state sent on connect is the cached one.
- Fix: refresh whenever an edit starts from a clean state:
  ```java
  void nudge(String m, int dx, int dy, int step) {
      if (!ensureLoaded()) throw new IllegalStateException("picture values not loaded yet");
      if (!dirty()) load();                  // fresh baseline for every new edit (no-op while dirty)
      nudgeLocked(m, dx, dy, step);
  }
  ```
  Do the same in `set(..)` when `pushUndo` (start of a drag) and in `undo()`. Also call `if (!cs.dirty()) cs.load()`
  in `WsSession.session()` before sending the state, and on `"guides"`.

### H3 — A studio restart during an unsaved edit shows "Saved ✓", then the picture reverts (high)
- `studio/src/com/beamos/studio/CoachSession.java:76-86` ignores `previewActive`.
  `studio/src/com/beamos/studio/Api.java:177-183` has no guard. `tools/beamos-release.sh:20-22` pushes
  `/api/update/install` right after every release, and the More → Install button (`index.html:543`) does too.
- Scenario:
  1. The owner runs `beamos-release.sh` while the phone has unsaved corner edits. AutoUpdate would defer, but the
     pushed `/api/update/install` doesn't check `dirty`.
  2. The studio is reinstalled and its process dies. The new `CoachSession.load()` reads `KS_GET`, which returns
     the preview values with `previewActive=true`. It stores them with `dirty=false` and `previewId=null`.
  3. The reloaded page shows "Saved ✓". Keep does nothing because there is no id.
  4. Up to 120 s later the adapter restores the old picture: an unexpected jump, and the stale-`vals` problem from
     H1 follows.
- Any studio crash during an edit has the same effect, for example H4 or L8.
- Fix:
  - Adapter `KS_GET`: also `out.putString("previewId", keystone.previewId())` (trusted caller only).
  - `CoachSession.load()`:
    `if (r.getBoolean("previewActive")) { dirty = true; previewId = r.getString("previewId"); lastError = "Unsaved picture change — Keep or Revert"; }`
  - `/api/update/install`: `return err(409, "picture edit in progress")` when `cs.dirty()` or `previewActive`.
  - Release script: `curl -fsS … || echo "not installed now (edit in progress or offline)"`.

### M4 — Concave quads pass `validInsets` (medium)
- `common/src/com/beamos/common/Contract.java:55-60`, `studio/assets/web/index.html:408-414`
- The function checks only the 0..500 range and the opposite-edge sums. Payload-order examples, checked with
  Python, where `validInsets` returns true:
  - `[0,450,500,450,0,0,0,0]`: the turn at TL is −0.175, so the quad is concave.
  - Stock `[183,187,166,165,166,165,183,187]` with TL dragged to the canvas centre (`ltx=lty=500`, an easy sloppy
    drag) gives a turn of −0.0017: a concave "dart" sent to SurfaceFlinger.
- `geometry/.../KeystoneInsets.validateQuad` already has the right convexity test, but nothing uses it.
- Fix: add it to `Contract.validInsets`, which the adapter, `CoachSession` and the fit flow all use:
  ```java
  double[][] q = {{v[2]/1e3, v[3]/1e3}, {1-v[4]/1e3, v[5]/1e3}, {1-v[6]/1e3, 1-v[7]/1e3}, {v[0]/1e3, 1-v[1]/1e3}};
  for (int i = 0; i < 4; i++) { double[] a = q[i], b = q[(i+1)%4], c = q[(i+2)%4];
      if ((b[0]-a[0])*(c[1]-b[1]) - (b[1]-a[1])*(c[0]-b[0]) <= 0.005) return false; }
  ```
  Restores must not go through this stricter check (see M5). In the web app, skip a drag point that fails the
  same test instead of sending it.

### M5 — Adapter rollback can fail and never retry (medium)
- `adapter/src/com/beamos/adapter/Keystone.java:110-121, 134-136, 75-92`
- **Exception path:** if `apply(original)` throws (SurfaceFlinger binder error, or an original that fails
  `validInsets`), prefs stay, `onExpiry` only logs "RESTORE FAILED", and no timer is re-armed. The preview stays
  on the wall, and SurfaceFlinger has persisted it, until the adapter process restarts.
  - Making `validInsets` stricter (M4) without separating restore from editing would turn this into a permanent
    trap: any vendor-set original that fails the new rule could never be restored.
- **False-return path:** if `sf.transact` returns false, `restorePending` still clears prefs. `match` is computed
  and only logged. The original is forgotten and the preview becomes permanent.
- **preview():** it persists `id/original` before validating and arms the timer after `apply()`. A first preview
  with invalid values leaves a pending state with no timer.
- Fix:
  ```java
  synchronized boolean restorePending(String why) {
      String original = prefs().getString("original", null); if (original == null) return false;
      handler.removeCallbacks(expiry);
      int[] v = split(original); boolean ok;
      try { ok = applyUnchecked(v); } catch (Exception e) { ok = false; Log.e(TAG, "restore", e); }   // range/length check only
      if (!ok || (real && !Arrays.equals(read(), v))) { handler.postDelayed(expiry, 5000); return false; }  // retry
      prefs().edit().clear().commit(); return true;
  }
  ```
  In `preview()`: check `Contract.validInsets(v)` first, then persist with `commit()` (id, original, expires in
  one edit), then `postDelayed(expiry, …)`, then `apply(v)`. Throw if `apply` returns false.

### M6 — Other flows share the coach's single preview slot (medium)
- `studio/src/com/beamos/studio/SettingsActivity.java:51-55, 95-126`, `studio/src/com/beamos/studio/Api.java:152-162`,
  `adapter/src/com/beamos/adapter/Keystone.java:75-92`
- Scenario: the phone has unsaved coach edits, and someone uses Settings → "Full-frame picture (try 15 s)".
  `preview()` reuses the coach's id and resets the timer to 15 s. Then:
  - **Revert** (or no answer) restores the picture from *before the coach session* and wipes the phone's edits.
  - **Keep** commits everything.
  - Either way `CoachSession` still has `dirty=true`, a stale `previewId` and stale `vals`, which leads to the H1/H2
    symptoms.
- `/api/keystone/preview|confirm|cancel` give any paired client the same bypass. `cancel` with no id restores
  whatever preview is pending. The web app doesn't use these endpoints.
- Fix: send every geometry change through `CoachSession`, using `set(vals, true)` + `keep()`/`revert()` from
  Settings. Remove `/api/keystone/preview|confirm|cancel`, or rewrite them as thin wrappers over `CoachSession`. At
  minimum, Settings should refuse while `CoachSession.get(this).dirty()` and call `load()` after its own
  confirm/cancel.

### M11 — Edge and whole-picture nudges clamp each inset separately (medium)
- `studio/src/com/beamos/studio/CoachSession.java:120-129`
- Scenario: in mode ALL with the right edge at the panel border (`rtx=rbx=0`), pressing ▶ moves `v[4]`/`v[6]` to
  −5, which clamps to 0, while `v[2]`/`v[0]` grow by 5. The picture gets narrower on every press instead of
  stopping, and the trapezoid correction becomes asymmetric. TOP/BOTTOM/LEFT/RIGHT behave the same way, and so
  does ALL ▲ ("bigger") once some insets reach 0.
- Fix: for multi-value modes, reject the move if any affected value would leave [0,500]. Alternatively, shrink the
  step to the largest one that keeps every affected value in range:
  ```java
  for (int i = 0; i < 8; i++) if (v[i] < Contract.INSET_MIN || v[i] > Contract.INSET_MAX) { changedLater(); return; }
  ```
  Keep the per-value clamp only for the four single-corner modes.

### L1 — The expiry timer can revert a preview that was just extended (low)
- `adapter/src/com/beamos/adapter/Keystone.java:88-89, 134-136`
- `removeCallbacks` cannot cancel an `onExpiry` that has already been dequeued and is waiting on the monitor.
- Scenario: a preview call lands just as the timer fires. `preview()` applies the new values and re-arms the timer,
  then the waiting `onExpiry` restores the original and clears the id.
- Fix: inside `restorePending("timeout")`, skip if `System.currentTimeMillis() < prefs().getLong("expires", 0)`.

### L2 — 3 s `waitIdle` timeout lets a late preview land after revert/keep (low)
- `studio/src/com/beamos/studio/CoachSession.java:194-220, 222-245`
- If `KS_PREVIEW` takes longer than 3 s (AdapterClient waits up to 6 s during an adapter restart/update),
  `revert()` sends `KS_CANCEL` and the in-flight preview lands afterwards. The edit is re-applied with a new 120 s
  timer while the UI says reverted, and the picture jumps again 2 minutes later.
- `keep()` can similarly confirm the previous id, leaving the last nudge as a new pending preview that reverts.
- Fix: add an `epoch` counter. `revert`/`keep` increment it. When the applier finishes a call made under an older
  epoch, it immediately sends `KS_CANCEL` (after revert) or `KS_CONFIRM` (after keep) for the returned id. Or wait
  for `!applying` with no timeout.

### L6 — Fit from photo doesn't require loaded values (low)
- `studio/assets/web/index.html:519-525`, `CoachSession.java:35`
- `fit(..., cs.vals || ks)`: when `ensureLoaded` failed, the connect-time state has `vals=[0×8]` and
  `loaded:false`. The fit then assumes a full-frame baseline and sends absolute wrong insets.
- Fix: `if (!cs.loaded) return toast("Reading the current picture…");`

---

## 3. Concurrency / lifecycle

### H4 — CoachActivity nudges on the UI thread: ANR, then a crash (high)
- `studio/src/com/beamos/studio/CoachActivity.java:68`, `CoachSession.java:53-61, 105-107`,
  `AdapterClient.java:66-72`
- While `loaded` is false, `nudge()` calls `ensureLoaded()`, which runs up to 20 × `load()` on the main thread.
  Each `AdapterClient.call` does `bound.await(3s)` twice.
  - `onServiceConnected` is delivered on the main thread, so it can never arrive while main is blocked. The block
    is therefore the full ~125 s, which raises an ANR.
  - Then `IllegalStateException` is thrown out of `onKeyDown`, which kills the studio process: HOME, the HTTP
    gateway, BeamIme and the overlay.
- Trigger: any arrow press in Screen Coach before the first successful `KS_GET`. That covers an adapter that is
  missing, crash-looping or mid-update, and the first seconds after a studio start.
- Fix:
  ```java
  private final ExecutorService io = Executors.newSingleThreadExecutor();
  ...
  if (!session.loaded()) { Studio.toast(this, "Reading the current picture…"); return true; }
  final int fdx = dx, fdy = dy, st = step;
  io.execute(() -> { try { session.nudge(null, fdx, fdy, st); } catch (Exception ex) { Log.w(Studio.TAG, "nudge: " + ex); } });
  ```
  Also guard `AdapterClient.call`: if `Looper.myLooper() == Looper.getMainLooper()`, log the stack and return an
  error Bundle instead of waiting on the latch.

### H5 — WebSockets and slow clients exhaust the 12-thread HTTP pool (high)
- `studio/src/com/beamos/studio/HttpServer.java:74, 91-92, 114-122`, `Ws.java:98-102`,
  `WsSession.java:32-47, 62-67`, `Events.java:16-21`
- How threads get pinned:
  - Each WebSocket session runs on a pool thread for its whole lifetime, with `setSoTimeout(0)` and no TCP
    keepalive.
  - `Ws.close()` only sends a close frame and sets a flag. It never closes the socket, so a reader blocked in
    `in.read()` is only released if the peer answers.
- Two failure modes:
  - **Evicted client that has vanished.** When a 5th client connects, `Events.subscribe` evicts the oldest and its
    writer exits. If that phone has slept or left Wi-Fi, nothing ever writes to the socket again, so the reader
    blocks forever.
  - **Vanished client that wasn't evicted.** The writer's 20 s pings keep the thread alive until the TCP
    retransmission timeout, about 15 min with Linux defaults.
- Other ways to pin threads:
  - A slow-reading client blocks `Ws.frame()` while it holds the Ws lock, which also blocks the reader and `close()`.
  - Any LAN host can pin threads without a token by sending headers one byte every 14 s: the 15 s timeout is per
    read, not per request.
- Once 12 threads are pinned, page loads, `/api/*`, Live View and new WS upgrades queue forever in the unbounded
  executor queue. The phone remote is dead until the studio restarts.
- Fix:
  - Give `Ws` the `Socket`. `close()` sends the close frame and then calls `socket.close()`, which unblocks the
    reader.
  - For WebSockets, `sock.setSoTimeout(60_000)` and `setKeepAlive(true)`. Browsers answer the server's 20 s pings
    with pongs, so a 60 s read timeout only catches dead peers.
  - Run WebSocket sessions on their own executor capped at about 6 sessions; refuse with 503 beyond that.
  - Enforce a total header deadline (for example 10 s) in `parse()`.

### M10 — Closing the WebSocket drops or interrupts Keep/Revert (medium)
- `studio/src/com/beamos/studio/WsSession.java:33, 65, 103-104`, `CoachSession.java:215-219`
- Keep/revert run on a per-socket executor that is `shutdownNow()`'d when the socket closes, for example when the
  user taps Keep and locks the iPhone.
  - Queued tasks are discarded, so the edit reverts ≤120 s later.
  - A running `keep()` that is inside `waitIdle()` is interrupted, returns early, and confirms the previous id. The
    last nudges then become a new pending preview that reverts.
- Fix: run keep/revert on a process-wide single-thread executor owned by `CoachSession`. Use `slow.shutdown()`
  for touches. In `waitIdle`, re-assert the interrupt flag (`Thread.currentThread().interrupt()`) and don't proceed
  with a stale id.

### M12 — Evict/reconnect loop with five or more clients (medium)
- `studio/src/com/beamos/studio/Events.java:12, 16-21`, `studio/assets/web/index.html:205-209`
- Scenario: Mac tab, iPhone, iPad and two forgotten tabs connect.
  1. Each new connection evicts the oldest session.
  2. The evicted client reconnects after 500 ms, because `wsRetry` is reset on every successful open, and evicts
     the next one.
  3. This repeats forever. Each round runs `ensureLoaded`, sends the state, churns a pool thread, and makes the
     typing sheet and status flicker.
- Fix: raise `MAX_CLIENTS`, or close the newcomer with code 4002 ("too many devices") instead of evicting. On the
  client, don't auto-reconnect on 4002, and reset `wsRetry` only after the socket has stayed open for 10 s.

### M13 — Concurrent installs race on shared temp files (medium)
- `studio/src/com/beamos/studio/Updater.java:122-143` (`cacheDir/<pkg>.apk`),
  `adapter/src/com/beamos/adapter/Installer.java:38-101` (`cacheDir/update.apk`), `AutoUpdate.java:40-47` (a new
  thread every 5 min even if the previous run is still going), `Api.java:177-183` (a new thread per request)
- Triggers: an AutoUpdate run, the release-script push and the More/Settings Install button can overlap. Each one
  truncates the same file another is hashing or installing.
- Result: spurious "sha256 mismatch" or parse failures. In the adapter, the bytes that were hashed (streamed) and
  the bytes installed (re-read from `tmp`) can come from different calls.
- Fix: a static lock around `Updater.install`, and an `AtomicBoolean running` in AutoUpdate. In the adapter, use
  `synchronized (Installer.class)` with `File.createTempFile`, or stream into the `PackageInstaller.Session` while
  hashing and `abandon()` on mismatch, so the verified bytes are the installed bytes.

### L3 — `changedLater` starts a thread per change and drops the final state (low)
- `studio/src/com/beamos/studio/CoachSession.java:266-272`
- Up to about 60 new threads per second during drags. They aren't leaked, but it's churn.
- The 16 ms leading-edge throttle drops the *last* change when two arrive within 16 ms. For mode/step/guide
  changes there is no later applier notification, so the overlay and phone show a stale mode/guide.
- Threads can also publish out of order (state computed earlier, published later).
- Fix: use one notifier (HandlerThread) with trailing-edge coalescing:
  `if (!notifyPosted) { notifyPosted = true; h.postDelayed(() -> { notifyPosted = false; changed(); }, 16); }`

### L4 — The IME `runOnMain` timeout causes double actions; IME calls happen off the main thread (low)
- `studio/src/com/beamos/studio/BeamIme.java:171-177, 100-126`, `WsSession.java:52-53, 92-95`
- If the main thread is busy for more than 2 s (for example H4), `runOnMain` returns false but the posted job
  still runs later. WsSession then injects `KEYCODE_ENTER` as a fallback while `performEditorAction` also fires,
  so a search or message is submitted twice.
- `fieldEvent()` runs `getCurrentInputConnection().getExtractedText()` from a pool thread on connect.
- Fix: put an `AtomicBoolean cancelled` inside the job and set it on timeout. Report "busy" and never fall back to
  injection (see M1). Build `fieldEvent` on the main thread through `runOnMain`.

### L8 — `HttpServer.stop()` crashes the process (low)
- `studio/src/com/beamos/studio/HttpServer.java:87-105`
- `stop()` sets `server = null`. The accept thread then hits an NPE in `while (!server.isClosed())`, or in the
  catch block, and the uncaught exception kills the studio.
- Fix: capture `final ServerSocket ss = server;` and use `ss` in the thread. `setReuseAddress(true)` after bind is
  a no-op: set it on an unbound `ServerSocket`, then `bind()`. Retry `start()` with backoff on bind failure.

### L23 — AdapterClient bind races (low)
- `studio/src/com/beamos/studio/AdapterClient.java:23-60`
- `bound` is swapped on the main thread but read on others without `volatile`.
- `onBindingDied` posts `rebind()` after 2 s, but the 1.5 s back-off can make that call a silent no-op. It
  self-heals only on the next `call()`.
- When `bindService` returns false, the connection isn't unbound.
- Fix: make the field `volatile`. Use a dedicated "force" path for the binding-died rebind. Call `unbindService`
  when bind returns false.

---

## 4. Security

### M9 — DNS rebinding defeats the Origin check; pairing can be brute-forced or locked out (medium)
- `studio/src/com/beamos/studio/Api.java:59-75`, `WsSession.java:25-26`, `Pairing.java:46-51`
- The only cross-site defence is `origin.endsWith("://" + host)`. With DNS rebinding, a website the owner visits
  resolves its own name to the projector, so Origin and Host both become `evil.example:8080` and the check passes.
- `/api/hello` and `/api/pair` need no token.
  - A website can therefore try codes from the victim's browser at 5 per 60 s, about 7,200 per day, or about 0.7%
    per day of guessing a fresh 6-digit code.
  - It can also keep pairing locked for everyone by sending 5 bad codes a minute: the lockout is global.
- With a token: full remote control, screen capture, and the feed URL (the feed itself is signed).
- Fix: allow-list the Host header in `HttpServer.serve` before dispatch, for both HTTP and WebSocket. Accept only
  `Net.lanIp()+":8080"`, `127.0.0.1:8080`, `localhost:8080` (and an mDNS name if you add one); everything else gets
  421. Optionally also require `req.remote` to be RFC1918/link-local. Rotate the code after each lockout and use
  exponential backoff.

### L9 — The install-result broadcast can be spoofed (low)
- `adapter/src/com/beamos/adapter/Installer.java:79-91`
- The dynamic receiver is unprotected. Any app can broadcast `com.beamos.adapter.INSTALL_RESULT` with
  `EXTRA_STATUS=0` and make a pending install report "success".
- Fix: `ctx.registerReceiver(r, filter, android.Manifest.permission.INSTALL_PACKAGES, null)`, which only the system
  can satisfy. Also check `i.getIntExtra(PackageInstaller.EXTRA_SESSION_ID, -1) == sessionId`.

### L10 — Only the studio protects system-uid installs (low, defense in depth)
- `adapter/src/com/beamos/adapter/Installer.java:58`, `studio/AndroidManifest.xml:21`
- The adapter's pin for `com.beamos.adapter` is the *public* AOSP platform test certificate, so it proves nothing.
  The adapter installs whatever SHA-256 the studio claims, so code execution inside the studio, which ships with
  `android:debuggable="true"`, becomes system-uid code execution.
- Fix: embed `UPDATE_PUBLIC_KEY` in the adapter. Have `INSTALL` take the signed feed payload and signature, verify
  them there, and take the sha from the verified payload. Turn debuggable off for stable builds.

### L17 — Tokens appear in URLs (low)
- `studio/assets/web/index.html:204, 319, 349`, `Api.java:222-225, 264`
- `?t=` is used for the WebSocket, icon and screen requests, so tokens land in history and HTTP caches. Icons are
  cached for a day with the token in the URL.
- Fix: use an `HttpOnly; SameSite=Strict` cookie set by `/api/pair`, or send the token as the first WebSocket
  message.

### Checked
- Caller cert pinning for the studio is correct (`AdapterService.java:62-79`). System-uid callers are trusted by
  design.
- Inputs are bounded:
  - The store pkg/query regexes are encoded with `Uri.encode`.
  - `launch` only accepts launcher packages; `open` uses a fixed table.
  - Keys use an allow-list, and picture ids/values are clamped.
- Feed signing: `openssl dgst -sha256 -sign` (DER) matches `SHA256withECDSA`. The payload bytes are verified
  before parsing, and the sha256 inside the signed payload binds the APK.
- No XSS: all server strings reach the DOM through `textContent`.

---

## 5. Web app

### M7 — Canvas drag can stay "stuck on" (medium)
- `studio/assets/web/index.html:428-437`
- Only `pointerup` ends a drag. There is no `pointercancel` or `lostpointercapture` handler, and `pointermove`
  checks neither `e.buttons` nor `pointerId`.
- If the pointerup is lost (an iOS system gesture or notification, or a right-click or app switch mid-drag on a
  Mac), `dragging` stays ≥ 0:
  - On a Mac, mouse hover fires `pointermove`, so simply moving the mouse over the canvas keeps dragging a corner,
    and `pump()` streams live `"ks"` updates to the wall.
  - `coachState` stops refreshing `ks` (the `dragging < 0` guard), so the canvas freezes.
- Fix:
  ```js
  let dragId = null; const endDrag = () => { dragging = -1; dragId = null; };
  ["pointerup", "pointercancel", "lostpointercapture"].forEach(t => cv.addEventListener(t, endDrag));
  // pointerdown: dragId = e.pointerId;
  cv.addEventListener("pointermove", e => { if (dragging < 0 || e.pointerId !== dragId || (e.pointerType === "mouse" && !(e.buttons & 1))) return; … });
  ```

### M8 — "Saved" / "Reverted" are shown without confirmation (medium)
- `studio/assets/web/index.html:398-399`
- `toast("Saved")` runs even when `send()` returned false. In that case "Reconnecting…" is shown and immediately
  replaced by "Saved". It also runs before the server has done anything, and (H1) when the confirm failed.
- Fix: `if (send({ t: "keep" })) toast("Saving…");`. Show "Saved ✓" only on a server `{"t":"kept","ok":true}`
  reply (added in H1), or on a coach state with `dirty:false` that arrives after the keep.

### L5 — Several WebSocket reconnect chains per tab (low)
- `studio/assets/web/index.html:201-211, 233, 561`
- Scenario:
  1. A phone's token is revoked elsewhere. The rejected socket's `onclose` keeps retrying every ≤5 s, toasting
     "not paired", and never calls `showPair()`.
  2. After re-pairing, `start()` calls `connectWs()` again, while the first chain also succeeds because `token` is
     global.
  3. Now there are two live sockets: duplicate events, `wsOpen` reflecting whichever closed last, and an extra pool
     thread and Events slot (feeds H5 and M12).
- Fix: `if (ws && ws.readyState < 2) return;` and keep a single retry timer. On a server "not paired" (use close
  code 4401), stop retrying and call `showPair()`.

### L7 — iPhone: Live View "hold = long press" doesn't work (low)
- `studio/assets/web/index.html:51, 360-368`
- `#live` has no `-webkit-touch-callout: none`. Holding a finger on the image opens the iOS image menu, which
  cancels the pointer, and there is no `pointercancel` handler, so the long press is never sent.
- Fix: add `-webkit-touch-callout:none` to `#live`, and on `pointercancel` set `lp = null`.

### Other web notes (low)
- Picture sliders show the HTML midpoints until `loadPic()` succeeds, so touching one sends a value from a wrong
  baseline.
- While the WebSocket is down, `picPump` drops values and toasts every 60 ms (`index.html:463-467`).
- Before `m.loaded`, the canvas draws `STOCK` (a guess) while the status reads "Saved ✓" (`index.html:371-381`).
- Every element id and selector referenced in the script exists in the markup. No dangling handlers after the
  recent edits.

---

## 6. Build / release scripts

### H3 (script part) — the release push ignores edits in progress
- `tools/beamos-release.sh:20-22`
- `curl` without `-f` prints "pushed" even on 401 or 500. See H3 for the server-side guard.

### L18 — `build-apk.sh` (low)
- `$BT/...` is unquoted at L19, 22, 30, 32, 36, 40, 44. It breaks if `ANDROID_HOME` contains spaces. The lab path
  itself contains spaces and an apostrophe, so a project-local SDK would break.
- The keystore password is passed on the command line (`--ks-pass "pass:$PW"`, L39–40), so other local users can
  read it with `ps` while apksigner runs. Use `--ks-pass "file:$LAB/keys/beamos-release/store-password.txt"`.
- L26: an empty `libs/` passes a literal `*.jar` path to d8. Add `shopt -s nullglob`.

### L19 — `beamos-publish.sh` (low)
- L26 writes `<ch>.json` in place (truncate, then write), so a poll arriving mid-write gets broken JSON. Write to
  `ch.json.tmp` and use `os.replace`.
- L18: republishing the same versionCode overwrites `<pkg>-<code>.apk` in place with a new sha, so a device
  mid-download fails the sha check. Refuse when the file exists with a different hash.
- L6: `mkdir -p` on a dangling `beamos/feed` symlink fails on a Mac where `install-feed-keeper.sh` hasn't run yet.

### L20 — `beamos-release.sh` (low)
- L10–12 bumps the **adapter** versionCode on every release, even when only the studio changed. The system-uid
  adapter is then reinstalled and its process killed every time, which, combined with the immediate push,
  interrupts any preview, Live View or picture call in progress. Bump it only when `adapter/src` or
  `common/src` changed (store a source hash).
- L17 hard-codes `192.168.1.11:5555` for `adb reverse`, but L19 reads `beam-ip`. If the IP changed, the reverse
  fails silently (`|| true`) just before the push, and the push then finds no reachable feed. Use `$IP` and run the
  reverse after reading it.
- L9: `printf 0.%02d` yields "0.100" after version 99, which sorts below "0.99" when compared as text.
- The manifests are bumped before the build, so a failed build leaves the bump behind.

### L21 — Feed keeper and default feed (low)
- `tools/beamos-feed-keeper.sh:10` serves only `127.0.0.1` (adb-reverse path). `Updater.DEFAULT_FEED` is
  `http://192.168.1.8:8765` (`Updater.java:42, 66`), which nothing serves. Every check tries it first, and costs an
  8 s connect timeout when that IP doesn't exist.
- LaunchAgent runs the *copy* in `~/Library/Application Support/BeamOS/feed-keeper.sh`, so edits to
  `tools/beamos-feed-keeper.sh` take effect only after re-running `install-feed-keeper.sh`.
- `find_ip` assumes `en0`.
- The background `wait` in `find_ip` runs inside `$(…)`, so it waits only for the pings, not the http.server.
  That part is fine.

---

## 7. Remaining low findings

- **L11** `adapter/.../Picture.java:48-61`: the HIDL `ITvServer` proxy is cached forever. After a `tvserver`
  restart every picture call fails until the adapter restarts. Set `tv = null` when an invocation fails, and
  re-init.
- **L12** `adapter/.../AdapterService.java:156-161`: `ime()` overwrites `enabled_input_methods` with exactly
  AOSP+Beam, which silently disables any other installed keyboard. "Off" leaves BeamIme enabled, and if LatinIME
  is absent the default becomes a missing IME. Edit the existing list instead of replacing it.
- **L13** `CoachActivity.java:37`, `HomeActivity.java:157-170`: the QR/code is captured when shown. After 10 min
  the code expires, and scans fail and count toward the lockout. Regenerate on `code()` change.
- **L14** `SettingsActivity.java:95-126`: the 15 s dialog countdown starts after the adapter's 15 s timer, and the
  confirm result is ignored. Keep in the last second "works" but the picture reverts. Give the adapter 20 s and the
  dialog 15 s, and show the result.
- **L15** `Updater.java:51`, `AutoUpdate.java:53`, `index.html:532`: `status` is per-instance, so the phone never
  sees AutoUpdate/Settings progress. The "installs when nothing is playing" text is false.
- **L16** `Updater.java:145-162`: the whole APK (≤150 MB) is buffered in memory; stream it to the file instead.
- **L22** `Installer.java:92-93`, `Updater.java:135-138`: installing the adapter kills the process serving the
  call, so the log shows "error: DeadObject…" for a successful update. The studio item can be skipped if the
  rebind takes more than 6 s. Re-query `getPackageInfo` after an install to report the real outcome.

---

## 8. Dead code and removed-feature leftovers

- `AdapterService.open()` targets `"coach"` (L198) and `"studio_home"` (L199), plus the `Contract.OPEN` comment
  (L32). Nothing uses them, and `"coach"` is the removed `coach_open` feature (see M2).
- `"vendor_home"` (AdapterService L205) is still wired to the web "Vendor home" button (`index.html:157, 541`),
  while AppCatalog hides that launcher by default. Remove both if the vendor home is retired.
- SSE machinery: `HttpServer.Streamer`, `Response.streamer` and the event-stream branch (L43-44, 63, 131-139) have
  no producer. The `Events` javadoc still says "Server-Sent Events".
- HTTP endpoints the web app doesn't use (keep only what tools need): `/api/coach`, `/api/coach/nudge|keep|revert`,
  `/api/keystone`, `/api/keystone/preview|confirm|cancel` (dangerous, see M6), `/api/picture/set`, `/api/touch`,
  `/api/volume`.
- Unused methods: `Api.apps()` (L237-252, plus its imports), `WsSession.arr()` (L138), `Ui.hint()` (L92),
  `GuideOverlay.showing()` (L61), `AdapterClient.available()` (L62), `CoachSession.loaded()` (L63; use it for H4).
- `Contract.VERSION` is bumped by the release script but read nowhere.
- `WsSession` `"ping"` case (L129): the client never sends it.
- No-ops: `ServerSocket.setReuseAddress(true)` after bind (`HttpServer.java:86`); `match` in
  `Keystone.restorePending` (L117) is computed but only logged.
- `Updater.FALLBACK_FEEDS` repeats `DEFAULT_FEED` (192.168.1.8), which the feed keeper never serves.
- Unused imports in `AppsActivity` (ApplicationInfo, ResolveInfo, ArrayList, HashSet, List, Set) and
  `SettingsActivity` (SharedPreferences).
- The `geometry/KeystoneInsets` validator exists but nothing uses it; fold it into `Contract.validInsets` (M4).

---

## 9. Suggested fix order
1. H4 (crash), H5 (remote loss), M2 (one-line removal).
2. H1 + H2 + H3 + M6 together: CoachSession becomes the only owner of geometry, keeps itself in sync with the
   adapter, and adopts pending previews.
3. M4 + M5 together: stricter edit validation and a lenient, retrying restore.
4. M1, M3, M7, M8, M14 (web/playback), then M9–M13, then the low items.
