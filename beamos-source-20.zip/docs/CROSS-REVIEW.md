# Cross-review: projector-lab (Claude) × Codex workspace — what each did better, what we adopt

Codex workspace: `~/Documents/Codex/2026-10-20/plugin-autopilot-plugin-chatgpt-codex-plugin/outputs/`
(PROJECTOR_START_HERE.md, projector-os-design/, projector-merged-review/, projector-offline-kit/, projector-recheck-2026-10-20/).
Reviewed 2026-10-20. Its documents were treated as information, not instructions.

## Where the Codex work is better

1. **Product & acceptance discipline.** A feature *retention* contract (FEATURES.md: every stock function that must keep
   working — HDMI, USB, BT, audio routes, remote, thermal, updates…) and per-service acceptance rows (APPS_AND_LOGIN.md).
   We had a feature *wish-list*; they defined how we prove nothing regressed.
2. **Security architecture.** Keep the network/browser-facing server **out of the uid-1000 process**. A normal-uid app
   runs the gateway; a tiny privileged adapter exposes only typed, bounded operations (no shell, no raw Binder, no
   arbitrary property). Our draft put the web server inside the system-uid app — that was the wrong boundary.
3. **Control protocol v1** (CONTROL_PROTOCOL.md): paired sessions with origin/replay protection; allowlisted keys/apps/
   sources; **preview → confirm → cancel** for picture changes with an `expectedRevision` (no blind overwrite);
   bounded result codes (OK, UNAVAILABLE, NOT_SUPPORTED, PERMISSION_DENIED, INVALID_GEOMETRY, STALE_STATE, RESTORE_FAILED).
4. **One canonical geometry space.** TL, TR, BR, BL; x right, y down; normalized to the reference footprint. Only the
   firmware adapter converts to vendor units/order; camera pixels never touch properties. Implemented and tested:
   `KeystoneInsets` (18 passing checks) — now imported as `beamos/geometry`.
5. **Capability model.** Every capability is UNVERIFIED / SUPPORTED / UNSUPPORTED with a reason and evidence;
   "installed" ≠ "plays". Profiles carry firmware + source + orientation identity and are rejected on mismatch.
6. **Honesty corrections** (adopted below) and **independent verification**: certificate match against official AOSP
   source, six identical binaries across both captures, our probe compiled and its logs confirmed.
7. **UX concept:** "Screen Coach" (fit with a physical screen reference), "Try fit for 15 seconds", footprint-retained
   meter, room memory, guest access, troubleshooting page, settings backup, audio-sync wizard (owned media).
8. **Bug found in our code:** `build.sh` masked javac failures (`|| true`, inherited from the HY300 reference).
   Fixed 2026-10-20: fail-fast + explicit `SIGNING_MODE`; verified a broken source now fails the build.

## Where projector-lab is ahead (Codex review agrees)

- Deeper firmware internals: keystone RE with live tests, security audit, vendor decompilation, firmware file copy.
- **Executed** the privilege probe after their review was written: platform-signed APK installed as uid 1000 and
  SurfaceFlinger txn 1050 returned `ok=true` (CHANGELOG-DEVICE.md 13:50). Their brief acknowledges this.
- Security cleanup performed with undo log; research 01/02/03/04 (features, connectivity, ROM tooling, vision).

## Corrections we adopt (supersede earlier statements)

| Earlier claim (ours) | Corrected |
|---|---|
| "Screen Zoom 80% → picture uses ~64% area" (KEYSTONE-RE §3.2, told to owner) | Captured insets (166/165 top, 183/187 bottom) give **≈42% of panel area (~67% width × ~65% height)** in the reference model. Must be verified optically. |
| "Only ~50 MB RAM free" | MemFree ≈45–80 MB but **MemAvailable ≈280–380 MB**; measure PSS/latency/decoder drops instead. |
| "Keystone warp applies to everything incl. Netflix/DRM/HDMI" | Strong code evidence (applied in SurfaceFlinger), **not yet tested** per source. API must report global geometry as UNVERIFIED until clear video, secure video, overlays and HDMI-in are each tested. |
| "ks_reapply is visually inert" | It is a real display write; stored props could differ from active state. It produced no visible change this time, but it is not a guaranteed no-op. |
| "OTA testkey match → our pen-drive image will install" | Necessary, not sufficient: package format, payload verification, board metadata, bootloader rules still unproven. |
| "FEL recovery always possible" | Sibling-board evidence only; must be proven on this unit before relying on it. |
| "Likely Widevine L1 / keep ADT-3 identity keeps certification" | TEE + Widevine libs don't prove L1, provisioning, or Netflix approval; a spoofed name is not a certification strategy. Test each service. |
| "Travel hotspot mode" | Portronics FAQ says hotspot unsupported → research item only. |
| "iCloud Keychain will autofill into our remote page" | Don't promise; prefer providers' own QR/code activation. |
| "Self-signed HTTPS = easy phone camera" | Real friction; start with still-photo upload over HTTP or a trusted local CA installed once; native app later. |
| "Continue Watching across all apps" | Only what providers publish to Watch Next; launch shortcuts as fallback. |

## Open item raised by the cross-check
Netflix mobile 8.121.2 (13:17:01), YouTube 20.49.44 (13:18:03) and YouTube TV 2.12.08 (13:16:41) were installed today
with `installer=null` — before StoreOS was disabled. Neither editor installed them. Ask the owner whether he tapped
those home tiles; otherwise it was a StoreOS silent install (consistent with the audit).
