# Home you own (BeamOS 0.13)

What research/08 F2, F4, F5 asked for, scoped to what a launcher (not the system) can honestly do without an Accessibility service.

## Favourites row (F2)

- `AppCatalog.favourites()` — ordered package list in prefs `apps/favs` (comma-joined; a StringSet would lose the order).
- Home "Watch" row = favourites in the owner's order; while empty, BeamOS keeps auto-picking the installed streaming apps (unchanged behaviour).
- Phone → Apps: ☆ on any tile adds it to the row; the "Your Watch row" card reorders (◀ ▶) and removes (✕). Hidden apps are never shown even if starred.
- Projector: **hold OK** on a Watch tile → Move left / Move right / Remove / Hide. "Add" from a non-favourite first freezes the current auto row as favourites so nothing disappears.
- API: `GET /api/apps` adds `fav` per app and `favs` (order); `POST /api/apps/fav {pkg,on}`, `/api/apps/fav/move {pkg,dir}`, `/api/apps/favs {order:[…]}`.

## Remote-key gestures on the home screen (F4)

| Gesture | Does | How |
|---|---|---|
| HOME twice (< 0.7 s) | All apps | HomeActivity is singleTask: HOME while on home → `onNewIntent`; two within 700 ms. |
| Hold BACK | Screensaver | `onKeyDown` tracks, `onKeyLongPress` → adapter `SCREENSAVER{start:true}` → `IDreamManager.dream()` (uid 1000, platform-signed, hidden-API allowed). Starts whichever screensaver is selected (BeamOS or vendor). |
| Hold OK on a Watch tile | Tile menu | `setOnLongClickListener` on the tile. |

Only the home screen sees these (an app in front gets its own keys — nothing BeamOS does intercepts keys globally, by design: no Accessibility service, no interference with playback). The phone remote already covers long-press (`long:true`) on every key.

## Shortcut tiles (F5)

Bluetooth (vendor BT settings via adapter `OPEN bluetooth`), Mapping (opens the last mapping scene full-screen — explicit tap on the projector), Screensaver (start now). HDMI, Mirror, Screen Coach, Phone Remote, Settings were already there. Tiles live in a horizontal scroller, so more fit without shrinking.

`POST /api/screensaver/start` from the phone: 409 while something is playing unless `confirm:true` (same rule as every interrupting action).

## Not done (and why)

- Per-key configurable tap/double/long mappings in Settings: would need a global key hook (Accessibility service or ROM) — left for the ROM milestone.
- HDMI 1/2/3 as separate tiles: the Beem 470 exposes one HDMI input (`OPEN hdmi`).
- Mesh / curved auto-map: Mapping Studio v2 (see MAPPING-STUDIO.md).
