# Installing BeamOS and updating it forever

Goal (owner, 2026-10-20): install our OS now, then keep sending updates directly to it without big changes,
with multiple versions (channels), and add features (phone "eyes", Arduino later) over time.

## Key design: "install once, update forever" — the same packages in every stage

BeamOS = a fixed set of packages that never change name or signing key:

| Package | Runs as | Signed with | Role |
|---|---|---|---|
| `com.beamos.adapter` | system uid 1000 | AOSP platform key (public — matches this firmware) | tiny privileged service: keystone, picture, inputs, key/text injection, **silent installer for BeamOS updates** |
| `com.beamos.studio` | normal uid | **our own BeamOS release key** (generated once, backed up 3×) | launcher/home, phone+Mac gateway, Screen Coach, settings, update UI |
| later: `com.beamos.airplay`, `com.beamos.mapping`, … | normal uid | BeamOS release key | optional modules |

Because names and keys never change, every stage below updates the same apps in place — no reinstall, settings kept.

## Three ways to install (practical, in order)

### Stage 1 — Install over Wi-Fi from the Mac (now; nothing flashed; fully reversible)
1. Projector on Wi-Fi with network debugging on (already).
2. On the Mac: `tools/beamos-install.sh 192.168.1.11` → installs adapter + studio, sets BeamOS as Home,
   grants its permissions, verifies it started. Takes ~1 minute.
3. Vendor launcher stays installed (disabled only after BeamOS has been stable for some days).
- Undo everything: `tools/beamos-uninstall.sh` (or `adb uninstall com.beamos.studio com.beamos.adapter`).
- Limitation: our apps live in /data, so a factory reset removes them (re-run the script). That's what Stage 3 fixes.

### Stage 2 — Updates without the cable or commands (from v0.2 on)
- The adapter (system uid) contains **BeamOS Update**: it reads a signed update feed, downloads the APK, checks
  SHA-256 + our Ed25519 signature, installs silently (system uid holds INSTALL_PACKAGES), then health-checks.
- Feed hosts: the Mac on the same Wi-Fi (dev, instant) → later GitHub Releases or any HTTPS host (anywhere).
- **Channels**: `stable`, `beta`, `dev`. Switch from the phone app. Each release has notes + minimum firmware check.
- **Rollback**: Android blocks downgrades on this user build, so "go back" = re-publish the previous code with a higher
  versionCode (the Mac build script does this in one command). The update UI shows history.
- **Offline / pen drive**: drop `beamos-update-<ver>.zip` (APKs + signed manifest) on a USB stick; BeamOS Update offers
  to install it when the stick is plugged in. Same verification as online.

### Stage 3 — BeamOS ROM via pen drive (later; only with a verified full backup)
- Prereqs: USB A-to-A cable, Linux VM (UTM), FEL full dump (3 copies), proven restore (research/03).
- The ROM bakes the same packages into /system as priv-apps (survive factory reset), removes vendor bloat/spyware at
  the image level, adds our root helper; image timestamp > 20250530; slot `_a` only.
- After flashing, **the same BeamOS Update keeps working**: Android treats newer APKs as updates of the built-in apps.
  Only deep system changes ever need another pen-drive image.

## What "v0.1 — best version right now" contains
- Home screen: big remote-friendly tiles (apps, inputs, Screen Coach, Share, Settings), live clock, quick status.
- Phone/Mac control page (pair by QR → token): remote d-pad, OK/back/home, volume, iPhone-keyboard typing,
  app launcher, input switch.
- Screen Coach v1: manual 4-corner drag from the phone with **preview → confirm (15 s auto-revert)**; reset; the
  photo-based sideways correction from tools/fit_from_photo.py as "Fit from photo" (phone uploads a still photo).
- Picture basics: screen zoom 100%, projection mode, auto-keystone on/off (all with undo).
- BeamOS Update client (Stage 2) built in from the first version.

## Phone as "eyes" (planned modules)
v0.2 Fit-from-photo (still photo upload) · v0.3 live camera calibration (HTTPS, local CA) · Focus Coach ·
re-fit after bump (tilt change detected → phone prompt) · wall-colour adaptation · later native iOS app (LiDAR),
USB webcam on the projector for fully automatic correction, Arduino/ESP32 (IR power-on, sensors).
