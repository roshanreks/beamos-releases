# Keystone / projection geometry reverse-engineering — Portronics Beem 470 (Hotack `UI_Veng.projector`, Allwinner H713)

Static analysis + read-only ADB only. No setting was changed on the device while producing this.
Device confirmed: Android 11 (API 30), 32-bit armeabi-v7a, SoC `sun50iw12p1` (Allwinner H713),
framebuffer 1920x1080, SELinux **Permissive**, adb shell = `uid=2000(shell) … context=u:r:shell:s0`,
groups include `3011(uhid)` and `1004(input)`. `ro.adb.secure=1`, not rooted. `getprop ro.build` reports
model `ADT_3 / adt3` (AOSP reference), `persist.sys.prj_device_name=HY320`.

Sources used (all under `projector-lab/`):
- `decompiled/com.htc.htcsettings/sources/com/htc/util/k.java` — the keystone/zoom math + SurfaceFlinger call.
- `decompiled/com.htc.htcsettings/sources/com/htc/activity/{CorrectionActivity,CorrectionIndexActivity,CorrectionDefaultActivity,KeystonecorrectionActivity,ScreenZoomActivity,ProjectionModeActivity,ProjectionActivity4,PictureModeActivity}.java`
- `decompiled/com.hysd.vafocus/sources/com/hysd/vafocus/{LocalService,PropertiesUtils,TpCorrectUtils,GsensorUtils,CamTpUtils}.java`
- `/system/lib/libsurfaceflinger.so`, `/system/lib/libkeystone.so`, `/system/framework/services.jar` pulled live (scratchpad), `strings`/`objdump`.
- `firmware-files/` (vendor, odm, product, oem) + `recon/20261020-1252/` snapshot.
- `reference/hy300-keystone/` — sister project on the same SoC/firmware family (ControlCenter `com.cptp.console`), proven working.

---

## 0. TL;DR — recommended apply path

**The one and only thing that warps the picture for all apps (Netflix included) is a single custom
SurfaceFlinger binder transaction, code `1050`, on interface token `android.ui.ISurfaceComposer`,
carrying 8 floats = 4 corner inset fractions in order `LB, LT, RT, RB` (each `x` then `y`, range 0.0–0.5).**
SurfaceFlinger turns those into a GL warp matrix (`getKeyStoneMatrix` in `libkeystone.so`) applied to the
final composited 1920x1080 framebuffer — below WindowManager — so every app and the DRM video path is warped.

Transaction `1050` is inside SurfaceFlinger's "backdoor" switch, which is gated to
`uid == AID_SYSTEM (1000)` **or** holder of `android.permission.HARDWARE_TEST`. **adb shell (uid 2000) and a
normal third-party app do NOT hold it → `service call SurfaceFlinger 1050` returns `PERMISSION_DENIED`**
(confidence: high; identical SoC/SF to HY300 where this is proven; verify live — see §6).

So our code cannot call `1050` directly. The reliable mechanism (proven on the sister HY300) is:

1. Disable the auto keystone so it stops overwriting us: `persist.sys.tpryauto=0`, `persist.sys.tpryxcrt=0`.
2. Write the 8 target corners into `persist.display.keystone_{ltx,lty,rtx,rty,lbx,lby,rbx,rby}`
   (per-mille, 0..500; `0`=corner at full-frame position, `500`=50% inward).
3. Make the system-uid Settings app (`com.htc.htcsettings`, uid 1000) read those props and push them to SF:
   `am start -n com.htc.htcsettings/.CorrectionActivity`, then inject one D-pad nudge that nets to zero on the
   selected corner. `CorrectionActivity.onCreate → util.k.u()` loads all 8 props into memory; the nudge calls
   `util.k.C()→E()` which runs transaction `1050` with all 8 values. Then BACK to save/exit.
4. The app that runs steps 1–3 is an `app_process` helper started as `shell` through the projector's own adb
   on `127.0.0.1:5555` (exactly the HY300 model), because a normal app can neither start the non-exported
   `CorrectionActivity` nor inject input.

Confidence the warp mechanism is transaction 1050 with these 8 floats: **very high** (three independent
decompiled call sites + matching SurfaceFlinger strings). Confidence that the shell→UI-nudge apply works on
*this* firmware: **high** (same SF binary family as HY300; `CorrectionActivity` logic confirmed to load from
props and push on nudge). Live checklist in §6.

---

## 1. Full chain: from CorrectionActivity / auto-keystone to the panel

### 1.1 The real apply primitive — SurfaceFlinger transaction 1050

`com/htc/util/k.java` method `E()` (and `F(boolean)`), and independently
`com/hysd/vafocus/TpCorrectUtils.java androidN_tp_correct(...)`, all do the same thing:

```java
// com/htc/util/k.java  E()   (static fields are the 8 live corner values, per-mille)
IBinder l = ServiceManager.getService("SurfaceFlinger");
Parcel p = Parcel.obtain();
p.writeInterfaceToken("android.ui.ISurfaceComposer");
p.writeFloat(f1656d*0.001f); // LB x   (persist.display.keystone_lbx)
p.writeFloat(e      *0.001f); // LB y   (keystone_lby)
p.writeFloat(h      *0.001f); // LT x   (keystone_ltx)
p.writeFloat(i      *0.001f); // LT y   (keystone_lty)
p.writeFloat(j      *0.001f); // RT x   (keystone_rtx)
p.writeFloat(k      *0.001f); // RT y   (keystone_rty)
p.writeFloat(f      *0.001f); // RB x   (keystone_rbx)
p.writeFloat(g      *0.001f); // RB y   (keystone_rby)
l.transact(1050, p, null, 0); // reply=null, flags=0  (not oneway)
```

`com/hysd/vafocus/TpCorrectUtils.java` writes the same 8 floats in the same order (LB,LT,RT,RB), but scaled
as `pixel/1920` or `pixel/1080` instead of `permille*0.001` — mathematically identical normalized 0..1 fractions.

- **Interface descriptor:** `android.ui.ISurfaceComposer`
- **Transaction code:** `1050` (decimal) = `0x41A`
- **Payload:** 8 × `float32` (little-endian), order `LBx,LBy,LTx,LTy,RTx,RTy,RBx,RBy`, each in `[0.0, 0.5]`.
- **reply:** none; **flags:** 0.

### 1.2 What SurfaceFlinger does with it

`/system/lib/libsurfaceflinger.so` (pulled live) confirms the vendor warp:
- Imports `_Z17getKeyStoneMatrixPf` (`getKeyStoneMatrix(float*)`) from **`libkeystone.so`** (`/system/lib/libkeystone.so`, 18 KB).
- Compiled-in prop names `persist.display.keystone_{ltx,lty,rtx,rty,lbx,lby,rbx,rby}` and a flag
  `persist.sys.keystone_vaf` (log string `"SF read persist.sys.keystone_vafaa"`).
- `libkeystone.so` exports a GL pipeline: `createKeystoneShader`, `getKeyStoneMatrix`, `render_frame(uint,float*)`,
  `saveKeystonePara(float*,int,int)`, `rgba2yuv`, `draw_edge(int,int)`, globals `gKeyStoneMatrix`,
  `gKeyStoneVertice`, `gFbWidth/gFbHeight`, `gEdgeStart`. It builds a 4-point perspective (keystone) matrix
  from the 8 corner fractions and warps the composited framebuffer texture, with an edge feather
  (`draw_edge`, controlled by `persist.display.keystone.alias.{enable,edge,scale}`).

Because this is done in SF's GL composition on the whole output surface, it affects **every** layer/app
including protected/DRM (Netflix). Confirmed by `dumpsys display`/`SurfaceFlinger`: WindowManager/DisplayManager
see a clean identity 1920x1080 (`logicalFrame=physicalFrame=Rect(0,0-1920,1080)`, `rotation 0`) — the warp is
invisible above SF, i.e. it lives only in SF's final draw.

### 1.3 Property families observed (what each one is)

From `recon/.../getprop.txt`:

| Prop(s) | Meaning | Written by | Read by |
|---|---|---|---|
| `persist.display.keystone_{ltx,lty,rtx,rty,lbx,lby,rbx,rby}` = 166,165,166,165,183,187,183,187 | **The authoritative SF warp inputs**, per-mille inset 0..500 (0 = full-frame corner) | htcsettings `k` | SurfaceFlinger (strings) + htcsettings `k.E/u` |
| `persist.htc.keystone.*` (same 8) | Backup/record of auto/4-corner result, per-mille | vafocus `PropertiesUtils.efect_tp_correct(…,i2==1)`; htcsettings `k.i/k/h/j` for zoom recompute | htcsettings zoom math |
| `persist.sys.keystone.{lt,rt,lb,rb}` = "x,y" pixel pairs (e.g. lt=319,901) and identical `persist.hisi.keystone.*`, plus `.update=true` | The system_server auto-keystone's own record in **absolute pixels** (`0.166*1920≈319` for x; y is bottom-origin GL, `901≈1080-179`). `hisi.` is cloned naming, same values. `.update=true` is its reload flag. | system_server keystone manager (services.jar) + `KeystonecorrectionActivity` panel path | system_server |
| `persist.sys.zoom.value` = 167,166,167,167,167,167,167,166 | htcsettings backup of the 8 warp values for the Screen-Zoom feature (`k.F(false)`) | htcsettings `k.F` | htcsettings |
| `persist.vendor.overscan.main` = `overscan 80,80,80,80` | Screen-Zoom percentages per edge; 100=full, 80=shrunk. **This 80% is the cause of the ~65% usage** (see §3). | htcsettings `k.D` | htcsettings `k` + possibly disp HAL (`setOverScan`) |
| `persist.sys.keystoneAngle` = -9 | current auto vertical-tilt correction angle (deg) | system_server auto-keystone | system_server |
| `persist.sys.tpryauto`=1 | auto (sensor) vertical keystone ON | htcsettings `k.A/B`, vafocus | system_server, vafocus |
| `persist.sys.tpryxcrt`=0 | auto 4-corner (camera) keystone ON/OFF | htcsettings `CorrectionIndexActivity.I` | vafocus `calib_begin` |
| `persist.sys.vafocus`=0 | autofocus ON/OFF | htcsettings `CorrectionIndexActivity.G` | vafocus |
| `persist.sys.camok`=0 | a camera was detected (0 = no camera on this unit) | vafocus `onStartCommand` | htcsettings, vafocus |
| `persist.sys.focusupdn`=1 | up/down-only focus/keystone variant | factory | htcsettings, vafocus |
| `persist.sys.prj.keystone`, `persist.sys.prj.manualkeystone` | **optical/panel** keystone via an MCU on i2c (`/sys/devices/ff140000.i2c/i2c-2/2-001b/{panel_keystone_enbale,manual_Keystone_mode}`). Different, lens-side mechanism; present in `KeystonecorrectionActivity` but that screen is not in the normal menu on this unit. | `KeystonecorrectionActivity` | kernel i2c driver |

### 1.4 Auto keystone (sensor path) lives in system_server

`/system/framework/services.jar` (pulled live) contains the vendor auto-keystone (strings:
`persist.sys.keystoneAngle`, `persist.sys.keystone_new`, `android.intent.hotack_keystone`,
`"auto-keystone is on, focus delay"`, `"angle changed, need keystone and focus"`, reads
`/sys/devices/platform/prj343x/xyz_data` (g-sensor), `/sys/devices/platform/prj343x/sensor_report`).
With `camok=0` (no camera on this unit) the auto keystone is the **g-sensor vertical-tilt** one: system_server
reads the tilt, computes corner insets, stores them in `persist.sys.keystone.*`/`persist.hisi.keystone.*`
(+`.update=true`) and `persist.sys.keystoneAngle`, and applies via the SurfaceFlinger `1050` path.
It is the component that will **fight** our values if left enabled — it re-applies on boot and on tilt change
and after the `android.intent.hotack_keystone` / `com.htc.auto_keystone` broadcasts.

### 1.5 Reload triggers (how an apply is kicked)

- **Primary, synchronous:** calling transaction `1050` itself (does the warp immediately). Writing the props
  alone does **not** warp — SF reads them at init; live changes need the `1050` call.
- **`persist.sys.keystone.update=true` / `persist.hisi.keystone.update=true`:** the system_server auto-keystone's
  own "re-read my pixel-coords record and re-apply" flag. Not a general-purpose hook for arbitrary corners (it
  reads `persist.sys.keystone.*`, its own representation, and is tied to the sensor logic).
- **Broadcasts** (sent by htcsettings `k.y/k.z`, received by system_server / vafocus; these recompute from
  **sensor/camera**, not from arbitrary props, so they are NOT a way to set arbitrary corners):
  - `com.htc.auto_keystone` (`k.y`)
  - `android.intent.hotack_keystone` (`k.z`, extra `ratio=1`)
  - `android.intent.projective_mode` (`ProjectionModeActivity.x`) — front/rear/ceiling changed
  - `keystone.set.floatview` (seen live in logcat, received by SystemUI `PowerUI.Notification`) — shows the
    on-screen keystone overlay float view; cosmetic.

---

## 2. Who is allowed to apply, and the cheapest reliable path

### 2.1 Permission facts

- **`setprop persist.display.keystone_*` from shell:** works. SELinux is **Permissive** (confirmed live:
  `getenforce` → `Permissive`), so property-set SELinux ownership is not enforced; and these props are in the
  default `persist.*`/`system_prop` contexts (not restricted in `vendor_property_contexts`). HY300 (same base)
  confirms shell writes these. (This is a WRITE — not performed here; command in §6.)
- **`service call SurfaceFlinger 1050` from shell:** expected **PERMISSION_DENIED**. SurfaceFlinger's
  `onTransact` backdoor block (codes ≥1000, which is where the OEM added `1050`) is gated by
  `uid==AID_SYSTEM(1000) || PermissionCache::checkPermission(android.permission.HARDWARE_TEST)`.
  `libsurfaceflinger.so` contains exactly these strings: `android.permission.HARDWARE_TEST`,
  `"Permission Denial: can't access SurfaceFlinger pid=%d, uid=%d"`, `PermissionCache::checkPermission`.
  Shell (uid 2000) is not AID_SYSTEM and is not granted HARDWARE_TEST. The sister HY300 project states the same:
  *"Shell can write persist.display.keystone_* but cannot call SurfaceFlinger transaction 1050 (EPERM)."*
  Confidence high; a one-shot live test is cheap and worthwhile (§6) in case this OEM moved `1050` outside the gate.
- **Starting `CorrectionActivity`:** it is **not exported** (`<activity android:name=".CorrectionActivity"/>`,
  no `exported`, no intent-filter). A third-party app cannot launch it. **adb shell CAN** (`am start` from shell
  is allowed to start non-exported activities). `CorrectionIndexActivity` and `CorrectionDefaultActivity` ARE
  `exported="true"`.
- **Injecting key/touch events:** needs system/shell. Shell (via `InputManager.injectInputEvent` reflection from
  an `app_process` process, or `input keyevent`) can. A third-party app cannot inject into other apps.
- **Our own third-party app:** runs as its own uid (not 1000). It can neither call `1050`, nor start
  `CorrectionActivity`, nor inject input. It therefore must delegate to a shell-privileged helper.

### 2.2 Cheapest reliable mechanism (recommended)

Mirror the HY300 helper exactly (`reference/hy300-keystone/helper/src/com/hy300/keystone/Helper.java`),
retargeted to this firmware's Settings app:

1. App starts a helper as **shell** via the device's own adb loopback:
   `CLASSPATH=/data/local/tmp/ks-helper.dex app_process /system/bin com.yourpkg.Helper` over `adb 127.0.0.1:5555`.
2. Helper, per apply:
   - (once) `SystemProperties.set("persist.sys.tpryauto","0")`, `("persist.sys.tpryxcrt","0")` to stop auto keystone.
   - `SystemProperties.set("persist.display.keystone_ltx", …)` … all 8 (per-mille 0..500).
   - `am start -W -f 0x10008000 -n com.htc.htcsettings/.CorrectionActivity`
     (`NEW_TASK|CLEAR_TASK`; shell can start this non-exported activity). Wait until it is the resumed activity.
   - `CorrectionActivity` opens with the **LT (top-left)** corner checkbox selected
     (`check_lt` set true in `r()`); `k.u()` has just loaded all 8 props into memory.
   - Inject a net-zero nudge on LT: e.g. `KEYCODE_DPAD_RIGHT` then `KEYCODE_DPAD_LEFT` (or any arrow and its
     opposite). Each `onKeyDown` → `D(keyCode, …)` → `util.k.C(1, xy)` → `util.k.E()` → **transaction 1050 with
     all 8 current props**. Two opposite presses leave the stored value unchanged while still pushing.
   - Exit: `KEYCODE_BACK`. (Unlike HY300's ControlCenter, this screen has no "save?" dialog in the decompiled
     flow — BACK just returns; values already live + persisted in props. Verify live.)
3. To read current values: `getprop persist.display.keystone_*` (read-only, no privilege needed).

Key-event accelerator note: `CorrectionActivity.onKeyDown` increments step size `B` from 1→8 on held repeats,
and `D()` uses it as the delta. For a net-zero nudge, send two single DOWN/UP presses (repeatCount 0) in
opposite directions so each uses delta 1.

Alternative (simpler if the live test passes): if `service call SurfaceFlinger 1050 f <8 floats>` is **not**
denied on this unit, the helper can call it directly and skip the UI entirely. Test first (§6).

Why not go through vafocus or a system binder instead: `com.hysd.vafocus` (uid 1000, `sharedUserId=android.uid.system`)
only exposes `LocalService` (exported) whose `LocalBinder` returns the service for in-process binding — no AIDL
to set arbitrary corners from another process; it recomputes from camera/sensor, not arbitrary props. No exported
component in any uid-1000 app accepts 4-corner coordinates via Intent. So the prop + UI-nudge path is the route.

---

## 3. Value ranges, the ~65% shrink, reset-to-full, disabling auto

### 3.1 Ranges / encoding (`persist.display.keystone_*`)

- Per-mille integers. **0 = corner at full-frame position; larger = corner pulled inward.** Max per axis is
  **500** (= 50% inward), clamped in `util.k.C()` (`if (x<0) x=0; if (other+x>500) x=500-other;` — a corner plus
  its paired cross-corner cannot exceed 500). The float sent to SF is `value/1000` → range `[0.0, 0.5]`.
- This is the "direct" sense (0 = none), **not** HY300's inverted 750..1000 sense. Simpler for us.
- Per-corner x/y and sign of each `persist.display.keystone_*`: LT/LB/RT/RB each get an x-inset and y-inset.
  The exact direction each one moves its corner on *this* optics/orientation should be measured with a one-shot
  live probe during calibration (HY300 does this: nudge each and watch the camera), because projection mode
  (front/rear/ceiling, `persist.sys.panelvalue`) flips axes. Baseline interpretation from the code: increasing
  `ltx`→LT moves right/inward, `lty`→LT moves down/inward, and analogously inward for the other corners.

### 3.2 Why the picture only uses ~65% — it's the Screen-Zoom (overscan), NOT keystone

`ScreenZoomActivity` drives `util.k.D(ctx, 80, i,i,i,i)` with slider `i∈0..20`; `k.D` sets
`persist.vendor.overscan.main = "overscan (i+80),(i+80),(i+80),(i+80)"` → range **80..100**. The device is
currently at **`overscan 80,80,80,80` = 80% per axis → 0.8×0.8 = 64% of the panel area** ≈ the ~65% the user sees.

Crucially, on this unit (`camok=0`, auto path) `k.D → k.c()` *implements that zoom through the same keystone
warp*: with overscan 80 it computes `persist.display.keystone_ltx = ((100-80)*16*1000)/1920 = 166` (matches the
live `ltx=166`), and similarly ~165/183/187 for the others, then calls `F(true)`→transaction 1050. So the
current non-zero `keystone_*` values are the **Screen-Zoom shrink**, not a manual keystone. (The slight top/bottom
asymmetry 166 vs 183 comes from the zoom formula's different top/bottom terms, possibly combined with the −9°
auto tilt.)

So "zoom / screen size" and "keystone" are the **same warp primitive** here; there is no separate scaler.

### 3.3 Reset to full frame (exact)

To get a full, rectangular, 100%-area image (then let the phone-camera calibration pull corners in as needed):

- `persist.display.keystone_ltx=0 lty=0 rtx=0 rty=0 lbx=0 lby=0 rbx=0 rby=0`  → transaction floats all 0.0.
  (`util.k.x()` is exactly this: sets all 8 to 0 then `E()`.)
- Screen-Zoom to max/full: slider 20 → `persist.vendor.overscan.main = overscan 100,100,100,100`, and the
  Global setting `zoom_value=0` (full). Note: `CorrectionActivity`'s hidden "hold OK ×10" reset (guarded by
  `persist.sys.hideok=1`) calls `k.x()` AND sets Global `zoom_value=20`.
- Then push via the §2.2 nudge so SF applies the zeros.

Full-frame baseline for the transaction = **8 zeros**.

### 3.4 Disable auto keystone so it does not fight us

- `persist.sys.tpryauto=0` — turn off sensor vertical keystone (currently `1`). Mirror of the Settings toggle
  (`util.k.A/B`, and `CorrectionIndexActivity`). With it off, system_server stops recomputing from tilt.
- `persist.sys.tpryxcrt=0` — auto 4-corner (camera) off (already `0`; N/A, no camera).
- `persist.sys.vafocus=0` — autofocus off if desired (already `0`).
- Because a native/system_server component owns the sensor loop, confirm live that after setting `tpryauto=0`
  the values stay put across a tilt and a reboot (§6). If it still re-applies, also clear its record
  (`persist.sys.keystone.update`, `persist.sys.keystoneAngle`) — but treat those as writes to test carefully.

---

## 4. Other projection settings worth exposing in our UI

All of these are system-app features; our launcher can deep-link the ones that are exported, or drive them via
the shell helper. Props/mechanisms:

- **Projection mode (front/rear/ceiling flip):** `ProjectionModeActivity`. Prop `persist.sys.panelvalue`
  (0,1,2,3) applied via `AwTvDisplayManager.factorySetPanelValue(E_AW_PANEL_CONFIG_MIRROR, value)` and broadcast
  `android.intent.projective_mode`. Also `persist.sys.projection.position` (0/1) swaps 0↔2. Values map to
  Desktop-front / Desktop-rear / Ceiling(hoisting) / Ceiling-rear (string ids `desktopcast`,
  `desktoprearprojection`, `hoistingandcasting`, `rearprojection`). vafocus `LocalService` handler `4` also calls
  `factorySetPanelValue(MIRROR, persist.sys.panelvalue)`.
- **Zoom / screen size:** `ScreenZoomActivity` → `persist.vendor.overscan.main` (`overscan N,N,N,N`, 80..100 on
  slider 0..20) + the keystone warp (§3.2). This is also the "power consumption mode" menu row
  (`powerconsumptionmode_rl → ScreenZoomActivity`).
- **Picture modes / image:** `PictureModeActivity` via `com.softwinner.a` (`k.e(id,val)`/`k.a(id)`): id 1=brightness,
  2=contrast, 3=? , 4=saturation, 5=? (0..100; brightness default 100, others 50). Also `BrightnessActivity`
  (projector lamp brightness via `android.os.PrjScreen.set_brightness_level`), `ColorTemperatureActivity`.
- **Autofocus / focus motor:** vafocus (`com.hysd.vafocus`, the "tpjz" / projection-correction app). Toggle
  `persist.sys.vafocus`. Focus is camera-assisted; this unit has `camok=0` (no camera) and `focusupdn=1`
  (manual up/down focus). `persist.sys.focus_delay=2000`. There is a lamp/fan interface `android.os.PrjScreen`
  (`get/set_fan_level`, `get/set_brightness_level`, `set_angle_offset`) used by `ProjectionActivity4` /
  `com.htc.util.o`. (A physical focus motor is not evidenced; focus appears manual on this SKU.)
- **HDMI / source switching:** Softwinner TV stack present: `com.softwinner.awlivetv` (AwLiveTv),
  `com.softwinner.awsource` (AwSource), `com.softwinner.vis` (VideoInputService), `tv_input` service
  (`android.media.tv.ITvInputManager`). htcsettings switches signal via `com.htc.util.d.d(ctx,"HDMI1"/"HDMI2")`
  (receiver action `intent.start.signal`; `persist.sys.prj.type` "t03"→HDMI2 else HDMI1). `dumpsys-hdmi.txt` =
  `hdmi_control` service. Expose by launching AwSource/AwLiveTv or sending `intent.start.signal`.
- **Fan level / power:** `ProjectionActivity4` → `PrjScreen.set_fan_level(i)`, gated by `persist.sys.enablefans`.
- **Standby / screensaver:** `com.htc.screensaver` (`persist.sys.screendream.*`, `persist.screensaver.compnent`),
  `ScreenSaverActivity` (exported). Power dialog `com.htc.closedialog/.WeiMiMainActivity`
  (`persist.sys.power_package/class`). Shutdown broadcasts handled by the launcher
  (`action.projector.battery_shutdown`, `android.intent.action.ACTION_SHUTDOWN`).

---

## 5. Useful intents / activities we can launch from our own launcher

From `com.htc.htcsettings` (`AndroidManifest.xml`); `exported="true"` unless noted:

- `com.htc.htcsettings/.activity.HomeActivity` — Settings home (actions `android.intent.action.MAIN`,
  `android.cmcc.settings.TV.SETTINGS`).
- `com.htc.htcsettings/.activity.ProjectionActivity` — "Projection Setting" menu (action
  `action.htcsettings.prjsettings`, category DEFAULT). Also `ProjectionActivity4`, `ProjectionActivity3` exported.
- `com.htc.htcsettings/.activity.CorrectionIndexActivity` — keystone/correction menu (exported). Parent of the
  keystone screens; from here the shell helper taps/navigates to `CorrectionActivity`.
- `com.htc.htcsettings/.activity.CorrectionDefaultActivity` — "reset correction to default" screen (exported).
- `CorrectionActivity` — **not exported** (manual 4-corner); shell-only via `am start -n …/.CorrectionActivity`.
- `com.htc.htcsettings/.activity.ProjectionModeActivity`, `ScreenZoomActivity`, `KeystonecorrectionActivity`,
  `PictureModeActivity` — **not exported** (reachable via `ProjectionActivity4` rows or shell `am start`).
- Exported broadcast actions (sent to htcsettings' `StartActionReceiver`): `intent.start.projectton` (→ProjectionActivity4),
  `intent.start.othersetting`, `intent.start.wifi`, `intent.start.bluetooth`, `intent.start.signal`,
  `intent.start.volume`. Also `action.htcsettings.{networking,bluetooth,time,language,deviceinfo}`,
  `android.settings.{WIFI_SETTINGS,NETWORK_SETTINGS,BLUETOOTH_SETTINGS,DATE_SETTINGS}`, and OTA `ota_install_htc`.
- `FactoryResetActivity`, `DeveloperOptionsActivity` (not exported), `AboutDeviceActivity` (exported),
  `ScreenSaverActivity` (exported), `ScreenBrightnessActivity`/`BrightnessActivity` (exported).
- Softwinner: launch `com.softwinner.awsource`/`com.softwinner.awlivetv` for source/HDMI; `tv_input` service for
  programmatic input switching.
- Launcher `com.htc.htclauncherhighenglishd08` is the HOME app (`persist.sys.homePackage`); it owns projector
  battery/power broadcasts (`action.projector.{dcin,batterylevel,battery_shutdown}`).

> Debloat/malware note (from project memory, re-confirm before shipping): Hotack firmware family has shipped
> `com.hotack.silentsdk`/`com.hotack.writesn` residential-proxy malware. Not seen in this package list
> (`packages-all.txt`), but `com.htc.eventuploadservice` (uid 1000) and `com.htc.storeos` are telemetry/store —
> candidates to disable. `com.htc.hyk_test` (HYK_TEST) is a factory test app.

---

## 6. What must be verified live on the device (exact commands)

Legend: **[R]** read-only (safe, matches the user's "read-only" constraint). **[W]** writes/changes device
state (the user said do NOT do these now — listed so they can be run deliberately later).
All with `adb -s 192.168.1.11:5555`.

1. **[R] Current corners / zoom / auto state** (baseline before any change):
   ```
   adb -s 192.168.1.11:5555 shell "getprop | grep -E 'keystone|overscan|tpry|vafocus|panelvalue|zoom.value|keystoneAngle'"
   ```
2. **[W, one-shot, highest-value test] Can shell call transaction 1050 directly?** If this does NOT print a
   permission error and the picture changes, the whole UI dance is unnecessary. (This *is* a warp change.)
   ```
   # 8 floats = LBx,LBy,LTx,LTy,RTx,RTy,RBx,RBy as fractions; here all 0.0 = full frame
   adb -s 192.168.1.11:5555 shell "service call SurfaceFlinger 1050 f 0.0 f 0.0 f 0.0 f 0.0 f 0.0 f 0.0 f 0.0 f 0.0"
   ```
   Expect `Permission denied`/`PERMISSION_DENIED` (confirms §2.1). If instead it returns `Result: Parcel(…)` and
   warps, shell can drive SF directly.
3. **[W] Does writing props + opening CorrectionActivity + a nudge apply?** (the recommended path)
   ```
   adb -s 192.168.1.11:5555 shell setprop persist.sys.tpryauto 0
   adb -s 192.168.1.11:5555 shell "for k in ltx:120 lty:120 rtx:120 rty:120 lbx:120 lby:120 rbx:120 rby:120; do setprop persist.display.keystone_${k%%:*} ${k##*:}; done"
   adb -s 192.168.1.11:5555 shell am start -n com.htc.htcsettings/.CorrectionActivity
   adb -s 192.168.1.11:5555 shell input keyevent 22   # DPAD_RIGHT  (pushes all 8 to SF)
   adb -s 192.168.1.11:5555 shell input keyevent 21   # DPAD_LEFT   (net zero)
   adb -s 192.168.1.11:5555 shell input keyevent 4    # BACK (exit)
   ```
   Watch the wall: the picture should pull all four corners ~12% inward. Then confirm the transaction fired:
   `adb -s 192.168.1.11:5555 shell logcat -d | grep -iE 'keystone|writeParcelToFlinger|rb_X'`.
4. **[R] Confirm shell can start the non-exported CorrectionActivity** (before step 3, check it resumes):
   ```
   adb -s 192.168.1.11:5555 shell "am start -n com.htc.htcsettings/.CorrectionActivity; sleep 1; dumpsys activity activities | grep mResumedActivity"
   ```
   (Launching an activity is arguably a state change; run only when ready.)
5. **[R] Map each corner's direction/sign** (the calibration probe): write one axis at a time to a known value,
   nudge, and observe which wall corner and direction moves — do this in the app's calibration loop rather than
   assuming, since projection mode flips axes.
6. **[W] Verify auto keystone stays off:** after `setprop persist.sys.tpryauto 0`, tilt the unit and reboot, then
   re-read the props (step 1) to confirm system_server does not overwrite them. If it does, also investigate
   clearing `persist.sys.keystone.update` / `persist.sys.keystoneAngle`.
7. **[R] (optional) Pull the auto-keystone class for exact math:** decompile `services.jar` and find the class
   using `persist.sys.keystoneAngle` / `/sys/devices/platform/prj343x/xyz_data` to read the tilt→corner formula.
   The 8-float apply there will again be transaction `1050`.

### Key file/symbol references
- Apply: `com/htc/util/k.java` `E()` / `F(boolean)` (transaction 1050); `com/hysd/vafocus/TpCorrectUtils.java`
  `androidN_tp_correct`; `com/hysd/vafocus/PropertiesUtils.java` `efect_tp_correct` / `keystone_reset`.
- UI: `com/htc/activity/CorrectionActivity.java` (`r()`→`util.k.u()`, `onKeyDown`→`D()`→`util.k.C()`→`E()`;
  checkbox ids `check_lt/lb/rt/rb`; arrow→keyCode 19/20/21/22; hidden reset = hold center ×10 with
  `persist.sys.hideok=1`).
- Reset: `com/htc/util/k.java` `x()` (8 zeros + apply); `CorrectionDefaultActivity`.
- Zoom/overscan: `com/htc/activity/ScreenZoomActivity.java`, `com/htc/util/k.java` `D()`/`c()`.
- SF: `/system/lib/libsurfaceflinger.so` (strings: `android.ui.ISurfaceComposer`, `getKeyStoneMatrix`,
  `persist.display.keystone_*`, `android.permission.HARDWARE_TEST`, `"can't access SurfaceFlinger"`),
  `/system/lib/libkeystone.so` (GL warp), `/system/framework/services.jar` (auto keystone).
- Reference impl to port: `reference/hy300-keystone/helper/src/com/hy300/keystone/Helper.java`,
  `reference/hy300-keystone/MAPPING.md`, `ks-apply.sh`.

---
## 7. LIVE RESULTS (2026-10-20, verified on the device)

1. **Direct SurfaceFlinger call from shell is DENIED** (tested by re-sending the current values — no change):
   `service call SurfaceFlinger 1050 f ...` → `Parcel(Error: 0xffffffff "Operation not permitted")`;
   logcat: `Permission failure: android.permission.HARDWARE_TEST from uid=2000` /
   `SurfaceFlinger: Permission Denial: can't access SurfaceFlinger pid=…, uid=2000`.
2. **`am start` of CorrectionActivity from shell is DENIED** on this firmware (unlike the doc's assumption):
   `SecurityException: Permission Denial: starting Intent { cmp=com.htc.htcsettings/com.htc.activity.CorrectionActivity } … not exported from uid 1000`.
3. **Reachable path via UI navigation (works from shell):**
   `am start -n com.htc.htcsettings/com.htc.activity.HomeActivity` (exported) → focus is on the first tile;
   `KEYCODE_DPAD_DOWN` → "Projection Setting" → `DPAD_CENTER` → `ProjectionActivity`
   (tiles: Screen Zoom | Projection Mode | Keystone Correction) → `DPAD_RIGHT ×2`, `DPAD_CENTER` →
   `CorrectionIndexActivity` (rows: "Auto [ON]", "Initial angle correction").
   - `input tap` does NOT work on these TV screens; use D-pad key events. `uiautomator dump` works for reading text,
     but its `focused` attribute is unreliable — confirm focus with `screencap`.
   - **The manual 4-corner entry (`correction_rl` → CorrectionActivity) is HIDDEN while Auto keystone is ON**
     (`CorrectionIndexActivity` lines ~51/84 set it GONE when auto). Also, clicking it shows a toast and refuses while
     auto keystone / auto four-corner are on. So: set `persist.sys.tpryauto=0` (or toggle "Auto" off in the UI) first.
   - UI screenshots/XML of each step: `recon/ui/` (s1, proj, ksindex).
4. **Screen Zoom = 80%** (`persist.vendor.overscan.main=overscan 80,80,80,80`, `persist.sys.zoom.value=167,166,…`)
   is what shrinks the picture to ~64% area. User can fix it today: Settings → Projection Setting → Screen Zoom → max.

### Apply strategy (updated)
- **Phase 1 (no root):** helper (shell uid) does: setprop `persist.sys.tpryauto 0` → setprop 8× `persist.display.keystone_*`
  → navigate HomeActivity → Projection → Keystone Correction → (manual row now visible) → CorrectionActivity → net-zero
  D-pad nudge (RIGHT, LEFT) → BACK ×3 → HOME. ~3–4 s per apply; fine for "apply preset" and photo auto-fit.
  For LIVE corner dragging, stay inside CorrectionActivity and translate phone drags into corner-select + arrow presses
  (1 unit per non-repeated press; repeats accelerate to 8).
- **Still to investigate:** `com.hysd.vafocus/.LocalService` (exported, uid 1000, no permission) has
  `keystone_setbk_val()` which reads `persist.display.keystone_*` and applies via transaction 1050 (handler msg 17),
  reached after a `hotack.vaf.runEnable` run when `tpryxcrt=0` and `persist.sys.focusupdn=0`. Shell can set those props
  and `am startservice` it → possible fast, UI-less apply path. Needs careful testing (camera-less unit).
- **Phase 3 (root via custom ROM):** call transaction 1050 directly (instant, any rate) — best for live dragging and mapping.

> **Correction (2026-10-20, CROSS-REVIEW.md):** §3.2/§7 "80% zoom → 0.8×0.8 ≈ 64% area" is wrong. Overscan 80 is
> converted to insets of ~16.6–18.7% per side (`((100-80)*16*1000)/1920 = 166`), so the captured insets leave
> ≈42% of the panel area (~67% × ~65%). Still to verify optically.

## 8. LIVE RESULT 2026-10-20 15:45 — txn 1050 PERSISTS the values
A uid-1000 `transact(1050)` with new insets both warps the picture **and writes `persist.display.keystone_*`**
(SurfaceFlinger/libkeystone `saveKeystonePara`). Consequences:
- A "live only" preview does not exist at this layer: every apply is persistent (survives reboot).
- Rollback must apply a **captured copy** of the previous values; re-reading props after an apply returns the new values.
- The PreviewCoordinator must persist the original values in its own storage before the first apply, and restore from
  that record on timeout/disconnect/service restart (as the Codex control contract specifies).
- Test 1 (top-left inward 166→266 / 165→265) applied ok; the first rollback wrongly re-applied props (bug), corrected
  ~20 s later by re-applying the snapshot; props verified equal to snapshot.
- A `screencap` taken 3 s into test 1 shows the full, unwarped frame (screensaver) → **screenshots are captured before
  the keystone warp**; geometry can only be verified optically (eye, phone photo, webcam), never by screencap.
