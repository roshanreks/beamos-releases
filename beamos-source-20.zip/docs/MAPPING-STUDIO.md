# Mapping Studio (BeamOS 0.12)

Lazy-Lighting-style projection mapping from the phone: light only the surfaces you choose, leave the rest dark.

## How to use it

1. Phone → **Map** tab.
2. **📷 Room photo** — the projector shows a calibration frame (grid + red/green/blue/yellow corners), the phone camera opens, you photograph the wall. The four corners are found automatically (same detector as Auto Screen); if the room is too bright you tap them instead. The photo is warped into projector space, so the editor canvas *is* the wall as the projector sees it.
3. **＋ Surface** — drag the four corners onto the thing you want lit (a panel, a shelf, a door frame). Drag inside to move the whole shape.
4. Fill: **Colour**, **Pattern** (diagonal stripes, grid, breathing dots, pulse, gradient sweep — two colours + speed), **Picture** or **Video** (upload from the phone, up to 400 MB, loops, volume per surface).
5. **▶ Show on wall**. Everything you change afterwards is live on the wall. **■ Hide** (or BACK on the remote) closes it.
6. **Scenes** — save/load/delete named scenes.

Showing the output is always an explicit tap; if something is playing it asks first (409 → confirm). Opening the Map tab, editing and uploading never touch what is on the wall.

## How it works

| Piece | Where |
|---|---|
| Renderer | `MappingView.java` — colour/pattern/image surfaces drawn on one canvas with `Matrix.setPolyToPoly` (perspective per quad, clipped); each video surface is a `TextureView` with the same transform + a looping `MediaPlayer`. Patterns redraw only while one is animated. |
| Output activity | `MappingActivity.java` — full screen, keeps screen on, BACK closes, releases players/bitmaps on destroy. `apply()` swaps scenes live. |
| Store + routes | `Mapping.java` — `files/mapping/scene.json` (current), `files/mapping/scenes/*.json`, media in `files/mapping/`. Validates quads (±0.5 of the picture), types, that media files exist, ≤24 surfaces, ≤3 videos. |
| Upload | `PUT /api/mapping/upload?name=…` — raw body. `HttpServer` streams this one path (up to 400 MB) to a `.part` file instead of buffering; everything else keeps the 256 KB limit. Names are sanitised, extensions allow-listed (jpg/png/webp/gif, mp4/webm/mkv/mov/3gp), refuses when < 150 MB would remain free. |
| Live edits | WS `{"t":"map","scene":…}` (debounced 120 ms on the phone) → `Mapping.setScene` → `MappingActivity.apply`. Falls back to `POST /api/mapping/scene` when the socket is down. |
| Editor | `index.html` Map tab: 960×540 canvas in projector space, pointer drag for corners/moves, photo warp via the existing `homography`/`hap` helpers (inverse mapping, nearest sample). |

## Scene format

```json
{"surfaces":[
  {"id":"s1","name":"Shelf","type":"pattern","pattern":"stripes","color":"#ff7a59","color2":"#1b2a66","speed":1,"opacity":1,
   "quad":[[0.12,0.20],[0.41,0.21],[0.40,0.63],[0.12,0.60]]},
  {"id":"s2","name":"Door","type":"video","file":"waves.mp4","volume":0,"quad":[[0.6,0.1],[0.9,0.1],[0.9,0.9],[0.6,0.9]]}
]}
```
Quad order TL, TR, BR, BL, normalised to the projector picture (0..1). Keystone still applies on top (SurfaceFlinger), so a mapped scene stays mapped after a Screen Coach change.

## Memory

Images are decoded at ≤1280 px (≈3–4 MB each); each video is one MediaPlayer (~20–40 MB). The 3-video cap keeps a full scene under ~150 MB on the 940 MB device. `MappingActivity` runs in the main studio process (no extra process), so hiding it frees everything immediately.

## Not yet (v2 ideas)

- Curved/mesh surfaces (bezier edges) — research/08.
- Live phone camera "paint with light" (tap on the live view to add a surface there).
- Audio-reactive patterns (mic on the phone → speed).
- Masks (subtract a shape from another).
