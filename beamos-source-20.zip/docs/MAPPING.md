# Projection mapping design — "Beem Studio · Map"

Goal (user, 2026-10-20): the best projection-mapping tool for this projector, so that keystoning and
mapping the exact projection area is easy from the phone or the PC.

There are two different things the projector can warp, and that decides everything:

| | System warp (firmware keystone) | Content warp (our renderer) |
|---|---|---|
| Applies to | **Everything** on screen: launcher, Netflix, HDMI-in, AirPlay | Only what **our app** draws |
| Shape | 4 corners only, inward only, within firmware limits (see KEYSTONE-RE.md) | Anything: many quads, mesh/bezier warp, masks, curved surfaces |
| Use | "Make the picture fit this exact area" | Creative mapping: walls, boxes, posters, stage, decorations |

So the tool has three tiers.

## Tier 1 — Fit-to-Area (system keystone, works for all apps)

User flow (phone or webcam):
1. Projector shows the calibration pattern (ArUco markers at known projector pixels).
2. Phone takes a photo (or live camera over HTTPS). Page finds the markers → homography **camera → projector**.
3. User marks the target area on the photo: drag 4 corners, or tap "auto" to detect a rectangle (screen frame, poster,
   painted area, door) via edge/contour detection. Options: lock 16:9, "level with gravity" (iPhone DeviceMotion),
   "square to wall edges".
4. Target quad → projector pixel coords → required corner positions → firmware keystone values → apply.
5. Re-measure once or twice (closed loop) until the error is < ~3 px. Save as a preset (room/orientation).

Constraints shown in the UI: target must lie inside the current full-frame projection; corners can only move inward up to
the firmware maximum; show the "pixels kept" percentage (smaller area = softer image) and suggest moving the projector
when the loss is large.

## Tier 2 — Mapping Studio (our OpenGL renderer on the projector)

- **Surfaces:** quad (homography), grid mesh (N×M points, bilinear or bezier), triangle, polygon mask; per-surface
  opacity/brightness/edge feather; z-order; groups.
- **Sources:** video files (MediaCodec → SurfaceTexture, H.264 ≤ 1080p hardware decode), images, colours/test patterns,
  GLSL generative shaders, text/clock, USB-webcam feed, (later) AirPlay stream if we integrate the receiver library.
  Netflix/DRM and probably HDMI-in cannot be captured into our renderer (secure/sideband paths).
- **Editor on phone or PC (same web app):**
  - *Canvas view:* projector pixel space, drag points; changes stream live over WebSocket, the wall updates instantly.
  - *Through-camera view:* a photo/live view of the real wall with surfaces drawn on top; dragging there is converted
    with the camera→projector homography — you "paint" onto the wall you see on the phone.
  - Snap, nudge with arrows, undo/redo, scenes, playlists, timers; export/import JSON.
- **Auto-map (structured light):** projector shows Gray-code (+ phase-shift) patterns, phone/webcam captures them →
  per-pixel camera↔projector map → user outlines objects on the camera image → mesh warps generated automatically,
  including curved surfaces. Optional: fix camera distortion first with a checkerboard.
- **Renderer budget:** OpenGL ES on Mali-G31 MP2, 1920×1080@60; 1–2 video layers + simple shaders; no WebView;
  scene file small JSON; renderer only runs in Map mode.

## Tier 3 — PC as the mapping engine (optional)

For heavy shows: run a desktop mapper on the Mac and send the output to the projector by **HDMI cable** (no latency) or
**AirPlay** (wireless, some latency). Free: MapMap (GPL), browser tools (maptastic, p5.mapper,
ProjectorVideoMappingWeb). Paid: MadMapper, Resolume Arena, HeavyM. Our preferred design is still Tier 2 (projector
renders, PC/phone only edit → no streaming lag, works without the laptop).

## Open-source parts

| Use | Repo | License | Why |
|---|---|---|---|
| Web corner-pin | glowbox/maptasticjs | custom (check) | tiny CSS matrix3d corner pin; editor ideas |
| Web mapping lib | jdeboi/p5.mapper | MIT | quad/triangle/bezier/mesh surfaces + masks + save/load JSON — model for our scene format |
| Browser mapper | vitalyu/ProjectorVideoMappingWeb | none listed | UX reference |
| Lightweight mapper (Raspberry Pi) | kr15h/ofxPiMapper | custom | surface/source architecture on weak hardware — closest analogue to our renderer |
| Desktop mapper | mapmapteam/mapmap | GPL-3 | feature reference; can run on the Mac for Tier 3 |
| Little mapping tool | hvfrancesco/lpmt | GPL-3 | mesh/bezier warp, masks |
| Grid warp widget | tito/projectionmapping | — | grid warp math reference |
| Warp + blend | charlesveasey/ofxWarpBlend | GPL-3 | edge blending reference |
| Preview/simulation | baku89/VirtualMapper | MIT | realtime preview idea for the editor |
| VJ/mapping app | riskcapital/ghost-arcade | AGPL-3 | modern feature ideas (decks, beat sync) |
| Marker detection (browser) | jcmellado/js-aruco | custom (BSD-like) | find projected markers in Safari |
| OpenCV in browser | TechStark/opencv-js | Apache-2 | homography, contours, rectangle detection, undistort |
| Structured light | punpongsanon/graycode-procam-calibration, kamino410/phase-shifting, elliotwoods/ofxGraycode | MIT / MIT / — | auto-map algorithms |
| Procam calibration | kamino410/procam-calibration, BingyaoHuang/single-shot-pro-cam-calib | — | full calibration maths |
| Keystone approach | tthumbra/hy300-keystone | none (reference only) | phone flow + solver for 4-corner firmware keystone |

## Build order

1. Tier 1 manual: drag 4 target corners on the phone canvas → system keystone (needs KEYSTONE-RE apply path).
2. Tier 1 photo: markers + tap target corners on the photo; presets; gravity level.
3. Tier 2 v1: renderer with quads + images/video + canvas editor.
4. Tier 2 v2: through-camera editing, mesh warp, masks, scenes/playlists.
5. Auto-map with Gray code (phone first, USB webcam later for one-tap re-mapping).
