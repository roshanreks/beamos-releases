# BeamOS — Master Plan (single checklist for the whole project)

Last updated: 2026-10-20. Owner: Roshan. Device: Portronics Beem 470 (Hotack H713, Android 11).
Read with: README.md (facts) · docs/OS-PLAN.md (vision) · docs/KEYSTONE-RE.md · docs/SECURITY-AUDIT.md ·
docs/MAPPING.md · docs/ROADMAP.md · research/01–05 · docs/CHANGELOG-DEVICE.md (every device write + undo).

## 0. Where we are (done)

| ✓ | Item | Evidence |
|---|---|---|
| ✓ | Hardware/firmware identified (H713, Android 11, 32-bit, ~940 MB RAM, ADT-3 identity) | README §1, recon/20261020-1252 |
| ✓ | ADB over Wi-Fi working (192.168.1.11:5555) | README §2 |
| ✓ | Full read-only snapshot + 29 vendor APKs + file-level firmware copy (system/vendor/product/odm/system_ext) | recon/, firmware-files/ |
| ✓ | Keystone fully reverse-engineered (SurfaceFlinger txn 1050, 8 floats LB,LT,RT,RB, 0–0.5) | docs/KEYSTONE-RE.md |
| ✓ | Root cause of soft/small picture: Screen Zoom 80% + Auto keystone hiding manual mode | KEYSTONE-RE §7 |
| ✓ | Security audit; 6 risky vendor apps disabled (reversible) | SECURITY-AUDIT.md, CHANGELOG-DEVICE.md |
| ✓ | **Firmware signed with PUBLIC AOSP keys → our app runs as system uid 1000** | README "Breakthrough" |
| ✓ | **Proof: platform-signed probe ran as uid 1000 and applied keystone via txn 1050 (ok=true)** | CHANGELOG-DEVICE.md 13:50 |
| ✓ | Toolchain: adb, JDK 17, SDK build-tools 34, platform 30, jadx, public AOSP keys | README §3, keys/ |
| ✓ | Research: features (01), connectivity (02, partial), ROM/flash (03), vision (04a; 04 running), firmware capabilities (05 running) | research/ |
| … | Android TV 12 arm64 emulator image downloading (slow link ~0.3 MB/s) | scratchpad/sdk-emulator.log |

## 1. Guiding principles ("no mistakes")

1. **Reversible first.** BeamOS ships as a normal installable system-uid APK long before any flash. Uninstall = gone.
2. **Hardware behind one interface.** `HardwareBridge` with two implementations: `RealBridge` (projector: txn 1050,
   props, vendor display/TV APIs) and `FakeBridge` (emulator/tests). All UI/logic is developed and tested on the Mac.
3. **Safety rails on anything visual:** range validation (0–500 per-mille per corner), *confirm-or-revert* timer
   (15 s, like a monitor resolution dialog) for keystone/picture changes made remotely, a **panic reset** (remote key
   combo + phone button + boot-time check) that restores the last known-good geometry, and a snapshot before every write.
4. **Tests before device.** Pure logic (geometry, solver, validation, API, pairing) has unit tests on the JVM;
   UI is tested in the emulator; device integration tests run via adb scripts that snapshot and restore state.
5. **Every device write** is logged in CHANGELOG-DEVICE.md with its undo.
6. **Lightweight:** Java 8 + Android Views, no heavy frameworks; one process; idle < 40 MB PSS; no WebView on device.
7. **Local-only, private:** no cloud, no accounts, no telemetry. LAN API needs a paired token over TLS.
8. **Flash only with a verified full backup** (FEL dump) and only after months of stable app-level use.

## 2. Architecture (app-level phase) — revised after CROSS-REVIEW.md

Two processes, one narrow privilege boundary:

```
iPhone / Mac (PWA, later native) ──TLS + paired session──▶ com.beamos.studio  (NORMAL uid)
                                                           ├─ Gateway: HTTPS/WSS, pairing, sessions, origin/replay checks,
                                                           │  Control Protocol v1 (allowlisted, bounded, typed)
                                                           ├─ Launcher (HOME), Quick Panel, Screen Coach UI, Settings UI
                                                           ├─ Preview coordinator client, capability cache
                                                           └─ binds (signature-permission protected) ▼
                                                        com.beamos.adapter (sharedUserId=android.uid.system, tiny)
                                                           ├─ typed ops only: keystone preview/confirm/cancel/read,
                                                           │  picture controls, zoom, projection mode, source switch,
                                                           │  key/text/pointer injection, volume, app launch (allowlist)
                                                           ├─ device-side PreviewCoordinator: persist original state,
                                                           │  revision check, 15 s timer, restore on disconnect/restart
                                                           ├─ geometry: KeystoneInsets (canonical TL,TR,BR,BL ↔ LB,LT,RT,RB)
                                                           └─ NO network sockets, NO shell, NO raw Binder/property API
                                                        Vendor stack: SurfaceFlinger txn 1050, props, TV input, audio, power
```

- Capability model: every capability = UNVERIFIED | SUPPORTED | UNSUPPORTED + reason + evidence; "installed" ≠ "plays".
- Profiles (rooms/presets) carry firmware id + source + orientation; mismatches are rejected, never applied silently.
- Public AOSP test key = development trust only; final ROM gets its own keys and permission policy.
- TLS for the phone: start with plain-HTTP still-photo upload + pairing; add a local CA (installed once) for live camera.

## 3. Milestones, tasks, acceptance criteria

### M1 — BeamOS v0.1: adapter + studio (installable, reversible)  ← NOW
- [x] Geometry codec `beamos/geometry` (KeystoneInsets, 18 tests, imported from Codex work)
- [x] Probe build fail-fast + explicit SIGNING_MODE (bug found by cross-review)
- [ ] Guarded **new-value** keystone experiment: persist original → apply small known change → photo/visual check → restore (owner present)
- [ ] `com.beamos.adapter` (uid 1000): typed AIDL/Messenger API guarded by a signature permission; PreviewCoordinator
      (persist original, revision, 15 s timer, restore on disconnect/service restart); FakeAdapter for emulator/tests
- [ ] `com.beamos.studio` (normal uid): Gateway (HTTP first, pairing QR + token, Control Protocol v1), web app v0.1:
      Remote (d-pad/OK/back/home/volume), Keyboard, Screen Coach manual 4-corner with "Try for 15 s", reset
- [ ] Input injection (keys/text) in adapter with allowlist; text never logged
- [ ] Tests: JVM unit tests (geometry, protocol, sessions); emulator with FakeAdapter; device script snapshot→test→restore
- [ ] Source coverage tests for global keystone: launcher, YouTube TV, Netflix (secure video), HDMI-in → capability states
- **Done when:** on the projector, iPhone Safari pairs via QR, controls the remote, types text, drags each corner
  live (instant, all apps), auto-reverts if not confirmed, panic reset works; uninstall leaves no trace.

### M2 — Picture, size & scenes
- [ ] RealBridge.picture (modes, brightness, contrast, colour temp, sharpness …) from research/05
- [ ] Screen zoom/overscan, projection mode (front/rear/ceiling), auto-keystone on/off
- [ ] Scenes/presets ("Movie night", "Ceiling bed") applying geometry + picture + volume + app
- [ ] MotionWatcher: detect bump/tilt change → offer re-apply preset
- **Done when:** every vendor picture/projection setting is controllable from the phone, with presets.

### M3 — Launcher, Quick Panel, setup
- [ ] BeamOS launcher (set as default HOME; vendor launcher kept installed, disabled only after acceptance)
- [ ] Continue Watching row (TvProvider Watch Next), app rows, inputs, quick actions
- [ ] Quick Panel overlay; first-run setup (Wi-Fi → pair phone → CA install → Google sign-in typed from phone)
- **Done when:** daily use needs neither the vendor launcher nor the IR remote.

### M4 — Calibration with the iPhone camera
- [ ] Fit-to-Area: ArUco grid → homography → user/auto target quad → insets → apply → re-measure
- [ ] Focus Coach (sharpness meter + tone), auto level, wall-colour L0 (if display WB reachable)
- **Done when:** a phone photo makes the picture land in a chosen rectangle within ~3 px.

### M5 — Connectivity
- [ ] AirPlay receiver (jqssun/android-airplay-server, configured by BeamOS), disable EShare stack after
- [ ] LocalSend receiver ("send to Beam" from iPhone/Mac), HomeKit TV (HAP-Java) → Control Center remote + Siri
- [ ] Android TV Remote v2 server (Home Assistant), iOS Shortcuts recipes, Mac menu-bar app (SwiftUI)
- [ ] Travel hotspot mode with QR join

### M6 — Mapping Studio (GL renderer) & auto-map (docs/MAPPING.md)

### M7 — BeamOS ROM via pen drive
- [ ] Buy USB A-to-A cable; Linux VM (UTM); find FEL entry; full dump ×3 copies
- [ ] Build image (research/03 pipeline): debloat, BeamOS priv-apps, root helper, timestamp > 20250530, slot _a only
- [ ] Flash via pen drive; verify; restore drill from dump on purpose once
- **Done when:** BeamOS boots from a clean flash, all streaming apps work, and a full restore has been rehearsed.

## 4. Testing matrix (every release)

| Layer | How | Gate |
|---|---|---|
| Logic | JVM unit tests (geometry, validation, pairing, API) | 100% pass |
| UI | Android TV emulator (FakeBridge), remote-only navigation | manual checklist |
| Device | adb script: snapshot props → run feature → verify → restore | no diff after restore |
| Streaming | Netflix, Prime Video, JioHotstar, YouTube, ZEE5, SonyLIV play after each release | all play |
| Recovery | panic reset, uninstall, (later) restore from dump | works |
| Performance | `dumpsys meminfo com.beamos.core` < 40 MB idle; boot-to-home time | no regressions |

## 4b. Feature-retention contract (must never regress) — from Codex FEATURES.md
Local apps · Google Play · streaming services (each: install, login, paid playback, controls, resolution, updates) ·
Wi-Fi · Bluetooth (audio + accessories) · HDMI-in (picture, sound, reconnect) · USB/local files · speaker/AUX/BT audio ·
AirPlay/EShare/DLNA/Miracast (baseline measured before replacing) · auto/manual keystone · zoom & orientation ·
manual focus · physical remote/buttons · standby/fan/thermal/power · updates/reset. Each is an acceptance row per release.

## 5. What the user needs to do / provide

- [ ] Fix today (optional): Settings → Projection → Screen Zoom → max; Keystone Correction → Auto off (manual appears)
- [ ] Buy a USB A-to-A cable (needed only for M7)
- [ ] Optional: wide-angle UVC webcam (M4+), ESP32 IR blaster for power-on (M5+)
- [ ] Name the OS (working name BeamOS)
- [ ] Approve each device install / setting change when asked

## 6. Open questions (to resolve as we go)
- Which picture/colour APIs are reachable as uid 1000 (research/05) — and is display-engine WB/gamma exposed?
- Panel native resolution; HDMI-in latency with/without keystone; CEC; remote IR-only?
- Does a UVC webcam enumerate and at what CPU cost?
- Widevine level (install "DRM Info" from Play) and whether the Netflix TV app (`com.netflix.ninja`) works.
- Does ADB-over-network survive reboot, or must BeamOS keep its own path (it doesn't need ADB once installed).
