# "Our OS" for the Beem 470 — full plan (working name: BeamOS)

User goal (2026-10-20): a complete Android-based OS of our own, flashed from a USB pen drive, with all
streaming apps (Netflix, Prime Video, JioHotstar, YouTube, …) working, and the whole projector controllable from
the iPhone and the MacBook — picture, quality, size, keystone, connections, everything — pushed to the max.

## 1. What "our OS" can and cannot be

- **Can:** everything the user sees and touches is ours — setup wizard, launcher/home, settings, quick panel,
  system services, phone/Mac control, receivers, updates — on top of the projector's own Android 11 hardware layer.
  This is how serious custom firmwares for TV boxes are made.
- **Cannot:** a ground-up Android build. Allwinner's H713 SDK (kernel + HAL sources) is not public, and the parts that
  make this projector work — LVDS panel/display firmware, the keystone warp inside SurfaceFlinger (`libkeystone.so`,
  transaction 1050), Wi-Fi AIC8800 driver, IR remote, Widevine/OP-TEE keys in secure storage — are closed binaries.
  We keep them and replace everything above them.
- **Must keep** to keep streaming apps happy: the device identity (ADT-3 fingerprint), Play Store + Google services,
  the Widevine DRM HAL + OP-TEE (running on this unit, trusted apps present → likely Widevine L1; confirm with the
  "DRM Info" app), and secure storage (never wipe it; it holds keys, MAC, serial).

## 2. Verified facts that shape it (2026-10-20)

| Fact | Consequence |
|---|---|
| Widevine HAL `drm@1.3-service-lazy.widevine` + `optee` running with trusted apps; PlayReady plugin present | HD DRM is plausible; measure before promising HD |
| Netflix installed is the **phone app** `com.netflix.mediaclient` 8.121 (not the TV app `com.netflix.ninja`) | Vendor likely lacks Netflix TV certification. Our OS keeps whatever works; test the TV app as an experiment. Can't fake certification. |
| `android.software.leanback`, `type.television`, `live_tv` features; `com.android.providers.tv` present | Android TV apps install normally; **Watch Next / Continue-watching rows** can be read by a privileged launcher |
| YouTube TV app present | YouTube "Link with TV code"/second-screen casting from the phone works |
| Shell cannot call SF 1050 or open CorrectionActivity; system/root can | Root (Magisk in our ROM) unlocks instant keystone + mapping |
| Raw partitions root-only; `super` = 3 GB dynamic partitions (system, vendor, product, system_ext, odm) | ROM work = unpack `super`, edit, repack; needs full FEL backup first |
| 1 GB RAM, ~50 MB free at idle | Removing vendor bloat + EShare + spyware is the biggest speed win |

## 3. Architecture

```
┌──────────────────────────── BeamOS (our layer) ────────────────────────────┐
│ Setup wizard │ Launcher (home + Continue Watching) │ Quick Panel overlay   │
│ Settings (ours: picture, size, keystone, mapping, inputs, audio, network) │
│ beamd — privileged core service (priv-app + root helper)                  │
│   • keystone/mapping engine (SF 1050)   • picture engine (vendor TvDisplay)│
│   • inputs (TIF / awlivetv HDMI)         • audio (BT, AV-sync offset)      │
│   • power/sleep/schedules/thermal        • app manager, OTA, backup        │
│   • LAN API: HTTPS + WebSocket, pairing, mDNS `_beamos._tcp`              │
│ Receivers: AirPlay (GPL app), Miracast (vendor), DLNA, YouTube DIAL        │
├──────────────── kept vendor/Google layer ──────────────────────────────────┤
│ Play Store + GMS, Widevine/OP-TEE, SurfaceFlinger+libkeystone, HALs,       │
│ panel/display firmware, Wi-Fi/BT drivers, IR, kernel 5.4                   │
└─────────────────────────────────────────────────────────────────────────────┘
Controllers: iPhone/Android PWA · Mac/PC browser · Mac menu-bar app · iOS Shortcuts/Siri · (opt.) native iOS app
```

## 4. Feature catalogue (pushed to the max)

### Picture & size
- Picture modes, brightness, contrast, saturation, hue, sharpness, colour temperature, gamma — live sliders on the
  phone with instant preview (vendor `PictureModeActivity`/`BrightnessActivity`/`ColorTemperatureActivity` logic →
  our engine). Per-input and per-app profiles (Netflix = cinema, HDMI game = low-latency/vivid).
- Size: screen zoom 80–100% + keystone shrink, shown as a live "picture size / pixels kept" meter; recommends physical
  placement when software shrink costs sharpness.
- Keystone + **Fit-to-Area** + **Mapping Studio** (docs/MAPPING.md); presets per room/orientation; auto-select preset by
  tilt angle + Wi-Fi network; one-tap ceiling/rear/front flips; panic "reset to full frame".
- Night/eye-comfort mode by schedule; test patterns for focus and alignment; focus assistant (phone camera measures
  sharpness while you turn the focus ring — Beem 470 focus is manual).

### Control from phone / Mac (no extra logins)
- Pair once by QR → the phone is trusted (token), no account, no cloud — works on the local network only.
- Remote: d-pad, touchpad/mouse, **type with the iPhone keyboard (iCloud Keychain autofill works in the page)**, voice
  dictation into search, volume, power/sleep, input switch, app launcher, now-playing controls (MediaSession).
- Mac: same web app + a small menu-bar app (hotkeys, drag a file/photo/video onto it to play on the projector,
  quick picture/size controls). AirPlay from macOS is built-in once the AirPlay receiver runs.
- iOS Shortcuts / Siri: "Hey Siri, movie night" → HTTP call → preset (picture, size, volume, open app).
- Share sheet: send photos/videos/links from iPhone to the projector.
- Home Assistant integration (optional) — scenes with lights.

### Streaming & connections
- Netflix, Prime Video, JioHotstar, YouTube, ZEE5, SonyLIV from the Play Store, logged in once — **signing in is made easy
  with the phone (type from iPhone, or the apps' own "sign in with code/QR")**. Logins and subscriptions are the apps';
  we don't bypass them.
- Continue-watching row across apps (Android TV Watch Next provider, where the apps publish).
- Screen share: AirPlay (iPhone, iPad, Mac), Miracast (Android phones that still support it), WebRTC share from any
  laptop browser, YouTube/Netflix second-screen where supported. Chromecast built-in is impossible (Google-certified only).
- Travel mode: projector creates its own Wi-Fi hotspot; phone joins by QR — remote + AirPlay work with no router.
- Bluetooth audio with AV-sync offset slider; audio output switch; HDMI-in with auto-switch on signal.

### Speed, privacy, reliability
- Remove spyware/telemetry/bloat at the image level (incl. root daemons the audit flags), drop the EShare stack, lean
  launcher, tuned memory (zram/LMK), animations off, AOT-compiled core apps, fast boot (no boot video, default source).
- DNS-level blocking of vendor telemetry domains; firewall for the vendor root daemons.
- Diagnostics page: temperature, fan, RAM, Wi-Fi signal, uptime; quiet/eco mode.
- Our own updates (signed by us), with one-tap rollback; config backup/restore to the phone/Mac.
- Kids profile / app lock / screen-time (optional).

## 5. The USB pen-drive install — exact pipeline

**Prerequisites (one-time):** USB A-to-A cable · Linux VM on the Mac (UTM, USB passthrough) · pen drive (FAT32) ·
the full FEL dump (7.3 GB) stored in 3 places.

1. **Backup:** FEL mode → well0nez `h713-install identify` + `dump --full` (read-only).
2. **Unpack:** extract partitions from the dump; `super` → `lpunpack` → system / vendor / product / system_ext / odm images;
   `boot_a` / `vendor_boot_a` / `vbmeta*`.
3. **Modify:**
   - product/system: delete vendor bloat + spyware APKs and init services (per SECURITY-AUDIT.md); add BeamOS apps as
     `priv-app` with `privapp-permissions-beamos.xml`; set BeamOS launcher as default home; keep Play Store/GMS.
   - props: keep the ADT-3 fingerprint; performance tuning (zram, LMK, dalvik heap), no boot video, default source LOCAL.
   - init: add `beamd` root helper service (SELinux is permissive on this build).
   - boot: Magisk-patch `boot_a` (root); `vbmeta` with verification disabled.
4. **Repack:** `lpmake` → new `super`; build the Allwinner IMAGEWTY `update.img` (awimg.py / imagewty-tool), keeping the
   original bootloader, env, `private`, `Reserve0`, secure storage untouched.
5. **Flash from pen drive:** FAT32 stick → `update/update.img` + `update/auto_update.txt` (`sunxi_flash write update/update.img firmware`),
   power on with the stick inserted (method documented for Hotack H713 boards — must be confirmed on this unit), or
   via FEL + PhoenixUSBPro / the well0nez installer if the stick method isn't supported.
6. **First boot:** BeamOS setup → Wi-Fi → phone pairing QR → Google sign-in (typed from the phone) → app installs.
7. **Recovery:** always possible from the FEL dump with the A-to-A cable.

Later updates: BeamOS updates its own apps in place; system-level changes ship as new pen-drive images.

## 6. Build order

1. Phase 1 (now, stock firmware, reversible): BeamOS apps as normal apps + shell helper — remote/PWA, picture & size
   controls (via settings UI automation where needed), keystone presets, AirPlay receiver, launcher, debloat.
2. Phase 2: FEL full backup; confirm pen-drive flash method; capture stock image.
3. Phase 3: BeamOS ROM v1 = stock base + debloat + our apps as priv-apps + root helper → pen drive.
4. Phase 4: instant keystone/mapping (root), Watch Next row, Mac menu-bar app, Shortcuts, travel hotspot, OTA.
5. Phase 5: USB webcam auto-calibration, mapping auto-map, native iOS app (LiDAR), Home Assistant.

## 7. Honest limits

- No hardware upgrade: brightness, panel resolution, 1 GB RAM, speaker stay as they are.
- Streaming quality is set by DRM level + each service's device certification — our OS can preserve it, not raise it.
- Can't bypass app logins/subscriptions; can make them painless from the phone.
- Chromecast built-in can't be added.
- Every flash carries brick risk; we only flash after a verified full backup.
