# Remember picture alignment and lighting scenes

Owner request: keep the latest alignment and light mapping until explicitly changed, including closing the phone remote or updating the app. This takes priority over the old default two-minute Screen Coach preview.

## Changes

- Ordinary Screen Coach changes apply and confirm through the existing adapter before reporting Saved. They no longer expire after two minutes. Undo also saves its result. Manual alignment switches off automatic tilt correction so the sensor cannot overwrite the selected corners.
- The explicit Settings full-frame/restore safety dialog remains a temporary preview with a visible Keep/Revert countdown. It is a separate intentional action.
- Fixed the saved/reverted browser event handlers, which referenced a removed countdown variable/element.
- Room-photo calibration uses temporary output, never the persisted scene file. Completion, cancellation, leaving Studio or a 120-second fallback restores the preceding mapping output or closes the temporary output.
- Warped room reference photos save separately on the projector and reload with Studio. They are not listed as content images.
- Scene writes use Android AtomicFile and are serialized; browser writes wait for storage acknowledgement. Reading a scene cannot overwrite a newer local edit. Unacknowledged edits have a local browser backup and an explicit restore prompt after reopening.
- Scheduled app updates wait while mapping output/calibration is active.
- In 0.16, a completed older state read cannot replace a newer alignment, and an old Settings preview timeout cannot undo a later permanent phone adjustment. Restarted explicit previews are identified as temporary.
- The publish helper stops on a failed remote push and distinguishes push from verified Pages deployment.

No optical or video-source changes are needed. The saved scene is retained when output is hidden; showing it again restores that scene. Calibration is an explicit temporary source change, not a permanent scene replacement.

## Verification

```bash
node beamos/tests/persistence/web-test.cjs
bash beamos/tests/persistence/run.sh <connected-adb-serial>
tools/build-apk.sh beamos/studio release
```

The Android test runs real Mapping/CoachSession code in an isolated app_process VM with fake display/Binder/navigation boundaries and temporary files. It does not install an APK, write projector corners, replace live scenes, or navigate the active projector screen. The companion test exercises deferred/failing network responses against the actual save/load functions.

Existing mappings already overwritten by an older calibration cannot be reconstructed from an empty scene. Named saved scenes and any existing atomic backup should be checked before claiming recovery. These changes prevent future loss; they do not invent missing coordinates.
