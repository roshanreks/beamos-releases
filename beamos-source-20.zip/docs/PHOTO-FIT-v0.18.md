# Photo fitting and proportional screen size — Studio 0.18 / 0.19

The projector keeps its existing alignment until an explicit fit, resize or manual edit is accepted. A successful photo fit now applies all eight inset values, reads back all four corners, confirms the adapter's temporary edit, and saves a plane transform on the projector. Closing Chrome, opening another remote, or restarting Studio does not erase that fit.

## Use it

1. Open Picture in the remote. For a tilted projector and an angled phone, use **Fit from a photo — measured wall reference**.
2. Tape an A4 sheet flat and level on the projection wall, outside the video if convenient but visible in the same photo. A real measured rectangle on that plane also works. A protruding AC face is not on the wall plane.
3. Press **Show photo codes**. Take a new photo showing all four codes and the reference. Each code contains its corner identity, the eight capture-time insets and the guide dimensions. Codes cover only the corner areas while video continues.
4. Upload the photo. All four picture corners are reconstructed from the code centres, rather than from arbitrary red/green/blue/yellow pixels in a video. Mark the reference TL, TR, BR, BL. Choose **A4 landscape** or **A4 portrait**, or enter measured width/height.
5. With automatic saving enabled, a complete set of points and a valid reference ratio fits and saves after the final point/ratio edit. **Fit & save 16:9** also applies it explicitly. Drag any dot to correct a mistaken point. Hardware errors remain visible rather than reporting success.
6. **Smaller/Bigger 2.5%** scales the fitted rectangle in the reference plane, preserving proportions under tilted optics. It stops at the firmware's optical/inset limits. Undo restores and saves the preceding fit/size. A manual corner edit invalidates proportional resize until a new fit.

Auto Screen's no-reference option constructs a rectangle in the photo plane. It is useful with a camera facing the wall squarely; an oblique photo alone does not establish the wall's physical aspect ratio. The measured-reference option rectifies camera perspective as well as projector perspective. Its accuracy depends on correctly marked, level, coplanar reference points and a stationary projector. Integer per-mille hardware coordinates also limit precision. No physical 100% accuracy claim is made from digital readback alone.

## Fixes and validation

| Before | After | Why |
|---|---|---|
| File picker opened after a delayed callback | Visible native file input | Preserves the phone's upload gesture |
| Unsupported iPhone HEIC could silently fail | Lazy local heic-to 1.5.2 worker, explicit errors | The owner's original 8064×4536 HEIC was actually tested in Chrome and now renders at 1600×900 |
| Video colours confused corner detection | Versioned QR identities and capture geometry; legacy/manual fallback | Rejects mixed captures and incomplete coded photos |
| Socket send could be mistaken for a successful fit | HTTP apply, hardware readback, durable confirmation | Success requires all eight coordinates to be accepted and saved |
| Further point edits could compound an old fit | Immutable capture baseline plus current-value compare-and-set | Reuses the original optics calculation and rejects another remote's intervening changes |
| Equal inset nudges distorted a tilted screen during resizing | Persisted plane transform and proportional plane scaling | Maintains the fitted rectangle's shape |
| New mapping photo could reuse an old manual calibration scale | Fresh decode and cleared stale scale | Avoids warping with coordinates from an earlier image |

Checks: 39 isolated Android persistence/geometry checks, 10 real-raster QR/math checks, 9 photo-save transaction checks, 12 picture-web checks, 10 mapping-web checks. The installed web remote was tested with the owner's HEIC and generated four-code image, with auto-apply disabled for these fixtures. No synthetic fit was applied to the owner's 95%-aligned wall. A fresh physical wall photo remains necessary to verify the optical result.

Typing changes were tested against an isolated visible Android test app: ordinary text and all six auto-advancing OTP cells, including a leading zero, passed. Select/confirm the target editor with the remote first; an unselected field is not a valid input connection. The temporary app and dummy data were removed afterwards and YouTube was restored. Ten pure OTP transaction checks also pass. This does not certify every third-party application's custom login fields.

## Memory and release notes

The device has roughly 1 GB RAM. Full-resolution screen capture during YouTube playback triggered low-memory kills of Studio/Adapter. These are Android LMK events, not evidence that photo fitting changed saved geometry. EShare and AirPlay receiver processes were force-stopped (not uninstalled) while unused, freeing headroom. Reopen mirroring from the remote when needed. Actual photo decoding and fitting run on the phone/Mac; avoid high-resolution digital screenshots while playing video.

Picture values, current YouTube look, alignment and mapping scene were retained through the Studio update. Adapter stays at 0.17. No light-current, temperature or thermal protection limits were bypassed. Official TV app catalogue links were tightened; Netflix certification/licence compatibility remains an independent task. No pirated APKs or DRM bypasses were installed.

## Open source

- QR: [jsQR 1.4.0](https://github.com/cozmo/jsQR), Apache-2.0; unmodified local asset and licence.
- HEIC: [heic-to 1.5.2](https://github.com/hoppergee/heic-to), LGPL-3.0, with libheif 1.22.2/libde265 1.0.16; unmodified optional worker library. The release includes `heic-decoder-source-1.5.2.zip` containing the exact upstream source commit, dependency source archives, licence texts, build instructions and hashes. It is separate from BeamOS application code and can be replaced when rebuilding the Studio assets.

See `docs/LIVE-CALIBRATION.md` for the separate, unfinished live-camera work.

## 0.19 focus follow-up

The final browser review exposed a YouTube text field reopening the typing sheet over Picture controls after a reconnect. Studio 0.19 keeps automatic typing sheets in Remote/Live/Type and closes them when entering Picture/Map/Apps/More. This preserves photo/reference editing focus. Seven focused routing checks pass. 0.18 remains an immutable earlier package; 0.19 is the final installed photo update.
