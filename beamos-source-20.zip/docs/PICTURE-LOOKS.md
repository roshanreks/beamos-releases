# BeamOS 0.17 — working picture controls and saved looks

The picture sliders previously sent a `pic` WebSocket message that the server did not handle. The UI appeared to change while the picture engine never received the change. The companion now serializes/coalesces acknowledged HTTP writes, rejects stale replies, preserves failed drafts for retry, and displays verified readback. The old WebSocket message is also handled for older remotes.

## What each layer does

Streaming app / HDMI input → Allwinner picture engine (black level, contrast, colour, sharpening, gamma) → LCD/panel and LED light engine → lens → wall. Screen Coach changes geometric alignment; Mapping Studio changes lighting scenes. A picture look changes neither of those stored geometries. BeamOS remains an app/controller on the original vendor Android 11 firmware; this update does not replace the kernel or light-engine driver.

Image brightness is a black-level/picture control, separate from lamp output. Setting brightness/contrast/colour to 100 is not an optical brightness upgrade and can destroy detail. Native Custom used to load old values; entering/editing a look now retains its other parameters and explicitly writes the complete bounded profile.

## Built-in starting points

All nine looks select vendor High-bright mode 2, panel/PQ level 100, and dynamic backlight off. They are deliberately distinct, editable starting points, not measured calibration or service-certified app profiles. No app launch or account changes occur when selecting a look. There is no automatic app/input switching in this release.

| Look | Image brightness | Contrast | Colour | Tint | Sharpness | Temporal NR | Spatial NR | Dynamic contrast | Black extension | Gamma selector | Temperature |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| Anime | 50 | 53 | 52 | 50 | 25 | Off | Off | Off | Off | 2.0 | Standard |
| YouTube | 50 | 52 | 50 | 50 | 30 | Low | Off | Off | Off | 2.1 | Standard |
| Netflix | 50 | 50 | 50 | 50 | 25 | Off | Off | Off | Off | 2.2 | Standard |
| Cinema | 50 | 48 | 48 | 50 | 30 | Low | Low | Off | Off | 2.2 | Warm |
| Bright room | 52 | 55 | 52 | 50 | 40 | Low | Off | Low | Off | 2.0 | Standard |
| Balanced | 50 | 50 | 50 | 50 | 35 | Low | Low | Off | Off | 2.2 | Standard |
| Vivid | 50 | 58 | 58 | 50 | 50 | Low | Low | Low | Off | 2.1 | Standard |
| Game | 50 | 52 | 50 | 50 | 35 | Off | Off | Off | Off | 2.2 | Standard |
| Text / PC | 50 | 50 | 50 | 50 | 0 | Off | Off | Off | Off | 2.2 | Standard |

Gamma values above are firmware selectors, not measured transfer curves. Factory standard/cool/warm gain tables on this build are identical, so warm is not evidence of a D65 result. No HDR-capability or gamut expansion claim is made. Anime is the initial recommendation for the owner's anime viewing on a white wall with some room lighting. Netflix/Cinema favour a less processed movie picture; Bright room offers a stronger shadow lift. A taste preference can be saved for any of them.

## Save and recall

Phone or Mac → Picture → choose a look → adjust sliders → enter name and optional device/room → Save current as a new preset. Apply selected recalls it; Update selected replaces that preset with the current confirmed values. Delete removes the saved entry and retains the current image. Custom recalls the last manual edit. Eco/Standard lamp choices remain available as explicit controls.

Data lives on the projector in Studio's private `picture_presets` SharedPreferences. Each saved preset has an id, name, device label, 13 values, and lamp mode. Up to 32 presets; the last applied snapshot is restored when the controller starts. It is available to all paired phones/Macs and survives a normal APK update. Uninstalling/clearing app data removes it. Device labels organise presets; they do not automatically detect an iPhone, HDMI device, or room. Existing pairing is retained.

## Maximum output and cooling findings on this unit

- `persist.sys.brightness.level=2`: highest normal lamp mode exposed by the vendor menu/API.
- `persist.sys.prj.brightness=3`; vendor array `{50,70,90,100}`: highest normal panel level.
- `/sys/class/backlight/tv/brightness=100`, `max_brightness=100`; no custom brightness array override.
- PQ backlight id 6 = 100; dynamic backlight id 13 = 0 in every built-in look.
- This verifies supported control state, not LED current, lumens, ANSI brightness or screen luminance. No hidden headroom has been demonstrated.
- Vendor `set_brightness_level` tries to couple fan policy, but the `/sys/class/prj/mode` node does not exist on this SKU. Never interpret that API/property alone as proof of fan RPM.
- The stock app contains fan levels Auto/1/2/3/4, though the feature is disabled by this model's config. The owner explicitly requested maximum cooling. A bounded request for menu level 4 was attempted: the real `speedlevel` write was denied; it remained 2 with `iopwm=50`. The ineffective saved request was restored to its original unset value. There is no RPM tachometer exposed to prove full fan speed. No raw PWM, test/dozing/high-temp mode or arbitrary 255 level is applied.
- LCD sensor read 57 °C during that check (CPU sensor is separate); `ledtemp=0` is not a valid LED-temperature calibration. Vendor overheat monitoring/cutoff and CPU thermal policy remain unchanged. Raising a thermal limit would allow hotter operation rather than produce better cooling.

## White wall / some room light setup

1. Use Anime for anime; try YouTube for compressed clips. Use Bright room only if its stronger shadow lift looks better. Compare a dark scene and a bright face; keep detail rather than selecting the largest numbers.
2. Keep light off the wall. Reflected room light sets the black floor, which picture controls cannot remove. A white wall can be neutral-looking yet still have a tint/texture; the actual wall must be measured for colour correction.
3. Place the projector nearer square to the wall where practical and focus the physical ring after it warms up. Digital keystone can align an oblique projector but costs active pixels; it cannot fix optical focus at every corner. Current saved alignment is preserved.
4. If still dim, physically reduce the projected image size by moving the projector closer and refocusing (within the vendor's range). Digital shrinking alone usually masks/rescales pixels and is not equivalent to concentrating the optical beam. Exact size recommendation awaits image width/distance.
5. In each streaming app, select the highest stable source resolution supported by the subscription/device/network; use 1080p when available. Verify the actual video resolution/codec, rather than treating an Android display-resolution setting as proof of stream quality. Heavy filters cannot recover lost compression detail. App login/DRM limits remain controlled by each provider.
6. For a measured pass: warm up and stabilise the projector, keep normal room lighting, use black/white clipping and grayscale/colour patches through the real playback path, measure reflected light with a supported colorimeter (with the right LED spectral correction), adjust black/white without clipping, then white balance/gamma/gamut. Record before/after luminance, gamma, white point and Delta E. A phone photo can assist geometry/subjective comparison; its auto exposure/white balance cannot establish reference colour calibration.

## Verified upstream projects (researched 2026-10-20)

These are a curated set of relevant primary repositories, not every projector repository. None is blindly installed or merged into this small controller. Licences and dependencies must be reviewed before code reuse.

| Project | Useful capability | Fit for BeamOS / next step |
|---|---|---|
| [HCFR](https://github.com/arthur-liberman/hcfr-code) | Meter-led display/projector measurement and patterns; Windows-oriented continuation | Best separate measurement workbench for manually tuning vendor controls. A meter is required; does not replace Android. GPL-2.0. |
| [DisplayCAL Python 3](https://github.com/eoyilmaz/displaycal-py3) | Modernised DisplayCAL; calibration/profile/LUT workflow with ArgyllCMS | Measurement work on a computer. A computer ICC/LUT is not automatically applied to native Netflix/YouTube on Android. GPL-3.0. |
| [mpv](https://github.com/mpv-player/mpv) | Configurable video player with rendering/shader controls | Optional external computer playback path to benchmark with local/authorised video. It does not modify other streaming apps' protected playback. Review its GPL/LGPL build options. |
| [libplacebo](https://github.com/haasn/libplacebo) | GPU scaling, colour management, tone mapping, ICC and LUT support | Renderer component for a future player, not a universal OS setting. Benchmark fast/default options before using more costly processing. LGPL-2.1-or-later. |
| [Anime4K](https://github.com/bloc97/Anime4K) | Anime-specific optional restoration/upscaling shaders | Optional A/B experiment on Mac/PC playback. Upstream focuses on 1080p → 4K and warns of processing/artifacts; a 1080p low-memory projector is not automatically improved by adding it. The new Anime look does not claim to run Anime4K. |
| [OpenCV](https://github.com/opencv/opencv) | Feature matching, homography and camera/projector geometry algorithms | Improve robustness of photo alignment, with lens distortion/inlier rejection and known targets. Geometry is distinct from photometric colour calibration. [Official homography example](https://docs.opencv.org/4.x/d7/dff/tutorial_feature_homography.html). |
| [MapMap](https://github.com/mapmapteam/mapmap) | Desktop projection mapping of surfaces | Reference for a separate Mac/PC scene-authoring workflow feeding HDMI. Requires a real build/compatibility trial; not a native streaming-app filter. GPL-3.0. |
| [H713 research](https://github.com/shift/sun50iw12p1-research) and [H713 Linux](https://github.com/well0nez/allwinner-h713-linux) | Related-SoC boot, display and hardware research | Read-only reference only. Their target boards differ from Beem 470; no compatible Android flash image, LED-current limit or fan override is established by sharing a SoC. |

[ArgyllCMS dispcal manual](https://www.argyllcms.com/doc/dispcal.html) describes instrument-based white point, luminance and response-curve calibration, including projector measurement options. [Portronics Beem 470 guide](https://support.portronics.com/support/solutions/articles/17000150995-portronics-beem-470-faq-troubleshooting-guide) recommends a dim environment and manual focus. Firmware observations above come from this unit's saved decompiled sources/config and live API/sysfs readback, rather than settings copied from a different projector.

## Validation

`node beamos/tests/picture/web-test.cjs` exercises serial writes, stale replies, failures/retry and readback UI. `bash beamos/tests/picture/run.sh SERIAL` tests the actual preset controller against a fake adapter with real isolated Android preference files (no live app data/display writes). Existing persistence tests cover alignment and mapping. Live checks separately validate hardware readback, user preset save/update/delete, APK-update retention and unchanged geometry/mapping. Readback does not substitute for an optical measurement.
