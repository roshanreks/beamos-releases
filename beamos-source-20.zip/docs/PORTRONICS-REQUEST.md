# Firmware request to Portronics support (owner sends it; nothing has been sent)

To: support@portronics.com (or the ticket form at support.portronics.com)
Subject: Beem 470 — request for stock firmware image (update.img) for local USB update

Hello,

I own a Portronics Beem 470 (purchased July 2024 on Amazon.in). Device details from the About screen:
- Model: Beem 470
- Firmware: UI_Veng.projector.20250530.175816 (updated OTA; previous 20250321.150503)
- Serial: 2406254500312
- Wi-Fi MAC: 64:EC:36:E1:DA:61
- Platform: Allwinner H713, Android 11

Could you please send me the stock firmware image for this exact model and board (the `update.img` / USB local-update
package that your service centres use), together with the checksum and the USB local-update instructions
(stick format, folder/file names, how to start the update)? I'd like to keep an offline copy so I can restore the
projector myself if a future update fails or the device stops booting, without shipping it in.

Thank you,
Roshan
