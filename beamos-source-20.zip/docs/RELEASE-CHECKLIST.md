# BeamOS release checklist (run before every `tools/beamos-release.sh`)

## 1. Playback safety (the owner's #1 rule) — from research/06-ux-rulebook.md §A
- [ ] No new Activity is started by anything a phone/Mac can trigger without an explicit confirm (`/api/launch`,
      `/api/open` return 409 while playing; the web app asks "This will pause what is playing").
- [ ] New overlays are `TYPE_APPLICATION_OVERLAY` + `FLAG_NOT_FOCUSABLE|FLAG_NOT_TOUCHABLE` (see GuideOverlay).
- [ ] No `requestAudioFocus`, `MediaPlayer`, `SoundPool`, `AudioTrack` anywhere in BeamOS: `grep -rn` must be empty.
- [ ] Typing goes through BeamIme only; never raw key injection as a fallback.
- [ ] Transport (play/pause/seek) goes through `MEDIA` (MediaController), not keys.
- [ ] Regression on the device while a YouTube video plays: `/api/state`, `/api/screen`, `/api/picture`, WS coach
      nudges, guides on/off, `/api/media toggle` ×2 → `dumpsys media_session` state stays 3 (except after toggle),
      `dumpsys window | grep mCurrentFocus` unchanged.

## 2. Geometry safety
- [ ] All geometry changes go through `CoachSession` (single owner). No new `KS_PREVIEW` callers.
- [ ] `Contract.validInsets` (convex) for new shapes; `insetsInRange` only for restores.
- [ ] Restore path tested: preview → wait 120 s → props equal the snapshot.

## 3. Build & publish
- [ ] `node --check` on the web app script; `tools/build-apk.sh` for both modules; APK sizes sane (<400 KB).
- [ ] The adapter is re-versioned only when `adapter/` or `common/` changed (release script hash).
- [ ] Release notes say what the owner will notice.

## 4. After the push
- [ ] `dumpsys package com.beamos.{adapter,studio} | grep versionName` → new version.
- [ ] `curl /api/hello` answers; wrong `Host:` → 421; `/api/playback` answers.
- [ ] `logcat -s BeamStudio:W BeamAdapter:W AndroidRuntime:E` shows nothing new from BeamOS.
- [ ] Entry in docs/CHANGELOG-DEVICE.md; `git log` has the release commit.
