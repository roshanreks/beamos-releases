# Roadmap — from stock Beem 470 to "our" projector

Written 2026-10-20 after the first ADB recon. Answers: *can we flash brand-new software from a pen
drive, and what do we build, with which open-source parts?*

## 1. The three ways to "replace the software"

| | A. Upgraded stock ("custom stock ROM") | B. Newer Android (GSI) | C. Linux (mainline H713) |
|---|---|---|---|
| What it is | The projector's own Android 11, repacked: spyware/bloat removed, our apps built in, tuned | Generic Android 12–14 system image over /system | Debian + our own UI, no Android |
| Keystone | ✅ keeps the vendor keystone (it lives in vendor-modified system components) | ❌ lost — vendor keystone is inside their system build | ⚠️ would have to be written by us (GPU warp); not in the port today |
| Netflix / Prime HD | ✅ keeps certification (ADT-3 identity, Widevine) | ❌ certification breaks | ❌ no Widevine L1 on Linux |
| Panel, Wi-Fi, remote, HDMI-in | ✅ unchanged | ⚠️ 32-bit board; arm32 GSIs are rare/abandoned | ⚠️ beta; only the HY310 board verified, ours (`h713_tuna_p3`) unknown |
| Speed / RAM | Good after debloat (+ our launcher, no EShare bloat) | Unknown, likely worse on 1 GB | Best (no Android), but you rebuild everything |
| Risk | Medium (needs a full backup first) | High | High (overwrites Android) |
| Verdict | **Recommended flashing route** | Not worth it | Fun experiment later, not a daily driver |

**Pen drive flashing exists on this chip family** (Allwinner IMAGEWTY `update.img`):
- `update/auto_update.txt` containing `sunxi_flash write update/update.img firmware` on a FAT32 stick, power-on with stick in
  (documented by well0nez/magcubic-root for Hotack H713 boards), or Settings → About → System update → Local update.
- Repack tools: `awimg.py` (well0nez/magcubic-root), fuxdasec/imagewty-tool.
- **Hard gate:** we do NOT have the stock Beem 470 `update.img` (not public; Portronics support may provide it), and raw
  partitions are root-only, so we cannot dump them over ADB. Without a stock image or full dump a bad flash is unrecoverable.
- **The backup path:** FEL mode (Allwinner USB boot ROM) + USB **A-to-A cable** + well0nez's installer/`sunxi-fel` (H713
  "trap door" build) reads the whole eMMC as a USB drive → full 7.3 GB dump incl. secure storage (HDCP keys, MAC, serial).
  Needs Linux (a UTM Linux VM on the Mac with USB passthrough works) and a way into FEL on our unit (reset pinhole + power,
  or IR remote `Vol+` at boot per YuujiLab — to be found for the Beem).

**Key insight:** almost every feature wanted does NOT require replacing the OS. Build it as apps first (Phase 1,
reversible, no flashing), then bake the finished apps into a custom stock ROM (Phase 3) for speed and permanence.

## 2. Feature map → how → open-source building blocks

| Want | How on this hardware | Repos to use / learn from |
|---|---|---|
| Keystone in any direction (wall, ceiling, floor, side angle) | System 4-corner keystone props + firmware apply path (docs/KEYSTONE-RE.md), plus projection-mode flips (front/rear/ceiling). Phone measures, projector applies. Auto-correct from tilt sensor stays as a fallback | tthumbra/hy300-keystone (approach, `keystone.js` solver, app_process helper); jcmellado/js-aruco (marker detection in Safari); BingyaoHuang/single-shot-pro-cam-calib, kamino410/procam-calibration (math reference) |
| Control everything from iPhone | Projector serves a web app (PWA, "Add to Home Screen"); QR pairing; HTTPS/WSS with self-signed cert; remote, keyboard, volume, apps, inputs, keystone, presets | Our code. Ideas: hy300-keystone `remote.js`; protocol ref tronikos/androidtvremote2 |
| Control from laptop | Same web app in any browser; plus full screen-view-and-click of the projector from the Mac | NetrisTV/ws-scrcpy (MIT, browser scrcpy), Genymobile/scrcpy (Mac app, `brew install scrcpy`) |
| iPhone / iPad / Mac screen share | AirPlay receiver app (appears natively in Control Centre → Screen Mirroring, also Mac). Replaces the heavy EShare stack | **jqssun/android-airplay-server** (GPL-3, AirPlay 2, H.264/H.265, Android TV, PIN), prat3ik/iMirror (GPL-3, armeabi-v7a APK), antimof/UxPlay (the C core) |
| Android phone screen share | Miracast sink (vendor `com.softwinner.miracastReceiver` already present; many new phones dropped Miracast); fallback: our WebRTC share page (laptop Chrome/Edge) | ivygroup/miracast-sink; hy300-keystone `share.html` (WebRTC) — Google Cast receiver is NOT possible (needs Google certification) |
| Camera on the projector | USB webcam on the USB-A host port (USB 2.0 host confirmed; `android.hardware.camera.external` declared) → auto re-calibrate after rotating | jiangdongguo/AndroidUSBCamera (Apache-2), saki4510t/UVCCamera, shiyinghan/UVCAndroid |
| Fast, lightweight | Disable spyware/bloat; replace launcher; drop EShare if AirPlay app replaces it; animations off; AOT-compile key apps; LMK/zram tuning (root) | aistra0528/Hail (disable apps via Shizuku), micha102/hy300pro-debloat, well0nez/magcubic-root |
| Privileged actions without root | Shell-uid helper via `app_process` (keystone props, input injection, pm disable) — either our own or Shizuku | RikkaApps/Shizuku (Apache-2, 31k★), awesome-shizuku |
| Launcher | Our own projector-first home screen | leanbitlab-org/LtvLauncher (GPL-3, minimal), BareLauncher, sinusinu/Molla, android/tv-samples (official patterns) |
| Firmware work | Unpack/repack IMAGEWTY, root, FEL backup/unbrick | well0nez/magcubic-root (`awimg.py`), fuxdasec/imagewty-tool, YuujiLab/HY300-H713-Research (+ YuujiLab/sunxi-tools), well0nez/allwinner-h713-linux (FEL dump, installer) |
| Linux experiment | Mainline 6.18 + Debian; HDMI-in, audio, Wi-Fi, focus motor, camera on HY310 | well0nez/allwinner-h713-linux, shift/sun50iw12p1-research, srgneisner/hy300-linux-porting |

## 3. Phases

### Phase 1 — Apps on stock Android (no flashing, all reversible) ← start here
1. Security/debloat per docs/SECURITY-AUDIT.md (`pm disable-user`, documented undo).
2. Accept Android SDK license (user) → build toolchain complete.
3. **Beem Studio** projector app + shell helper:
   - LAN server (HTTPS 8443 + WSS), QR pairing token, phone/laptop web app.
   - Keystone: manual 4-corner drag (live), save presets per room/orientation, reset; then photo auto-fit.
   - Remote: d-pad, OK/back/home, iPhone keyboard text, volume, launch apps, HDMI input switch, sleep timer.
4. Install the AirPlay receiver (build from jqssun source or verified release) → Mac/iPhone mirroring.
5. Our launcher as default home (keep vendor launcher installed but disabled — HDMI/keystone shortcuts re-provided by us).
6. Laptop: ws-scrcpy for full remote view when debugging.

### Phase 2 — Full backup (prerequisite for any flashing)
- Get: USB A-to-A cable; Linux VM (UTM) or Linux PC; find FEL entry on the Beem.
- Run well0nez `h713-install identify` + full `dump` (read-only). Store 3 copies.
- Also try to capture the official OTA package (htcotaupdate endpoint from the audit) and ask Portronics support for the
  stock `update.img`.

### Phase 3 — Custom stock ROM via pen drive
- Unpack stock image → remove spyware/bloat APKs → add Beem Studio + AirPlay + launcher as system/priv-apps →
  Magisk-patched boot (root) → tune `build.prop`/init (zram, LMK, no boot video, default source LOCAL) → repack → USB stick.
- Note: we do not have Hotack's platform signing key, so our apps can't run as `android.uid.system`; root (Magisk) or the
  shell helper covers what needs privilege.

### Phase 4 — Optional experiments
- Mainline Linux on a second unit or after full dump; native iPhone app with LiDAR calibration (Swift, from
  hy300-keystone `ios/`); distance sensor / ESP32 add-ons.

## 4. How we write the code (engineering rules for a 1 GB, 32-bit projector)

- **Projector app:** Kotlin or Java, minSdk/targetSdk 30, **armeabi-v7a only**, no Gradle needed (aapt2 → javac/kotlinc →
  d8 → zipalign → apksigner) or a minimal Gradle build. Plain Android Views for the launcher (Compose for TV is nicer to
  write but costs RAM/startup on this device — measure before adopting). No WebView inside the projector app.
- **One process, event-driven:** no polling loops; foreground service only while the server is needed; idle RAM target
  < 40 MB PSS (check with `dumpsys meminfo <pkg>`).
- **Helper:** tiny dex run by `app_process` as shell, listens on 127.0.0.1 only, token-authenticated, whitelist of
  actions (keystone set/get, keys, text, launch, input switch). Never a generic "run any command" endpoint.
- **Phone/laptop UI:** one static web app (vanilla JS or Preact, < 200 KB), served by the projector; PWA manifest so it
  opens full-screen from the iPhone home screen. HTTPS + WSS only; pairing token in QR; revoke from projector.
- **Calibration:** ArUco markers (js-aruco) → homography → corner offsets → firmware units → apply → re-measure (closed
  loop). Geometry code is pure functions with unit tests on simulated scenes (as hy300-keystone does).
- **Safety:** every write has an undo; keystone values range-checked against firmware limits; "panic reset" button
  (full-frame keystone) reachable from phone and remote.
- **Measure, don't guess:** `dumpsys meminfo`, `dumpsys gfxinfo`, `top -m 10`, boot time via `logcat -b events | grep boot_progress`.
- **Licensing:** GPL-3 parts (AirPlay receiver, LtvLauncher) stay separate apps or we accept GPL for our app;
  hy300-keystone has no license → reference only, don't copy code verbatim.

## 5. Shopping list

| Item | Why | Approx. |
|---|---|---|
| USB A-to-A cable | FEL full backup / unbrick | ₹150–300 |
| USB webcam (UVC, 1080p, wide angle) | projector-side auto keystone | ₹800–1,500 |
| Pen drive (have it) | firmware flashing in Phase 3 | — |
| USB-UART 3.3 V adapter (optional) | deep recovery, needs opening the case | ₹200 |
| Linux: UTM VM on the Mac (free) | runs the FEL/dump tools | free |
