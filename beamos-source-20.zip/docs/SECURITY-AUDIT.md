# Security / Privacy Audit — Portronics Beem 470 (Hotack OEM)

- **Device:** Allwinner H713 (sun50iw12p1, 32-bit armv7 userspace), Android 11, build `UI_Veng.projector.20250530.175816`, `ro.build.type=user`, security patch **2022-02-05**
- **Date:** 2026-10-20
- **Method:** static analysis of pulled APKs/binaries (jadx, strings, keytool) plus read-only adb (`/proc/net/tcp*`, `ps`, `getprop`, `dumpsys package`, `logcat -d`, `cat` of rc/config files, `adb pull` of APKs/jars/certs). Nothing on the device was modified, disabled or executed, and no binary was run locally.
- Paths below are relative to `projector-lab/` unless absolute.

---

## 0. Executive summary

**No residential-proxy, SOCKS, tunnel or traffic-resale SDK was found** on this unit. The HY300 indicators are all absent from every decompiled APK, from `services.jar`/`framework.jar`, from the vendor partition and from `binaries/`:

- `com.hotack.silentsdk`, `com.hotack.writesn`
- SOAX, ports 12341/12342
- `shortx.srafx.com`, `imasdk`

The firmware is still **not trustworthy**. The real problems are:

| # | Finding | Severity |
|---|---|---|
| 1 | **Platform and OTA signing keys are the public AOSP test keys.** Every vendor APK is signed with the AOSP *platform* test key (serial `b3998086d056cffa`, SHA-256 `C8:A2:E9:BC:…`) or the AOSP *testkey* (`936eacbe07f201df`, `A4:0D:A8:0A:…`). `/system/etc/security/otacerts.zip` contains only `testkey.x509.pem`, the AOSP public testkey. Anyone can therefore sign a "system" app or a full OTA image this device will accept. | Critical (platform) |
| 2 | **Remote silent app install/uninstall/launch as `system`**. `com.htc.storeos` takes commands from `store-api.aodintech.com`: silent `pm install -r -d`, silent uninstall, launch at boot. It **silently updated itself during this session**: v30 → v46 at 12:47:38, with no user action and the privacy-consent flag unset. | High |
| 3 | **Firmware OTA over plain HTTP**: `ota.triplesai.com:8080` / `otaapi.triplesai.com:8080`, fallback `139.199.190.220:8080`. The only integrity check before install is an MD5 that comes from the same HTTP response. Recovery and update_engine verify against the public testkey. A network attacker can push persistent firmware. The same service has a **remote "unauthorized device" kill switch** that reboots the projector. | High |
| 4 | **Root on demand**. `qw` is a renamed Koush/CyanogenMod `su` daemon running as root. It grants root to any uid 0/1000/1001/2000 caller, and every vendor app runs as uid 1000. `/system/bin/wifi` is a setuid-root AOSP `su` with its uid check removed. SELinux is **permissive**. | High (local) |
| 5 | **Telemetry**: <br>• app-usage tracking hooked into `system_server`, uploaded every 2 h over plain HTTP with MAC + serial (`com.htc.eventuploadservice`); <br>• Baidu Mobile Statistics SDK in the launcher with consent force-set to true (MACs, ANDROID_ID, GAID/OAID, UI auto-trace); <br>• IP geolocation; <br>• serial/MAC sent to the OTA and EShare license servers. | Medium (privacy) |
| 6 | **Ad injection**: `com.htc.expandsdk` checks the foreground activity every second and overlays TCL VAST video ads (from `euads-o.api.leiniao.com`) when you open the vendor App Store. | Low–Medium |
| 7 | **Large unauthenticated LAN surface**: the EShare/AirPlay/DLNA stack listens on ~15 TCP/UDP ports on all interfaces. PIN mode is off (`eshare_pin_code_mode=0`), the AirPlay password is disabled, and it can inject input. ADB-over-TCP (5555) is currently open. | Medium |

**The 111.230.36.129:8080 connection came from `com.htc.htcotaupdate` (uid 1000), not a root process.** Evidence is in §2.

---

## 1. Component verdicts

| Component | What it is | Remote endpoints | Code-exec / install | Proxy? | Needed for core? | Verdict |
|---|---|---|---|---|---|---|
| `/system/bin/qw` (init `qw`, root, class core) | CM/Koush `su --daemon`, v15 | none | **root shell for uid 0/1000/1001/2000** | no | No: only EShare uses su, for optional features | **Privacy/security-invasive (root backdoor-by-design)** |
| `/system/bin/wifi` (setuid root) | AOSP `su` with uid check removed | none | root for any non-NO_NEW_PRIVS caller (adb shell, init scripts) | no | No | **Security-invasive** |
| `/system/bin/esharert` | Koush `su` client v16, **aarch64**, so it cannot run on this 32-bit userspace | none | (dead) | no | No | Benign-but-unneeded |
| `/vendor/bin/dom2reg` (root, NET_ADMIN) | Maps `persist.sys.timezone` to an ISO country code and sets the Wi-Fi regulatory domain via nl80211 | none | no | no | **Yes** (Wi-Fi channels) | **Required** |
| `multi_ir`, `gpioservice`, `systemmixservice`, `isomountservice`, `tvserver` | Allwinner HW daemons (IR→uinput mouse, GPIO, audio mix, ISO mount, TV input) | none seen | no | no | Yes | Required |
| `dbgserver` (disabled unless `persist.vendor.dbgserver=1`) | Demod/I²C register debug TCP server | LAN listener if enabled | register r/w | no | No | Benign (not running) |
| `com.htc.htcotaupdate` | Firmware OTA checker + remote kill switch | `ota.triplesai.com:8080`, `otaapi.triplesai.com:8080` (both → **111.230.36.129**), `139.199.190.220:8080` | `RecoverySystem.installPackage` / hands to `com.softwinner.update` | no | Only for OTA | **Privacy-invasive + insecure** |
| `com.htc.storeos` | Vendor App Store + remote app-deployment agent | `https://store-api.aodintech.com/{sign/app/list, sign/app/update/check, channel/check, app/install/report}`, `https://ota-api.aodintech.com/upgrade/check`, `faq.aodintech.com` | **silent `pm install -r -d`, silent uninstall, launch-on-boot, LAN APK-upload server** | no | No (Google Play is present) | **Privacy-invasive / high-risk (remote install channel)** |
| `com.htc.expandsdk` | Ad overlay SDK (TCL "vastad") | `http://pb-api.aodintech.com/api/collections/addialog/records`, `https://euads-o.api.leiniao.com/ads/adsSdk/vastTag` | no | no | No | **Adware (benign-but-unneeded)** |
| `com.htc.eventuploadservice` | Usage telemetry | `http://event-api.aodintech.com/report` | no | no | No | **Privacy-invasive** |
| `com.htc.htclauncherhighenglishd08` | Home screen (`persist.sys.homePackage`) with Baidu Mobstat | `hmma.baidu.com`, `dxp.baidu.com`, `mtjsocket.baidu.com`, `http://store-api.aodintech.com/sign/app/list`, `forum.alliwava.com` | no | no (only OkHttp internals mention "proxy") | **Yes** (only home app) | **Privacy-invasive but required** |
| `com.htc.htcsettings` | Settings + manual keystone (`persist.sys.manualkeystone_*`) | Baidu SDK bundled and configured but **not started** in vendor code | no | no | **Yes** | Required |
| `com.htc.closedialog` | Power menu, low-battery, **temperature check**, manual-focus, BT-speaker; dormant DeepSeek voice bridge | `https://api.deepseek.com/chat/completions` (only when triggered by intent) | no | no | **Yes** (power/thermal) | Required (contains a leaked API key) |
| `com.hysd.vafocus` | Auto-focus / auto-keystone (no INTERNET permission) | none | no | no | **Yes** | Required |
| `com.htc.hyk_test` | Factory test / aging app (no INTERNET) | none | `exec("su")` in FileUtils | no | No | Benign-but-unneeded |
| `com.htc.screensaver` | DreamService screensaver | none | no | no | No | Benign |
| `android.rockchip.update.service` | Local USB/SD `update.zip`/`update.img` finder + LAN OTA query | `http://192.168.1.143:2300/OtaUpdater/android?...&sn=<serial>` (hard-coded factory LAN default) | `RecoverySystem.installPackage` | no | Only for USB firmware flashing | Benign-but-unneeded (minor leak) |
| `com.softwinner.update` | A/B update UI (update_engine); bundled BigBigCloud SDK is not wired | none active | applies OTA | no | Only for OTA | Benign |
| `com.ecloud.eshare.server` (+`eairplay`, `emedia`, `eshare.linedisplay.receiver`, `allshare.edisplay.idisp`) | EShare / AirPlay / DLNA / wired / eDisplay mirroring receivers | `h1.ee-share.com`, `hub.ee-share.com`, `app.ee-share.com` (license + crash report), `https://update.ee-share.com` (self-update), `192.168.0.77:8001` (factory fallback) | self-update silent install; uses `esharert` (su) | no | **Yes, if you use screen mirroring** | Benign-but-unneeded if unused; privacy-light; LAN exposure |

---

## 2. Attribution of the 111.230.36.129:8080 connection

1. **DNS**: `dig` shows `ota.triplesai.com` and `otaapi.triplesai.com` both resolve to **111.230.36.129**.
2. **Strings**: the only code anywhere containing `triplesai` or port-8080 OTA hosts is `decompiled/com.htc.htcotaupdate/sources/com/util/RequestManager.java`:
   ```
   BASE_URL1 = "http://ota.triplesai.com:8080"
   BASE_URL2 = "http://otaapi.triplesai.com:8080"
   BASE_URL3 = "http://139.199.190.220:8080"
   ```
   Searched: all 30 vendor APKs, the extra APKs, `services.jar`, `framework.jar`, the vendor partition and `binaries/qw`. `qw` contains no hostnames or IPs at all.
3. **Why it showed uid 0**: in `recon/20261020-1252/net-tcp.txt` the row is `192.168.1.11:40270 → 111.230.36.129:8080` with **state `06` (TIME_WAIT)**, uid 0 and **inode 0**.
   - TIME_WAIT sockets are kernel-owned remnants of a closed connection, and the kernel reports uid 0/inode 0 for them.
   - The Google `:443` TIME_WAIT rows next to it show uid 0 for the same reason.
   - It is **not** evidence of a root process.
4. **Trigger**: `com.htc.htcotaupdate` (pid 4713, uid 1000) is started at boot by `com.receiver.BootReceiver`. On first network-up it runs two services:
   - `UpgradeRemindService.checkVersion()` → `POST V1/Ota/Check`;
   - `ReBootService.checkNumber()` → `POST V1/Ota/CheckDevice`.

---

## 3. Detailed findings

### 3.1 `qw` — root su daemon (`/system/bin/qw`, `/system/etc/init/qw.rc`)

**Identity**
- Static ARM32 ELF, 388 KB, 0755 root:shell, SELinux type `qw_exec`.
- It is the CyanogenMod/Koush `su`. Strings: `Usage: su [options] … --daemon start the su daemon agent`, `15 com.koushikdutta.superuser`, `/dev/com.koushikdutta.superuser.daemon`, `%s/server`, `starting daemon client %d %d`, `request rejected (%u->%u %s)`.

**Policy** (strings `Allowing root/system/radio.`, `Allowing shell.`, `request rejected`)
- Callers with uid 0, 1000 (system), 1001 (radio) or 2000 (adb shell) are granted root.
- All other uids fall through to a database check on `/data/data/com.koushikdutta.superuser/databases/su.sqlite`. That app is absent, and the binary has no interactive/broadcast path, so those calls are rejected.

**Live state**
- `init.svc.qw=running`, pid 2421.
- Socket `/dev/com.koushikdutta.superuser.daemon/server` is `srwxrwxrwx root root u:object_r:qw_socket:s0`.

**SELinux**
- `vendor/etc/selinux/vendor_sepolicy.cil` explicitly allows `platform_app` to `connectto qw` / `qw_socket` and to `execute` `qw_exec`.
- SELinux is permissive anyway: `ro.boot.selinux=permissive`, `getenforce=Permissive`, and logcat shows `permissive=1` AVCs.

**Purpose**
- It is the root broker for EShare. EShare calls su under the name `esharert` (`com/eshare/update/Constants.COMMAND_SU="esharert"`), e.g. `ScreenCap.java` and `c/c/d/a/e.java` (`busybox pkill /system/bin/app_process`).
- The shipped `/system/bin/esharert` is an **aarch64** build that cannot execute on this armv7 userspace. So the daemon gives EShare little, but it still gives **every uid-1000 vendor app and adb shell a root shell**.

**Network**: none (no sockets other than its UNIX socket; no hostnames).

**Verdict**: not malware by itself, but a deliberate root backdoor. It can't be stopped without root (init `class core` service). Mitigate by disabling uid-1000 apps you don't need and keeping ADB off.

### 3.2 `/system/bin/wifi` — setuid-root su

- `-rwsr-sr-x root root`, 6248 bytes.
- Strings: `usage: su [WHO [COMMAND...]]`, `Switch to WHO (default 'root')…`. This is AOSP `system/extras/su`.
- The stock `"not allowed"` uid check (root/shell only) is **missing**, so the binary runs as root for anyone who can exec it.
- Android apps run with `PR_SET_NO_NEW_PRIVS` (seccomp), so the setuid bit doesn't elevate *apps*. It does elevate adb shell, init `shell` services (`preinstall`, `appsdisable`, `gmsopt`) and native daemons.
- No caller was found in any APK or jar; it looks like a factory leftover.

### 3.3 `dom2reg` (`/vendor/bin/dom2reg`, root, `NET_ADMIN`)

- Links `libnl` (`genl_connect`, `nl80211`).
- Contains a table of ~400 IANA time zones → ISO-3166 alpha-2 codes. Strings: `convert timezone to alpha2 country code`, `regulatory set to [%s] %s(%d)`, `timezone change, new: %s, pre: %s`, `persist.sys.timezone`.
- It sets the cfg80211 regulatory domain from your timezone and re-applies it on timezone change.
- No network I/O beyond netlink. **Required** for correct Wi-Fi channel/power limits.

### 3.4 `com.htc.htcotaupdate` (uid 1000, `/product/app/HtcOtaUpdate_QZ`)

Evidence: `decompiled/com.htc.htcotaupdate/sources/com/`.

**Endpoints**
- `RequestManager` tries `BASE_URL1` first, then `BASE_URL2`, then the raw IP `BASE_URL3` on failure (`requestHttp`/`onReqFailed`).
- Paths: `V1/Ota/Check`, `V1/Ota/CheckDevice`, `V1/Ota/UpgradeState`.
- All plain HTTP on port 8080.

**Data sent**
- `UpgradeRemindService.checkVersion()` and `UpgradeStateService` send:
  - `IMEI` = `ro.serialno` (`Const.getSerialNumber`);
  - `MAC` = wlan0 MAC (`Const.getMacAddr`);
  - `Version` = `Build.DISPLAY`;
  - `Model` = `persist.sys.Model` (`Beem 470`);
  - `Channel` = `persist.sys.Channel` (`aodin`);
  - `DstVersion`, `UpgradeState`.
- Headers: `phoneModel`, `systemVersion`, `appVersion 3.2.0`, `Sign`.

**Install path**
- Downloads `update.zip` to external storage.
- `MainActivity.validationSign()` compares only an **MD5 from the server's own response** (`newValidation`).
- Then either `RecoverySystem.installPackage(/cache/update_signed.zip)` or `com.softwinner.update/.ui.AbUpdate` (update_engine).
- Final signature verification uses `otacerts.zip` = **AOSP public testkey** (§3.12). A network attacker or a compromised vendor server can therefore install arbitrary firmware.

**Remote kill switch** (`service/ReBootService.java`)
- At boot it posts the serial to `V1/Ota/CheckDevice`.
- If the reply has `Code==0 && Data>0`, then after 30 min it shows a system overlay saying "The device is not authorized, please authorize it!" (`R.string.permission`), and 5 s later broadcasts `android.intent.action.REBOOT`. This repeats every boot.

**Code exec**: `Runtime.exec("chmod 777 <file>")` and `cat /sys/class/net/wlan0/address`. No dex loading and no app install.

**Verdict**: privacy-invasive (serial + MAC to a CN server over plaintext) and insecure (unauthenticated OTA). Only needed when you want vendor OTAs.

### 3.5 `com.htc.storeos` (uid 1000) — remote app-deployment agent

**Self-update during this session**

- `recon/20261020-1252/logcat.txt` 12:47:38:
  - `Integrity check passed for file:///data/app/vmdl2088737889.tmp`
  - `Killing 4629:com.htc.storeos … due to installPackageLI`
  - `Update system package com.htc.storeos code path from /product/app/StoreOs_QZ to /data/app/~~M3SFLiIBnIqDnQKefcCLBw==/…`
  - This was ~8 s after Wi-Fi validated (12:47:30).
- Version change:
  - Factory `/product/app/StoreOs_QZ/StoreOs_QZ.apk` is **v30 / 2505081138**. It was pulled to `recon/20261020-1252/apks-extra/com.htc.storeos-factory.apk` and decompiled to `decompiled/com.htc.storeos-factory/`.
  - Installed is **v46 / 2610101043** (`dumpsys package`: `lastUpdateTime=2026-10-20 12:47:38`).
- The download is still on the device: `/sdcard/Download/10731d58-0b91-4a33-911e-56f5caba9421des.apk`. Its MD5 `80c0c18f4288ce0494702ede0170b238` is identical to the installed v46 APK.
- `persist.sys.storeUpdate=1` is the flag `CheckUpdateService.c()` sets when a newer version of itself is offered.
- `persist.sys.implicit_policy` (privacy consent) is **unset**, yet the install happened. The gate is `((persist.appupdate.enable==1 && implicit_policy) || appsData.isSilentInstall())`, so the server-side `silentInstall` flag alone is enough.
- v46 adds a `BOOT_COMPLETED` receiver that starts `CheckUpdateService` as a foreground service. It also adds `ExportService`, `PrivacyPolicyActivity`, `ApkUploadActivity` and `SearchActivity`.

**Server-controlled capabilities** (`decompiled/com.htc.storeos/sources/`)

| Capability | Where |
|---|---|
| Per-app server flags: `silentInstall`, `silentUninstall`, `bootStartup`, `launchType`, `launchParam`, `installType`, `md5`, `reverseLen` | `com/htc/storeos/service/CheckUpdateService.java` |
| Silent install via `pm install -r <apk>`, `pm install -r -d` (allows downgrade), split installs (`pm install-create/-write/-commit`) and `PackageInstaller` sessions (XAPK) | `r3/d.java:310,488`; `q3/f.java:668-994` |
| Silent uninstall via `PackageInstaller.uninstall` and reflective `deletePackage(pkg,null,2)` | `q3/f.java:755`; `com/google/android/material/internal/i.java:330` |
| Launch installed apps | `StartAppService`, `o1/g.java` |
| Integrity check | only an MD5 from the same response; the payload path can be AES-encrypted and byte-reversed (`reverseLen`) |
| Remote "unauthorized" overlay | `r3/b.java` `SHOW_UNAUTHORIZED_DIALOG`, driven by `channel/check` |

**Data sent**
- `deviceId` = wlan0 MAC, optionally AES-encrypted (`com/google/android/material/internal/j.r()`).
- `chanId`, `model` (`persist.sys.modelName`), `sysVersion`, `verCode`, `pkg`.
- Install reports: pkg, size, verName.
- `ExportService` also sends `ro.serialno` + MAC to `ota-api.aodintech.com/upgrade/check`. Its export text states `"data_region": "Hong Kong (Tencent Cloud)"`.
- The factory v30 used **plain HTTP** for all store-api calls and queried `https://api.ipdatacloud.com/v2/query?ip=` for geolocation (`decompiled/com.htc.storeos-factory`).

**Local attack surface** (exported, no permission; from `resources/AndroidManifest.xml`)
- `AppDetailActivity` (exported) accepts an `appData` JSON extra (url/md5/pkg/launchParam). One click on Install leads to a silent `pm install` as system.
- `PublicRequestService` (exported).
- `ExportService` (exported; writes serial + MAC to a file on `/sdcard`).
- `TestActivity` (exported).
- `ApkUploadActivity` runs a NanoHTTPD server (`fi/iki/elonen`) on ports 8899+ on all interfaces. It needs a URL token `?k=` and only runs while that screen is open. It exposes install/uninstall endpoints.

**Proxy/tunnel**: none.

**Verdict**: high-risk remote-install channel controlled by aodintech.com. Not needed: Google Play (`com.android.vending`) is installed.

### 3.6 `com.htc.expandsdk` (uid 1000) — ad overlay

Evidence: `decompiled/com.htc.expandsdk/sources/`.

- **Polling**: `com/htc/expandsdk/ExpandSdkService.java` + `f4/b.java` schedule a 1 s `TimerTask`. It calls `ActivityManager.getRunningTasks(1)` (foreground app polling).
- **Ad fetch**: when the top package is `com.htc.storeos`, it fetches `http://pb-api.aodintech.com/api/collections/addialog/records?filter=(channel='aodin'&&scene='AppStore')` (PocketBase, plain HTTP).
- **Display**: it shows a full-screen VAST video ad through `com.tcl.ff.component.vastad.Ad`.
- **Ad server**: Base64-encoded in `com/tcl/ff/component/vastad/b/e.java` → `https://euads-o.api.leiniao.com`, which resolves to 8.222.221.160, an Alibaba Cloud range. Request path is `/ads/adsSdk/vastTag`.
- **Ad request data**: `com/tcl/ff/component/vastad/core/data/b.java` sends:
  - screen w/h, UA, brand, model;
  - `did` = a random per-install UUID (`core/k/b.java`, prefs `tcl_ad/aid`);
  - `ifaType=aaid`, `appBundle=com.tcl.movieark` (store link `play.google.com/...com.tcl.movieark`).
- **Scenes**: read from `/oem/config.ini` or `/product/etc/config.ini`. The `/product` file on this unit has no `sceneList`, so only the hard-coded AppStore scene fires.
- Starts on `BOOT_COMPLETED`; foreground service.
- **No** exec, install, dex loading, sockets or proxy code (searched for `Runtime.exec|ProcessBuilder|PackageInstaller|DexClassLoader|ServerSocket|addJavascriptInterface|SOCKS`).

**Verdict**: adware, low privacy impact. Safe to disable.

### 3.7 `com.htc.eventuploadservice` (uid 1000) — usage telemetry

Evidence: `decompiled/com.htc.eventuploadservice/sources/com/htc/`.

**Endpoint**: `eventlib/utils/URL.REPORT_URL = "http://event-api.aodintech.com/report"` (plain HTTP).

**Events** (`eventuploadservice/EventService.java`)
- `100001` boot/uptime, recorded every 5 min.
- `100002` per-app usage: `pkgName`, `startTime`, `endTime`, `runTime`, `pkgVer`, `pkgVerCode`.
- Upload: at first network-up, then every 2 h (`count % 24`).

**Source of usage data**
- It receives the `com.intent.AppAliveTime` broadcast (extras `package_name`, `current_time`, `last_time`, `alive_time`).
- That broadcast is emitted by the **modified framework**: the strings `com.intent.AppAliveTime` and `alive_time` are present in `/system/framework/services.jar`, pulled to the scratchpad for this audit.

**Identifiers** (`eventlib/EventManager.java:130-181`)
- `deviceId` = wlan0 MAC (`/sys/class/net/wlan0/address`);
- `deviceSn` = `ro.serialno`;
- model, firmware version, channel, `Build.TYPE`, language.

**Verdict**: privacy-invasive (an app-usage history linked to MAC + serial, sent in cleartext). Not needed for anything.

### 3.8 `com.htc.htclauncherhighenglishd08` (uid 1000) — home screen

**Baidu Mobile Statistics SDK 4.0.10.9** (`com/baidu/mobstat`)
- Started in `com/htc/activity/HomeActivity.java:965/1127/1205`:
  ```
  StatService.init(this, "299390fc9c", "HotackLauncherTest_QZ");
  StatService.setAuthorizedState(this, true);    // consent forced on
  StatService.autoTrace(this, true, false);       // automatic UI event capture
  StatService.start(this);
  ```
- Manifest meta-data: `BaiduMobAd_EXCEPTION_LOG=true`, `GPS_LOCATION=true`, `WIFI_LOCATION=true`, `CELL_LOCATION=true`.
- The header (`HeadObject.java`) carries:
  - Wi-Fi MAC (`mc`), Bluetooth MAC, device ID, CUID;
  - SSAID/ANDROID_ID, GAID, OAID;
  - model, manufacturer, device name, ROM, board.
- The SDK includes a Wi-Fi scan collector (`cp.m(Context)`: up to 30 BSSID|SSID|RSSI). No caller of it was found in this build, so it is likely inactive.

**Endpoints**
- `https://hmma.baidu.com/app.gif`, `/auto.gif`;
- `https://dxp.baidu.com/{autoTracker,circleConfig,vizParser}`;
- `wss://mtjsocket.baidu.com/app?`.
- **Live**: on 2026-10-20 13:07 an orphaned TLS connection was observed to `103.235.46.195:443`, which is `hmma.baidu.com` per DNS. Logcat shows `com.baidu.mobstat.cr.a` running in pid 3685 (the launcher).

**Vendor calls**
- `http://store-api.aodintech.com/sign/app/list` (plain HTTP; MAC, model, sysVersion).
- The response's IP geolocation is written to `Settings.System ip_country_code` (`HomeActivity.p()`).
- A `CLOSE_WAIT` socket from uid 1000 to `119.28.17.161:80` (aodintech) was seen live.

**Code exec / install / proxy**: none in vendor code. "Proxy" references are OkHttp internals (`d/f0/e/f.java`). No `shortx.srafx.com` and no `imasdk`, unlike the HY300.

**Verdict**: privacy-invasive but it is the only launcher and `persist.sys.homePackage` points at it. Block Baidu at DNS rather than disabling it.

### 3.9 `com.htc.htcsettings` (uid 1000)

- Settings, keystone correction (`persist.sys.manualkeystone_class=com.htc.activity.CorrectionActivity`), source/picture settings.
- It is kept alive by the framework (`persist.sys.AliveAppName`).
- It bundles Baidu Mobstat (key `c13300e6c6`, channel `HotackSettingsT08_QZ_HY300`) but **no `StatService.start/init` call exists** in its code, so the SDK appears dormant.
- **Required.** Do not disable.

### 3.10 `com.htc.closedialog` (uid 1000)

**Functions**
- Power menu (`WeiMiMainActivity` → `PowerManager.shutdown/reboot`; `persist.sys.power_*`).
- `LowBatteryService`.
- `TempCheckService`: reads `/sys/class/prj/lcdadc` every 5 s, i.e. **over-temperature protection** for the LCD/LED engine.
- `ManualFocusService`, `BluetoothSpeakerActivity`, `RemoteControlService`.

**DeepSeek bridge** (`com/peasun/aispeech/aiopen/AIOpenService.java`)
- The exported service (action `com.peasun.aispeech.action.top.scene`, no permission) takes an intent extra `request`.
- It POSTs that text to `https://api.deepseek.com/chat/completions` with a **hard-coded DeepSeek API key** (`sk-5095…`, 35 chars; value deliberately not reproduced) and shows the answer in an overlay.
- Only the query text is sent: no device IDs.
- The Peasun voice-assistant app that would normally call it is **not installed**, so this is dormant unless some app fires the intent.
- `RECORD_AUDIO` is declared, but no `AudioRecord`/`MediaRecorder` use was found.

**Verdict**: **required** (power and thermal safety). The leaked key is a vendor problem; block `api.deepseek.com` at DNS if you want.

### 3.11 EShare / AirPlay / DLNA stack (all uid 1000 except `emedia` uid 10030)

Evidence: `decompiled/com.ecloud.eshare.server`, `decompiled/com.ecloud.eairplay`, `decompiled/com.ecloud.emedia` (jadx, no resources).

**LAN listeners** (live `/proc/net/tcp*`, all interfaces)

| Port(s) | uid | Component |
|---|---|---|
| tcp 7100 | 1000 | AirPlay mirroring (`com.ecloud.eairplay`) |
| tcp 52333 | 1000 | eairplay local HLS, bound to `::` |
| tcp 8121, 25123, 51010–51040, 52020–52030, 56789; udp 25123, 48689, 51050 | 1000 | EShare server (`CifsServer.java`: `new ServerSocket`, `DatagramSocket(48689)`) |
| tcp 1854; udp 1900 (SSDP) | 10030 | DLNA (`com.ecloud.emedia`) |
| tcp 5555 | 2000 | adbd |
| tcp 14035 | 1041 | audioserver, not attributed |
| tcp 127.0.0.1:27015 | 1000 | local only |

**Pairing**
- `eshare_pin_code_mode` (Settings.Global) = **0**, so PIN is off.
- `/system/ecloud/airplay_settings.xml`: `airplay_password_setting_enable=false`.
- `server_features=0x003f` (mirror + EScreen etc.) and `phone_show_all_apps=1`.
- Input injection is supported via `Instrumentation.sendKeySync` (`com/ecloud/eshare/server/j.java`) and reflective `InputManager.injectInputEvent` (`b0/a.java`).

**Remote endpoints** (AES-obfuscated strings decrypted from `utils/b.a()`: AES-128-CBC, IV `0102030405060708`)

| Use | Endpoint | Data |
|---|---|---|
| License activation, plain HTTP POST | `http://h1.ee-share.com/app/auto_auth/index_pro_all(v2).php`, `http://app.ee-share.com/auto_auth/index_pro_all.php`, factory fallback `http://192.168.0.77:8001/...`, `http://hub.ee-share.com/lic/{authV2,eshareauth}.php` | `user_name`/`user_passwd` (vendor license account), `device_id`, `mac_address`, `serial_number`, `android_id`, `device_msg` (Build DISPLAY/FINGERPRINT/HOST/…) — `com/ecloud/registration/a.java` |
| Crash reports | `http://app.ee-share.com/bugreport/interface.php` (`com/ecloud/remotedebug/b.java`) | stack trace + Build fields; token `www.ecloud.tv` |
| Self-update | `https://update.ee-share.com/update.php` (`com/eshare/update/EShareUpdate.java`) | — |

The self-update performs a **silent install** via reflective `PackageManager.installPackage` or a `PackageInstaller` session. eairplay and emedia have the same updater; their update XMLs are at `http://h1.ee-share.com:8001/app/update/*.xml`.

**Root use**: `Runtime.exec("esharert", "-c", …)`, the su client name for the `qw` daemon. On this device the client binary is the wrong architecture.

**Packed apps**: `com.eshare.linedisplay.receiver` (USB/wired mirroring) and `com.allshare.edisplay.idisp` (eDisplay) are packed with **SecShell/Bangcle** (`lib/*/libSecShell.so`, encrypted `assets/classes0.jar`). Their real code is decrypted and loaded at runtime and could not be statically reviewed.

**Proxy**: none found (netty / ServerSocket use is media/control).

**Verdict**: needed only if you mirror from a phone or laptop. Otherwise it is unneeded LAN attack surface. Keep `com.ecloud.eairplay` if you AirPlay, and `com.ecloud.eshare.server` if you use the EShare app.

### 3.12 Platform signing and OTA keys

`keytool -printcert -jarfile` on every APK:
- **All vendor apps** (`com.htc.*`, `com.ecloud.*`, `com.softwinner.*`, `com.hysd.vafocus`, `android.rockchip.update.service`, `com.allshare.edisplay.idisp`) are signed with the cert `EMAILADDRESS=android@android.com, CN=Android, … Mountain View`, **serial `b3998086d056cffa`**, SHA-256 `C8:A2:E9:BC:CF:59:7C:2F:B6:DC:66:BE:E2:93:FC:13:F2:FC:47:EC:77:BC:6B:2B:0D:52:C1:1F:51:19:2A:B8`. This is the public AOSP **platform** test key.
- Theme overlays and `com.softwinner.vis` use the AOSP **testkey** (serial `936eacbe07f201df`).

`/system/etc/security/otacerts.zip` contains only `testkey.x509.pem`, serial `936eacbe07f201df`. There is no `/system/etc/update_engine/update-payload-key.pub.pem`, so update_engine also uses `otacerts.zip`.

**Consequences**
- Anyone can build an APK with `sharedUserId=android.uid.system` that installs as **system** (and then gets root via `qw`).
- Anyone can build an OTA the device accepts as genuine.
- The build lies about this: `ro.build.tags=release-keys`.

**Other platform facts**
- The fingerprint is spoofed as Google **ADT-3** (`ro.build.fingerprint=ADT-3/adt3/adt3:11/RP1A.201005.006/...`), presumably to pass Google certification checks.
- The kernel is a `-dirty` build.
- The security patch level is from 2022.

### 3.13 Boot scripts (read from device)

- `/system/bin/gmsopt`, `/system/bin/appsdisable` (root, `u:r:shell:s0`, once): `pm disable` every Google `BOOT_COMPLETED` receiver except the permission controller. This is a vendor "optimization" and the likely cause of some Google background features not starting.
- `/system/bin/preinstall` (shell): installs any APK found under `/*/preinstall` once. `/system/preinstall` is empty on this unit.
- `init.hotack.rc` makes `/vendor/zeasn/` and an LED sysfs node `chmod 0777`, and starts `preeshare`. Zeasn is a smart-TV OS vendor. Only `whiteList.conf` is present there.

---

## 4. What data leaves the device (summary)

| Data | Recipients |
|---|---|
| Wi-Fi MAC | aodintech (store/event/OTA), triplesai (OTA), Baidu, ee-share (license) |
| Serial `ro.serialno` | triplesai (OTA, kill-switch check), aodintech (event, export/OTA), LAN `192.168.1.143:2300` (RK updater), ee-share |
| ANDROID_ID / GAID / OAID / BT MAC | Baidu; ANDROID_ID also to ee-share |
| App usage history (package, start/end, runtime) | aodintech `event-api` (plain HTTP) |
| UI interaction auto-trace, crashes | Baidu; ee-share (EShare crashes) |
| IP geolocation | via aodintech store API (v30: ipdatacloud) |
| Voice/text queries | DeepSeek (only if the dormant bridge is triggered) |
| Location (GPS/cell/Wi-Fi scans) | Configured on for Baidu; the projector has no GPS/cell; the Wi-Fi-scan collector is present but no active call path was found |

---

## 5. Recommended actions (priority order)

All commands run from the Mac: `adb -s 192.168.1.11:5555 shell <cmd>`.

`pm disable-user` is reversible and survives reboot; it does not delete the APK or its data. Undo with `pm enable <pkg>` (equivalently `pm enable --user 0 <pkg>`). Check state with `pm list packages -d` or `dumpsys package <pkg> | grep enabled=`.

> **Do not** `pm uninstall` / `pm uninstall-system-updates` StoreOS. That reverts it to the factory v30, which uses plain HTTP and would just update itself again.
>
> Keep an ADB session working before disabling anything, so you can roll back.

### Priority 1 — stop the remote-install, telemetry and ad channels (safe, no core impact)

```sh
pm disable-user --user 0 com.htc.storeos              # remote silent install/uninstall agent
pm disable-user --user 0 com.htc.eventuploadservice   # app-usage telemetry
pm disable-user --user 0 com.htc.expandsdk            # ad overlay
pm disable-user --user 0 com.htc.hyk_test             # factory test app (calls su)
```
Re-enable: `pm enable com.htc.storeos` (and so on).

What breaks:
- **storeos**: the vendor "App Store" tile and its YouTube/app shortcuts. Google Play still works. Launcher tiles that came from the store API may be missing.
- **expandsdk, eventuploadservice, hyk_test**: nothing user-visible. The factory test menu disappears.

### Priority 2 — OTA, kill switch and serial leaks

```sh
pm disable-user --user 0 com.htc.htcotaupdate             # plaintext OTA + remote "unauthorized → reboot" kill switch
pm disable-user --user 0 android.rockchip.update.service  # sends serial to 192.168.1.143:2300; USB update.zip flasher
```
Re-enable: `pm enable com.htc.htcotaupdate`, `pm enable android.rockchip.update.service`.

What breaks:
- No vendor firmware update notifications.
- No automatic USB-stick firmware update.
- To update, re-enable temporarily on a network you trust. Better, get firmware from Portronics support and verify it.

Leave `com.softwinner.update` enabled. It only applies updates.

### Priority 3 — network-level blocking (router DNS / Pi-hole / firewall)

Do this **in addition to** the disables; it also covers anything a disabled app's server might re-push.

- **Domains**: `*.aodintech.com` (store-api, event-api, pb-api, ota-api, faq), `ota.triplesai.com`, `otaapi.triplesai.com`, `euads-o.api.leiniao.com`, `hmma.baidu.com`, `dxp.baidu.com`, `mtjsocket.baidu.com`, `api.ipdatacloud.com`.
- **IPs** (the OTA app falls back to raw IPs): `111.230.36.129`, `139.199.190.220`.
- **Optional**:
  - `api.deepseek.com`;
  - `app.ee-share.com`, `update.ee-share.com`, `h1.e-cloud.tv`;
  - `h1.ee-share.com` and `hub.ee-share.com` *only if mirroring keeps working* (license checks).

What breaks: vendor store, OTA and ads. Blocking ee-share license hosts may make EShare/AirPlay show "unlicensed" on a fresh activation. Test once.

### Priority 4 — shrink the LAN attack surface

**If you don't use phone/laptop mirroring:**
```sh
pm disable-user --user 0 com.allshare.edisplay.idisp       # eDisplay (packed, unauditable)
pm disable-user --user 0 com.eshare.linedisplay.receiver    # wired EShare (packed)
pm disable-user --user 0 com.ecloud.emedia                  # DLNA renderer (ports 1854/1900)
pm disable-user --user 0 com.ecloud.eshare.server           # EShare (≈12 ports; main su user)
pm disable-user --user 0 com.ecloud.eairplay                # AirPlay (7100/52333) – keep if you AirPlay
```
Re-enable each with `pm enable <pkg>`.

What breaks: the respective casting modes. Miracast (`com.softwinner.miracastReceiver`) is separate and unaffected.

**If you do use EShare**: enable its PIN code in the EShare settings screen. Keep the projector on a trusted or isolated (IoT) Wi-Fi network.

**ADB**: turn off network ADB when you're done auditing (Settings → Developer options → disable USB/network debugging, or `settings put global adb_enabled 0`). The open port 5555 plus `qw`/`wifi` means any authorized ADB client is root.

### Do NOT disable

| Package | What it does |
|---|---|
| `com.htc.htcsettings` | Settings, manual keystone; kept alive by the framework |
| `com.hysd.vafocus` | Auto-focus / auto-keystone |
| `com.htc.closedialog` | Power menu, low battery, **temperature protection** (`/sys/class/prj/lcdadc`) |
| `com.htc.htclauncherhighenglishd08` | The only HOME. Disabling it without another launcher installed and set as default can leave you at a blank screen. Block Baidu at DNS instead. If you install an alternative launcher first: `pm disable-user --user 0 com.htc.htclauncherhighenglishd08` / `pm enable com.htc.htclauncherhighenglishd08`. |
| `com.softwinner.*` (awtvinputservice, vis, awmanager, awsource, settingsassist, …) | HDMI input/TV-input/IR-related platform pieces |
| Native daemons `dom2reg`, `multi_ir`, `tvserver`, `gpioservice`, `systemmixservice` | Hardware support |

### Cannot be fixed reversibly without root / reflashing (documented only)

- `qw` su daemon (init class core) and setuid `/system/bin/wifi`.
- Permissive SELinux (`ro.boot.selinux=permissive` on the kernel cmdline).
- AOSP test platform/OTA keys.

The real fix is vendor firmware signed with private keys. The mitigations above remove the uid-1000 apps that would talk to `qw`, and remove the network paths that could deliver code to them.

---

## 6. Evidence index

| Item | Location |
|---|---|
| Decompiled apps | `decompiled/<pkg>/` (incl. new: `com.htc.storeos-factory`, `android.rockchip.update.service`, `com.softwinner.update`, `com.htc.hyk_test`, `com.htc.screensaver`, `com.ecloud.eshare.server`, `com.ecloud.eairplay`, `com.ecloud.emedia`, `com.eshare.linedisplay.receiver`, `com.allshare.edisplay.idisp`) |
| Extra APKs pulled | `recon/20261020-1252/apks-extra/` (factory StoreOS v30, eDisplay, RK update service) |
| Binaries | `binaries/qw`, `binaries/wifi`, `binaries/dom2reg`, `binaries/esharert` (pulled), `binaries/*.rc` |
| SELinux policy | `firmware-files/vendor.tar` → `vendor/etc/selinux/vendor_sepolicy.cil` (qw rules), `vendor_file_contexts:177` |
| Network snapshot | `recon/20261020-1252/net-tcp.txt` (TIME_WAIT row to `111.230.36.129:8080`); live samples 13:07–13:08 showed `103.235.46.195:443` (hmma.baidu.com) and `119.28.17.161:80` (aodintech, uid 1000) |
| Storeos self-update | `recon/20261020-1252/logcat.txt` lines ~1547–1560; `/sdcard/Download/10731d58-…des.apk` (MD5 = installed v46) |
| Framework usage hook | `/system/framework/services.jar` strings `com.intent.AppAliveTime`, `alive_time` |
