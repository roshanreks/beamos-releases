# Camera workflow review

| Before | After | Why |
| --- | --- | --- |
| A phone user had to pinpoint a measured wall reference manually. | A no-tap native wall scanner is implemented in source, with LiDAR measurement and automatic target selection. It still needs its first iOS build and device test. | Small touch targets should not be the normal calibration workflow. |
| A digital Android screenshot could be confused with observing the physical wall. | A separately labelled live wall-camera panel shows the shared phone feed, selected target and measured excluded areas. | Optical errors and obstructions must come from a physical camera. |
| A command acknowledgement could appear to mean the picture was correct. | Green requires repeated fresh post-adjustment measurements, a fixed target and matching geometry; it expires with feedback. | A successful write is different from an observed result. |
| A dropped camera could leave temporary geometry until the generic timer fired. | A fast watchdog cancels the camera's exact preview generation while preserving later manual edits. | Disconnects should restore a known saved screen without overwriting another remote. |
| Enlarging a native fit could reach beyond a measured clear area. | Proportional resizing retains the verified area bounds; expanding beyond them requests a rescan. | Keeping aspect ratio alone does not establish clearance from obstacles. |
| Manual edits could be hidden by a third-party keyboard popup. | The 0.19 Picture/Map focus-routing fix remains in 0.20. | The calibration controls remain visible while video apps own text focus. |

The controller/UI is installed locally. The native workflow is not yet an installed product. The camera must remain in the foreground on the phone, and manual optical focus remains necessary.
