# BeamOS v10 — the ambitious version (minimal, fluid, ours)

Written 2026-10-20 after v0.07. Principles: the phone/Mac is the brain, the projector is the screen; nothing ever
interrupts what is playing; every feature has an undo; the whole thing stays light (1 GB RAM, 32-bit).
Sources: research/01 (projector & TV OS features), 02 (connectivity), 04 (vision), 05 (firmware capabilities),
06 (UX rulebook), 07 (apps & building blocks).

## 1. Sign-in without pain (no passwords ever typed on the projector)
- **Sign-in Concierge.** When a TV app shows an activation code, BeamOS reads it off the screen (Live View capture →
  OCR on the phone page) and sends the phone straight to the provider's own page with the code filled in:
  netflix.com/tv2, primevideo.com/mytv, youtube.com/activate, hotstar.com/in/activate, spotify.com/pair, plex.tv/link.
  Face ID autofills the password on the phone; the projector never sees it.
- **Google account via "sign in from your phone"**; the BeamOS keyboard sheet pops up for anything else.
- **Session keeper**: BeamOS updates never touch app data; our own settings/rooms/presets are backed up to the phone
  and restored after a factory reset or the future ROM flash.

## 2. Apps: own the whole experience
- **Keep (TV versions):** YouTube TV, Prime Video TV, JioHotstar, ZEE5, SonyLIV, Spotify TV; phone-style Netflix stays
  until the device is certified (it never will be — plan for the HDMI stick as the premium Netflix path).
- **Sideload (open source, from GitHub/F-Droid):** Just Player (public domain; plays anything from USB/network),
  Jellyfin/Kodi/Plex clients, VLC, LocalSend, KDE Connect, Aerial Views screensaver, Moonlight (game streaming from
  the Mac/PC), RetroArch (phone as gamepad). SmartTube only as an owner's choice: it violates YouTube's terms and its
  signing key was compromised in Nov 2025 — the official YouTube TV app stays the default.
- **Replace the WebView:** the built-in Chromium 83 (2020) is the only one the firmware accepts; re-sign a current
  32-bit LineageOS WebView with the firmware's (public) test key → modern web apps and a usable TV browser.
- **Build our own (lightweight, Media3-based):**
  - **Beam Player** — resume, subtitles, per-file picture profile, 48 MB buffer, plays what the phone/Mac sends.
  - **Send to Beam** — LocalSend-protocol receiver inside the existing server: share any video/photo/link from the
    iPhone share sheet or drag onto the Mac menu bar.
  - **Beam Cast** — AirPlay 2 receiver (jqssun, GPL-3, separate app) switched on by BeamOS only when needed;
    "Mirror iPhone/Mac" tile; projector as an AirPlay speaker too.
  - **Beam Ambient** — screensaver from your photos (shared iCloud album via the phone), clock, weather, wall-colour
    aware; replaces the vendor screensaver.
  - **Beam Watch Next** — one continue-watching row across apps (TvProvider; needs the uid-1000 test) + our own
    resume index.
- **Remove at ROM stage:** everything vendor (launcher, store, OTA, telemetry, EShare, voice bridge, root daemons).

## 3. Picture smarter than any projector sold
- **One-tap Fit** (done in v0.07 manually; photo-fit built): ArUco grid → homography → closed loop; **auto re-fit after
  a bump** (tilt sensor change → phone prompt or USB-webcam re-measure); rooms remembered by Wi-Fi + tilt.
- **Focus Coach**: phone camera sharpness meter + tone while you turn the ring.
- **Wall colour / ambient compensation** through the picture engine's white balance and gamma — applies to Netflix
  and HDMI too (research/05 §1.4).
- **Scenes**: "Movie night" = cinema mode, lamp high-bright, lights off (HomeKit), Netflix open; "Work" = PC mode,
  full frame, keyboard sheet; "Sleep" = star screensaver, dim, timer.
- **Per-app picture profiles** (game mode on HDMI consoles, cinema for Netflix, vivid for YouTube) switched by the
  playback guard's foreground app.
- **Mapping Studio** (docs/MAPPING.md): multi-surface projection mapping with the phone camera; party visualizer.

## 4. Phone and Mac as the real interface
- **Native iOS app** (SwiftUI): HomeKit "Television" accessory → the projector appears in Control Centre's Apple TV
  Remote and in the Home app; Siri ("Hey Siri, movie night"); widgets; haptics; LiDAR keystone; lock-screen Now Playing.
- **Mac menu-bar app**: drag a file to play, global hotkeys, "Share screen to Beam" (AirPlay) in one click, Live View
  window, keyboard passthrough.
- **Swipe-pad remote** (Apple-TV-style), voice search via the phone mic, guest pairing with expiry, kids mode.
- **Instant everything**: WebSocket control (26 ms measured), state shared across all connected devices,
  reconnect in <1 s after unlock.

## 5. Connectivity
- AirPlay 2 (video + audio), Miracast, DLNA, YouTube "link with TV code", Send to Beam. Chromecast built-in remains
  impossible (Google certification).
- **Bluetooth from the phone**: pair speakers/headphones, auto-reconnect, lip-sync slider, sound modes and 7-band EQ
  (vendor audio engine, research/05 §3).
- **HDMI-CEC**: console/stick turns the projector on and controls volume; auto-switch on signal.
- **Travel hotspot** (SoftAP exists in the firmware; Portronics says unsupported — test, don't promise).
- **Power-on from the phone**: ESP32 IR blaster (~₹500) + Siri.

## 6. The OS underneath (BeamOS ROM)
- Pen-drive image: BeamOS baked in as system apps (survives factory reset), vendor layer kept, everything else gone;
  our signing keys replace the public test keys; low-RAM tuning; boot straight into BeamOS in ~15 s.
- Self-healing: watchdog on the gateway, remote diagnostics to the phone, panic reset for the picture.
- Channels: stable/beta/dev; staged rollout; "rollback" = republish the previous build with a higher version.
- Prerequisite: the FEL full backup (needs an A-to-A path to the Mac, or a stock image from Portronics).

## 7. Experimental
- USB webcam: fully automatic keystone, eye-protection dimming, gesture control; the vendor's virtual-touch stack
  (HYSD-VATOUCH368) for an interactive wall.
- Two-projector edge blending for a huge image.
- Local AI via the phone: "what's on tonight" across apps, subtitle OCR + translate, voice control through Siri Shortcuts.
- Karaoke mode, party visualizer, star-projector sleep mode.

## 8. Order of work (each step ships as an auto-update)
v0.08 Sign-in Concierge + Now Playing polish · v0.09 Send to Beam + Beam Player · v0.10 Bluetooth/EQ/lip-sync panel ·
v0.11 Beam Cast (AirPlay) + mirroring-on-demand · v0.12 Scenes + per-app profiles + HomeKit TV · v0.13 Focus Coach +
auto re-fit · v0.14 Ambient + Watch Next · v0.15 Mac menu-bar app · v1.0 ROM on the pen drive.
