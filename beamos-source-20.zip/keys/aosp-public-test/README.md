# AOSP PUBLIC test keys (android11-release)

Downloaded from https://android.googlesource.com/platform/build/+/refs/heads/android11-release/target/product/security/
These are the publicly published Android sample keys — NOT secrets. The Beem 470 firmware is signed with them
(platform cert serial b3998086d056cffa verified against framework-res.apk on 2026-10-20; otacerts.zip = testkey).

- platform.* → sign BeamOS system-uid apps (android:sharedUserId="android.uid.system")
- testkey.*  → sign OTA packages the stock recovery/update_engine will accept
