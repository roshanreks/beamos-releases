#!/bin/bash
# Publishes the current builds to the update feed (signed). The projector pulls from http://<mac-ip>:8765/<channel>.json
#   tools/beamos-publish.sh [channel=stable] "release notes"
set -euo pipefail
LAB="$(cd "$(dirname "$0")/.." && pwd)"; CH="${1:-stable}"; NOTES="${2:-BeamOS update}"
FEED="$HOME/Library/Application Support/BeamOS/feed"; mkdir -p "$FEED"
AAPT2=${ANDROID_HOME:-/opt/homebrew/share/android-commandlinetools}/build-tools/34.0.0/aapt2
python3 - "$LAB" "$FEED" "$CH" "$NOTES" "$AAPT2" <<'PY'
import sys, json, hashlib, subprocess, shutil, base64, re, os
lab, feed, ch, notes, aapt2 = sys.argv[1:6]
rel = {}
for mod in ("adapter", "studio"):
    apk = f"{lab}/beamos/{mod}/out/{mod}.apk"
    badging = subprocess.run([aapt2, "dump", "badging", apk], capture_output=True, text=True).stdout
    m = re.search(r"package: name='([^']+)' versionCode='(\d+)' versionName='([^']*)'", badging)
    pkg, code, name = m.group(1), int(m.group(2)), m.group(3)
    out = f"{pkg}-{code}.apk"
    sha = hashlib.sha256(open(apk, "rb").read()).hexdigest().upper()
    dst = f"{feed}/{out}"
    if os.path.exists(dst):
        # Same versionCode already published: keep the published bytes (devices may hold that file), reuse its hash.
        sha = hashlib.sha256(open(dst, "rb").read()).hexdigest().upper()
    else:
        shutil.copyfile(apk, dst + ".tmp"); os.replace(dst + ".tmp", dst)
    rel[pkg] = {"versionCode": code, "versionName": name, "url": out, "sha256": sha, "notes": notes}
payload = json.dumps({"channel": ch, "releases": rel}, separators=(",", ":")).encode()
open(f"{feed}/.payload", "wb").write(payload)
sig = subprocess.run(["openssl", "dgst", "-sha256", "-sign", f"{lab}/keys/beamos-update/update-private.pem", f"{feed}/.payload"],
                     capture_output=True, check=True).stdout
os.remove(f"{feed}/.payload")
json.dump({"payload": base64.b64encode(payload).decode(), "sig": base64.b64encode(sig).decode()}, open(f"{feed}/{ch}.json.tmp", "w"))
os.replace(f"{feed}/{ch}.json.tmp", f"{feed}/{ch}.json")
print(json.dumps(rel, indent=1))
PY
# Internet copy: the same feed on GitHub Pages (projector verifies the signature either way).
if [ -d "$FEED/.git" ]; then
  git -C "$FEED" add -A
  if ! git -C "$FEED" diff --cached --quiet; then
    git -C "$FEED" -c user.name="Roshan" -c user.email="umsubscription@gmail.com" commit -q -m "$CH $NOTES"
  fi
  if [ "${BEAMOS_LOCAL_ONLY:-0}" = "1" ]; then
    echo "staged locally only — public feed unchanged"
  else
    git -C "$FEED" push -q origin main
    echo "pushed online → https://roshanreks.github.io/beamos-releases/$CH.json (deployment still needs verification)"
  fi
fi
echo "published → $FEED/$CH.json"
