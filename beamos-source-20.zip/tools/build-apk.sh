#!/bin/bash
# Builds one BeamOS module into <module>/out/<name>.apk. Fails on any error.
#   tools/build-apk.sh <module-dir> <platform-test|release>
# Module layout: AndroidManifest.xml, src/ (Java), optional assets/, optional libs/*.jar
# Shared sources from beamos/common/src are always compiled in.
set -euo pipefail
shopt -s nullglob
MOD="$(cd "$1" && pwd)"; MODE="${2:?signing mode: platform-test or release}"
LAB="$(cd "$(dirname "$0")/.." && pwd)"
export JAVA_HOME=/opt/homebrew/opt/openjdk@17 PATH=/opt/homebrew/opt/openjdk@17/bin:$PATH
SDK=${ANDROID_HOME:-/opt/homebrew/share/android-commandlinetools}
BT=$SDK/build-tools/34.0.0; AJ=$SDK/platforms/android-30/android.jar
for f in "$BT/aapt2" "$BT/d8" "$BT/zipalign" "$BT/apksigner" "$AJ"; do [ -e "$f" ] || { echo "missing $f"; exit 1; }; done
NAME="$(basename "$MOD")"; OUT="$MOD/out"
rm -rf "$OUT" && mkdir -p "$OUT/classes" "$OUT/dex"

ASSETS=(); [ -d "$MOD/assets" ] && ASSETS=(-A "$MOD/assets")
RES=()
if [ -d "$MOD/res" ]; then
  "$BT/aapt2" compile --dir "$MOD/res" -o "$OUT/res.zip"
  RES=(-R "$OUT/res.zip" --auto-add-overlay)
fi
"$BT/aapt2" link -I "$AJ" --manifest "$MOD/AndroidManifest.xml" ${ASSETS[@]+"${ASSETS[@]}"} ${RES[@]+"${RES[@]}"} \
  --min-sdk-version 30 --target-sdk-version 30 -o "$OUT/unsigned.apk"

CP="$AJ"; JARS=()
if [ -d "$MOD/libs" ]; then for j in "$MOD"/libs/*.jar; do CP="$CP:$j"; JARS+=("$j"); done; fi
SRCS=(); while IFS= read -r -d '' f; do SRCS+=("$f"); done < <(find "$MOD/src" "$LAB/beamos/common/src" -name '*.java' -print0)
javac --release 8 -Xlint:-options -encoding UTF-8 -cp "$CP" -d "$OUT/classes" "${SRCS[@]}"
CLASSES=(); while IFS= read -r -d '' f; do CLASSES+=("$f"); done < <(find "$OUT/classes" -name '*.class' -print0)
"$BT/d8" --release --min-api 30 --lib "$AJ" --output "$OUT/dex" "${CLASSES[@]}" ${JARS[@]+"${JARS[@]}"}
(cd "$OUT/dex" && zip -q ../unsigned.apk classes*.dex)
"$BT/zipalign" -f 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

case "$MODE" in
  platform-test)
    "$BT/apksigner" sign --key "$LAB/keys/aosp-public-test/platform.pk8" --cert "$LAB/keys/aosp-public-test/platform.x509.pem" \
      --out "$OUT/$NAME.apk" "$OUT/aligned.apk" ;;
  release)
    "$BT/apksigner" sign --ks "$LAB/keys/beamos-release/beamos-release.p12" --ks-pass "file:$LAB/keys/beamos-release/store-password.txt" --ks-key-alias beamos \
      --out "$OUT/$NAME.apk" "$OUT/aligned.apk" ;;
  *) echo "unknown signing mode $MODE"; exit 1 ;;
esac
"$BT/apksigner" verify --print-certs "$OUT/$NAME.apk" | grep -m1 "SHA-256" | sed "s/^/[$NAME] /"
echo "[$NAME] built $OUT/$NAME.apk ($(du -h "$OUT/$NAME.apk" | cut -f1))"
